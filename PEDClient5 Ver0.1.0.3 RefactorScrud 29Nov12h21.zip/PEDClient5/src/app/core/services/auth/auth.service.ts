import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { HttpClient, HttpResponse, HttpHeaders, HttpParams } from '@angular/common/http';


import { AuthHttp, JwtHelper, tokenNotExpired } from 'angular2-jwt';
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Rx';

import { TokenProfile, LoginModel } from '../auth/auth-model';

import * as appSetting from '../../../app.setting';

@Injectable()
export class AuthService {
    public refreshSubscription$: Subscription;
    public jwtHelper: JwtHelper = new JwtHelper();

    constructor(private http: HttpClient) {

    }

    public logIn(data: LoginModel): Observable<Object> {
        // data can be any since it can either be a refresh tokens or login details
        // The request for tokens must be x-www-form-urlencoded

        // const headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
        const headers = new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded');

        const body = new HttpParams()
            .set('username', data.username)
            .set('password', data.password)
            .set('grant_type', 'password')
            .set('scope', 'openid email profile roles');

        console.log('AuthTokenService: logIn()');

        // return this.http.post('/connect/token', body, options);
        return this.http.post(appSetting.backendUrl + '/connect/token', body, {headers: headers});
    }

    public saveTokenLocalStorage(obj: any): TokenProfile {

        // const res = <Response>response;
        // const data = res.json();

        // saving token to local storage
        localStorage.setItem('access_token', obj.access_token);
        localStorage.setItem('id_token', obj.access_token);
        // Reading again to confirm
        const test = localStorage.getItem('access_token');
        // console.log(test);
        if (test === obj.access_token) {
            console.log('access token get OK. Save to local storage successfully!');
            // Test decode token
            const decodeToken = this.jwtHelper.decodeToken(obj.id_token) as TokenProfile;
            return decodeToken;
        } else {
            console.log('Fail to get access token!');
            return <TokenProfile>{};
        }
    }

    public restoreTokenProfile(): TokenProfile {
        // Reading again to confirm
        const accessToken = localStorage.getItem('access_token');
        const idToken = localStorage.getItem('id_token');
        // console.log(test);
        if (idToken !== undefined) {
            console.log('id token restore OK!');
            // Test decode token
            const decodeToken = this.jwtHelper.decodeToken(idToken) as TokenProfile;
            return decodeToken;
        } else {
            console.log('Fail to restore id token!');
            return <TokenProfile>{};
        }
    }


    loggedIn(): boolean {
        return tokenNotExpired('id_token');
    }

    public deleteTokens() {
        localStorage.removeItem('id_token');
    }
}
