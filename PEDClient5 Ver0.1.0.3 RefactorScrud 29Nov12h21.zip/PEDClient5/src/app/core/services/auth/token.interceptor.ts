import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpHeaders
} from '@angular/common/http';

import { AuthHttpService } from './authHttp.service';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  constructor(public auth: AuthHttpService) {}
  
  
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    
    // const headers = request.headers.set('Authorization', `Bearer ${this.auth.getToken()}`);
    // const headers = new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded')
    //                                  .set('Authorization', `Bearer ${this.auth.getToken()}`);
    const headers = new HttpHeaders().set('Content-Type', 'application/json')
                                     .set('Authorization', `Bearer ${this.auth.getToken()}`);

    if(request.url.includes('/connect/token') !==true ) {
        request = request.clone({
          headers: headers
      });
    }

    return next.handle(request);
  }

}