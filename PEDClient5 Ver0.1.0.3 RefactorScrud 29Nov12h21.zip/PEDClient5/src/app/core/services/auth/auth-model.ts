﻿
export interface TokenProfile {
    sub: string; // 165d6bc1-1ac7-427c-8c5c-4aa1b44e1ac8,
    name: string; // User Name
    role: string[]; // Admin,Station.CanCreate,Station.CanDelete,Station.CanEdit...
    email: string; // hoangdaica@gmail.com,
    userid: string; // "165d6bc1-1ac7-427c-8c5c-4aa1b44e1ac8",
    usage: string; // identity_token,
    jti: string; // cc3d58c0-a8f8-4eec-927c-966ee0a52373,
    at_hash: string; // qf91tByHynlQ8FHZ_IRB8g,
    nbf: string; // 1494902282,
    exp: string; // 1494903482,
    iat: string; // 1494902282,
    iss: string; // http://localhost:58314/
}

export interface LoginModel {
    username: string;
    password: string;
}
