﻿
import { Injectable, ViewContainerRef } from '@angular/core';

@Injectable()
export class RootAppService {

    _viewContainerRef: ViewContainerRef;

    constructor(
    ) {

    }
    setViewContainerRef(viewContainerRef: ViewContainerRef) {
        this._viewContainerRef = viewContainerRef;
    }
    getViewContainerRef(): ViewContainerRef {
        return this._viewContainerRef;
    }

}
