﻿import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { Observable } from 'rxjs/Rx';
import { Store } from '@ngrx/store';
import { Action } from '@ngrx/store';

import * as login from '../../../login/logged-in.actions';
import * as fromLogin from '../../../login/log-in.state';

@Injectable()
export class UserService {

    public loggedInState$: Observable<any>; // LoggedInState

    constructor(
        private router: Router,
        public store$: Store<any>,
        // private logInActions: LogInActions
    ) {
        this.loggedInState$ = this.store$.select(fromLogin.getLoginState);
    }

    LogOutHandle() {
        this.store$.dispatch(new login.LogOut(undefined)); // Delete token
        this.store$.dispatch(this.logOutAction());
        //
        this.router.navigate(['/login']);
    }

    public logOutAction(): Action {
        // alert('logOut(): Action');
        return {
            type: 'USER_LOGOUT'
        };
    }


    isloggedIn$(): Observable<boolean> {
        return this.loggedInState$.map(state => {
            return state.loggedIn;
        });
    }

    currentUser$(): Observable<any> {
        return this.loggedInState$.map(state => {
            return state.userProfile;
        });
    }

    currentUserName(): string {
        let userName = '';
        this.loggedInState$.take(1).subscribe(s => userName = s.userProfile.name);
        return userName;
    }

    currentUserId(): string {
        let userId = '';
        this.loggedInState$.take(1).subscribe(s => userId = s.userProfile.userid);
        return userId;
    }

    userNumEvent$(): Observable<number> {
        return this.loggedInState$.map(state => {
            return state.userNumEvent;
        });
    }

    isInRole$(role: string): Observable<boolean> { // 'WebAppRole.Admin'
        return this.loggedInState$.map(state => {
            if (state.userProfile.role !== undefined) {
                return (state.userProfile.role.indexOf(role) >= 0) ? true : false;
            }else {
                return false;
            }
        });
    }

}
