﻿
import { Component, OnInit, OnDestroy } from '@angular/core';
// import { Http, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';

// import { Observable, Subscription } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';

@Component({
    selector: 'confirm-email',
    templateUrl: './confirm-email.component.html'
})
export class ConfirmEmailComponent implements OnInit, OnDestroy {

    public sub2: Subscription;
    public message: string;
    public errorMsg: string;

    // We need to get http params from active router link
    constructor(
        public http: HttpClient
    ) {

    }

    // As soon as component init, we send confirm email code to backend to verify
    ngOnInit() {

        // Get full of url
        const url = window.location.href;
        // Restore to origin backend generated path to confirm email
        const originPath = url.replace('UserRegisters', 'api/UserRegisters');

        // end confirm info to backend
        this.sub2 = this.sendConfirmEmailToBackEnd(originPath)
            .map(res => {
                this.message = res.toString();
            })
            .catch(error => {
                this.errorMsg = error;
                return Observable.of(error);
            })
            .subscribe(); // Cold => hot observable
    }

    ngOnDestroy() {
        if (this.sub2 !== undefined) {
            this.sub2.unsubscribe();
        }
    }

    sendConfirmEmailToBackEnd(fullPath: string): Observable<Object> {
        return this.http.get(fullPath);
    }


}
