﻿import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; // If your component use [(ngModel)] => you have to import FormModule
// import { SharedModule } from '../shared/shared.module';

import { UserRegisterComponent } from './user-register.component';
import { ConfirmEmailComponent } from './confirm-email.component';
import { userRegisterRouting } from './user-register.routing';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        userRegisterRouting
        // SharedModule
    ],
    declarations: [
        UserRegisterComponent,
        ConfirmEmailComponent
    ],
    providers: [
    ]
})
export class UserRegisterModule { }
