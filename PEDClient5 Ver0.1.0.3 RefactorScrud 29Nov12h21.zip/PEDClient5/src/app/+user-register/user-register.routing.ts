﻿import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UserRegisterComponent } from './user-register.component';
import { ConfirmEmailComponent } from './confirm-email.component';

const routes: Routes = [
    { path: '', component: UserRegisterComponent },
    // { path: 'NewRegister', component: UserRegisterComponent },
    // { path: 'UserRegisters', component: ConfirmEmailComponent }
];

export const userRegisterRouting: ModuleWithProviders = RouterModule.forChild(routes);
