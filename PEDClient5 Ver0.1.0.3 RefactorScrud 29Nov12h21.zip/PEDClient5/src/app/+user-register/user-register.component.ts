﻿
import { Component, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Http, Headers, RequestOptions } from '@angular/http';

// import { Observable, Subscription } from 'rxjs/Rx';

import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';

@Component({
    selector: 'user-register',
    templateUrl: './user-register.component.html'
})
export class UserRegisterComponent implements OnDestroy {

    registerForm: FormGroup;
    valueChangeSub: Subscription;

    formErrors = {
        'name': '',
        'userName': '',
        'email': '',
        'password': '',
        'confirmPassword': ''
    };

    validationMessages = {
        'name': {
            'required': 'Name is required.'
        },
        'userName': {
            'required': 'UserName is required.'
        },
        'email': {
            'required': 'Email is required.'
        },
        'password': {
            'required': 'Email is required.'
        },
        'confirmPassword': {
            'required': 'Email is required.'
        }
    };

    constructor(
        private fb: FormBuilder,
        private http: Http
    ) {
        this.createForm();
    }

    ngOnDestroy() {
        if (this.valueChangeSub !== undefined) {
            this.valueChangeSub.unsubscribe();
        }
    }

    createForm() {
        this.registerForm = this.fb.group({
            name: ['', Validators.required],
            userName: ['', Validators.required],
            email: ['', Validators.required],
            password: ['', Validators.required],
            confirmPassword: ['', Validators.required]
        });
        // Subscribe to value change
        this.valueChangeSub = this.registerForm.valueChanges
            .subscribe(data => this.onValueChanged(data));
    }

    onValueChanged(data?: any) {
        if (!this.registerForm) { return; }
        const form = this.registerForm;

        for (const field in this.formErrors) {
            if (this.formErrors.hasOwnProperty(field)) {
                this.formErrors[field] = '';
                const control = form.get(field);

                if (control && control.dirty && !control.valid) {
                    const messages = this.validationMessages[field];
                    for (const key in control.errors) {
                        if (control.errors.hasOwnProperty(key)) {
                            this.formErrors[field] += messages[key] + ' ';
                        }
                    }
                }
            }
        }
    }

    onSubmit() {
        const test = this.registerForm.value;

        // Send request to Backend
        const body = JSON.stringify(test);
        const headers = new Headers({ 'Content-Type': 'application/json' });
        const options = new RequestOptions({ headers: headers });
        this.http.post('api/UserRegisters' + '/', body, options)
            .map(res => {
                    // this.modal.alert()
                    // .size('lg')
                    // .showClose(true)
                    // .title('Register Result Information')
                    // .message(res.json())
                    // .open();
            })
            .catch(error => {
                    //  this.modal.alert()
                    // .size('lg')
                    // .showClose(true)
                    // .title('Register Result Information')
                    //      .message(error.json())
                    // .open();
                return Observable.of(error);
            })
            .subscribe();
    }
}
