// Ver0.1.0.2: Rename StandardCrud app. 23/Nov/2017. Hoang
// Ver0.1.0.1: Fix some test fail (Karma test). 21/Nov/2017. Hoang

export const appVersion = '0.1.0.3';
export const backendUrl = 'http://localhost:58310'; // The Url of backend app
