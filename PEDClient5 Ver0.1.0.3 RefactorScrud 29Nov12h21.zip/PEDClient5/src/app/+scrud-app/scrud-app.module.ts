import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../shared/shared.module';
import { ScrudAppComponent } from './scrud-app.component';
import { scrudAppRouting } from './scrud-app.routing';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    scrudAppRouting
  ],
  declarations: [
    ScrudAppComponent
  ]
})
export class ScrudAppModule { }
