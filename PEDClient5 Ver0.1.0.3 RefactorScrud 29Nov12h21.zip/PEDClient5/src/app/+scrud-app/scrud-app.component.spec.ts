import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../shared/shared.module';
import { ScrudAppComponent } from './scrud-app.component';

describe('ScrudAppComponent', () => {
  let component: ScrudAppComponent;
  let fixture: ComponentFixture<ScrudAppComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        SharedModule
      ],
      declarations: [ ScrudAppComponent]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScrudAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should be created', () => {
  //   expect(component).toBeTruthy();
  // });
});
