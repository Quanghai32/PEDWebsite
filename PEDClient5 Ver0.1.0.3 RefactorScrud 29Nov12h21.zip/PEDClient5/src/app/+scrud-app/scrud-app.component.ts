import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { HttpParams } from '@angular/common/http';

import * as appSetting from '../app.setting';
import { UserService } from '../core/services/user/user.service';

import { StandardCrudAppInfo, StandardCrudUserRouterLink } from '../shared/standard-crud/standardCrud.model';
import { StandardCrudState } from '../shared/standard-crud/standardCrud.state';

@Component({
  selector: 'app-scrud-app',
  templateUrl: './scrud-app.component.html',
  styleUrls: ['./scrud-app.component.css']
})
export class ScrudAppComponent implements OnInit, OnDestroy {
  scrudAppInfoInput: StandardCrudAppInfo;
  sub: any;
  constructor(
    public route: ActivatedRoute,
    public router: Router,
    public userService: UserService
  ) { }

  ngOnInit() {
    this.calAppInfo();
    this.sub = this.router.events.subscribe(e => {
      if (e instanceof NavigationEnd) {
        this.calAppInfo();
      }
    });
  }

  ngOnDestroy() {
    if (this.sub !== undefined) {
      this.sub.unsubscribe();
    }
  }

  calAppInfo() {
    const test = location.pathname.split('/');
    // const appName = location.pathname.split('/').slice(-1)[0];
    let appName;
    if (test.length >= 2) {
      appName = test[2];
    }
    let routingId;
    if (test.length >= 3) { // Routing directly to 1 item (by id)
      routingId = test[3];
    }
    const queryParams = this.route.snapshot.queryParams;
    // alert(appName);
    this.settingAppInfo(appName, queryParams, routingId);
  }

  settingAppInfo(appName: string, queryParams: any, routingId: any) {
    this.scrudAppInfoInput = Object.assign({}, this.scrudAppInfoInput);
    switch (appName.toLowerCase()) {
      case 'TestCruds'.toLowerCase():
        this.scrudAppInfoInput = <StandardCrudAppInfo>{
            appName: 'TEST CRUD APPLICATION',
            apiLink: appSetting.backendUrl + '/api/testCruds',
            frontEndLink: '/ScrudApp/testCruds', // router link of application
            routingId: routingId
        };
        break;

      case 'AppUser'.toLowerCase():
        // Test User router link
        const test = <StandardCrudUserRouterLink>{
            displayName: 'Role Control',
            userLink: '/UserRoles',
            userParam: ''
        };

        const links = [
            test
        ];

        this.scrudAppInfoInput = <StandardCrudAppInfo>{
            appName: 'APP USER CONTROL APPLICATION',
            apiLink: appSetting.backendUrl + '/api/AppUsers',
            userRouterLinks: links
            // userRouterLinks: undefined
        };
        break;

      case 'UserEvents'.toLowerCase():
        // const paras1: URLSearchParams = new URLSearchParams();
        // paras1.set('userId', this.userService.currentUserId());

        this.scrudAppInfoInput = <StandardCrudAppInfo>{
            appName: 'YOUR EVENTS',
            apiLink: appSetting.backendUrl + '/api/userEvents',
            urlSearchParams: new HttpParams().set('userId', this.userService.currentUserId())
        };
        break;

      case 'UserRoles'.toLowerCase():
        // const testId = queryParams['userId'];
        // // alert(testId);

        // const paras2: URLSearchParams = new URLSearchParams(); // URLSearchParams
        // paras2.set('id', testId);

        this.scrudAppInfoInput = <StandardCrudAppInfo>{
            appName: 'USER ROLE CONTROL APPLICATION',
            apiLink: appSetting.backendUrl + '/api/UserRoles',
            urlSearchParams: new HttpParams().set('id', queryParams['userId'])
        };
        break;

      case 'productModels'.toLowerCase():
        this.scrudAppInfoInput = <StandardCrudAppInfo>{
            appName: 'PRODUCT MODEL APPLICATION',
            apiLink: appSetting.backendUrl + '/api/productModels'
        };
        break;
      case 'JigProfiles'.toLowerCase():
        this.scrudAppInfoInput = <StandardCrudAppInfo>{
            appName: 'JIG PROFILE APPLICATION',
            apiLink: appSetting.backendUrl + '/api/JigProfiles'
        };
        break;

      case 'ModelJigInfos'.toLowerCase():
        this.scrudAppInfoInput = <StandardCrudAppInfo>{
            appName: 'MODEL JIG INFO APPLICATION',
            apiLink: appSetting.backendUrl + '/api/modelJigInfos'
        };
        break;

      // AuditJigs
      case 'AuditJigs'.toLowerCase():
        this.scrudAppInfoInput = <StandardCrudAppInfo>{
            appName: 'AUDIT JIG HISTORY',
            apiLink: appSetting.backendUrl + '/api/AuditJigs'
        };
        break;

      default:
        // alert('undefined!');
        break;
    }
  }


  userLinkStandardCrudHandle(state: any) {
     // alert('userLinkStandardCrudHandle(): ' + this.scrudAppInfoInput.appName);
      switch (this.scrudAppInfoInput.appName) {
        case 'APP USER CONTROL APPLICATION':
          // Analyze state
          // Looking for selected user
          const userId = state.selectedObj.obj.Id;
          // Do navigation
          this.router.navigate(['/ScrudApp', 'UserRoles'] , {queryParams: {appName: 'UserRoles', userId: userId}});
          break;

        default:
          break;
      }
  }
}
