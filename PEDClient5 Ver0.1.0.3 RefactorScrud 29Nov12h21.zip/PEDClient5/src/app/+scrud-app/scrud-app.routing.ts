
import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ScrudAppComponent } from './scrud-app.component';

const routes: Routes = [
    { path: '', component: ScrudAppComponent }, // Normal routing
    { path: ':id', component: ScrudAppComponent } // Routing directly to view 1 item
];


export const scrudAppRouting: ModuleWithProviders = RouterModule.forChild(routes);