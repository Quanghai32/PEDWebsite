import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { JwtModule } from '@auth0/angular-jwt';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { NgxMyDatePickerModule } from 'ngx-mydatepicker';

import { CoreModule } from './core/core.module';
import { SharedModule } from './shared/shared.module';
import { AppRoutingModule } from './app-routing.module';
import { LoginModule } from './login/login.module';

import { reducers, metaReducers } from './app-store';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { TopHeaderComponent } from './layout/top-header/top-header.component';
import { HeaderBarComponent } from './layout/header-bar/header-bar.component';
import { BottomBarComponent } from './layout/bottom-bar/bottom-bar.component';
import { AdSidebarComponent } from './layout/ad-sidebar/ad-sidebar.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    TopHeaderComponent,
    HeaderBarComponent,
    BottomBarComponent,
    AdSidebarComponent,
  ],
  imports: [
    BrowserModule,
    HttpModule,
    HttpClientModule,
    NgxMyDatePickerModule.forRoot(),
    CoreModule.forRoot(),
    SharedModule.forRoot(),
    AppRoutingModule,
    StoreModule.forRoot(reducers, { metaReducers }),
    EffectsModule.forRoot([]),
    LoginModule
  ],
  providers: [
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
