import { Component, ViewContainerRef } from '@angular/core';

import { RootAppService } from './core/services/root/root-app.service';
import { LogInService } from './login/log-in.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 constructor(
        public viewRef: ViewContainerRef,
        public rootAppService: RootAppService,
        public logInService: LogInService
    ) {
        this.rootAppService.setViewContainerRef(this.viewRef); // Saving instance to refer later in Modal services...
        // alert('App Start!');
        // Try to restore last login if token still valid
        this.logInService.restoreLastLogin();
    }
}
