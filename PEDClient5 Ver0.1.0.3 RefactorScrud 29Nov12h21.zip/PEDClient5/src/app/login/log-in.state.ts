﻿
import { createSelector, createFeatureSelector } from '@ngrx/store';

import { TokenProfile } from '../core/services/auth/auth-model';


export interface LogInState {
    loggedIn: boolean;
    userProfile: TokenProfile;
    logInMessage: string; // Display while verify account or when error happen
    userNumEvent: number; // How many events related to user
}

export const LogInInitialState: LogInState = {
    loggedIn: false,
    userProfile: <TokenProfile>{},
    logInMessage: '',
    userNumEvent: 0
};

export const getLoginState = createFeatureSelector<LogInState>('loggedIn');

