import { Action, ActionReducer } from '@ngrx/store';
import { createSelector } from '@ngrx/store';

import { LogInInitialState } from './log-in.state';
import { LogInState} from './log-in.state';

import * as login from './logged-in.actions';


export function loggedInReducer(
  state = LogInInitialState,
  action: login.Actions
): LogInState {
  switch (action.type) {

    case login.LogInActionTypes.LOG_IN_START: {
      return Object.assign({}, state, { logInMessage: 'Verifying your account...' });
    }

    case login.LogInActionTypes.LOG_IN_SUCCESS: {
        const loggedInSuccess = Object.assign({}, state, { loggedIn: true, logInMessage: '' });
        return loggedInSuccess;
    }

    case login.LogInActionTypes.LOG_IN_FAIL: {
        let errMsg = 'Invalid attemp login.';
        if (action.payload.error_description !== undefined) {
            errMsg = action.payload.error_description;
        }
        const loggedInFail = Object.assign({}, state, { loggedIn: false, logInMessage: errMsg });
        return loggedInFail;
    }

    case login.LogInActionTypes.LOG_OUT: {
        return LogInInitialState;
    }

    case login.LogInActionTypes.LOG_IN_UPDATE_USER_PROFILE: {
        let newState: LogInState;
        newState = Object.assign({}, state, { userProfile: action.payload });
        return newState;
    }

    case login.LogInActionTypes.LOG_IN_UPDATE_USER_NUM_EVENT_SUCCESS: {
        let newState: LogInState;
        newState = Object.assign({}, state, { userNumEvent: action.payload.total });
        return newState;
    }

    case login.LogInActionTypes.LOG_IN_RESTORE_USER_PROFILE: {
        let newState: LogInState;
        newState = Object.assign({}, state, { loggedIn: true, userProfile: action.payload });
        return newState;
    }

    case login.LogInActionTypes.LOG_IN_RESTORE_LAST_LOGIN: {
        let newState: LogInState;
        newState = Object.assign({}, state, { loggedIn: true, userProfile: action.payload });
        return newState;
    }

    default: {
      return state;
    }
  }
}