
import { Injectable } from '@angular/core';

import { type } from '../util/action-name-helper';
import { Action } from '@ngrx/store';

import { LoginModel } from '../core/services/auth/auth-model';
import { TokenProfile } from '../core/services/auth/auth-model';

export const LogInActionTypes = {
    LOG_IN_START: type('[LogIn] Start'),
    LOG_IN_SUCCESS: type('[LogIn] Success'),
    LOG_IN_FAIL: type('[LogIn] Fail'),
    //
    LOG_OUT: type('[LogIn] LogOut'), // USER_LOGOUT
    //
    LOG_IN_UPDATE_USER_PROFILE: type('[LogIn] UpdateUserProfile'),
    //
    LOG_IN_UPDATE_USER_NUM_EVENTS: type('[LogIn] UpdateUserNumEvents'),
    LOG_IN_UPDATE_USER_NUM_EVENT_SUCCESS: type('[LogIn] UpdateUserNumEventSuccess'),
    LOG_IN_UPDATE_USER_NUM_EVENT_FAIL: type('[LogIn] UpdateUserNumEventFail'),

    //
    LOG_IN_RESTORE_USER_PROFILE: type('[LogIn] RestoreUserProfile'),
    LOG_IN_RESTORE_LAST_LOGIN: type('[LogIn] RestoreLastLogIn')
};


export class LogInStart implements Action {
  readonly type = LogInActionTypes.LOG_IN_START;

  constructor(public payload: LoginModel) {}
}

export class LogInSuccess implements Action {
  readonly type = LogInActionTypes.LOG_IN_SUCCESS;

  constructor(public payload: any) {}
}

export class LogInFail implements Action {
  readonly type = LogInActionTypes.LOG_IN_FAIL;

  constructor(public payload: any) {} // error
}

export class LogOut implements Action {
  readonly type = LogInActionTypes.LOG_OUT;

  constructor(public payload: any) {} // error
}

export class LogInUpdateUserProfile implements Action {
  readonly type = LogInActionTypes.LOG_IN_UPDATE_USER_PROFILE;

  constructor(public payload: TokenProfile) {}
}

export class LogInUpdateUserNumEvent implements Action {
  readonly type = LogInActionTypes.LOG_IN_UPDATE_USER_NUM_EVENTS;

  constructor(public payload: string) {} // userId
}

export class LogInUpdateUserNumEventSuccess implements Action {
  readonly type = LogInActionTypes.LOG_IN_UPDATE_USER_NUM_EVENT_SUCCESS;

  constructor(public payload: number) {} // data.total
}

export class LogInUpdateUserNumEventFail implements Action {
  readonly type = LogInActionTypes.LOG_IN_UPDATE_USER_NUM_EVENT_FAIL;

  constructor(public payload: any) {} // error
}

export class LogInRestoreUserProfile implements Action {
  readonly type = LogInActionTypes.LOG_IN_RESTORE_USER_PROFILE;

  constructor(public payload: TokenProfile) {}
}

export class LogInRestoreLastLogin implements Action {
  readonly type = LogInActionTypes.LOG_IN_RESTORE_LAST_LOGIN;

  constructor(public payload: TokenProfile) {}
}

export type Actions =
  | LogInStart
  | LogInSuccess
  | LogInFail
  | LogOut
  | LogInUpdateUserProfile
  | LogInUpdateUserNumEvent
  | LogInUpdateUserNumEventSuccess
  | LogInUpdateUserNumEventFail
  | LogInRestoreUserProfile
  | LogInRestoreLastLogin;



// @Injectable()
// export class LogInActions {

//     public logInStart(user: LoginModel): Action {
//         return {
//             type: LogInActionTypes.LOG_IN_START,
//             payload: { user }
//         };
//     }

//     public logInSuccess(data: any): Action {
//         return {
//             type: LogInActionTypes.LOG_IN_SUCCESS,
//             payload: data
//         };
//     }

//     public logInFail(error: any): Action {
//         return {
//             type: LogInActionTypes.LOG_IN_FAIL,
//             payload: error
//         };
//     }

//     public logOut(): Action {
//         return {
//             type: LogInActionTypes.LOG_OUT
//         };
//     }

//     public logInUpdateUserProfile(tokenProfile: TokenProfile): Action {
//         return {
//             type: LogInActionTypes.LOG_IN_UPDATE_USER_PROFILE,
//             payload: tokenProfile
//         };
//     }

//     //Update User Num Events
//     public logInUpdateUserNumEvent(userId: string): Action {
//         return {
//             type: LogInActionTypes.LOG_IN_UPDATE_USER_NUM_EVENTS,
//             payload: userId
//         };
//     }

//     public logInUpdateUserNumEventSuccess(data: any): Action {
//         return {
//             type: LogInActionTypes.LOG_IN_UPDATE_USER_NUM_EVENT_SUCCESS,
//             payload: data.total
//         };
//     }

//     public logInUpdateUserNumEventFail(error: any): Action {
//         return {
//             type: LogInActionTypes.LOG_IN_UPDATE_USER_NUM_EVENT_FAIL,
//             payload: error
//         };
//     }

//     //

//     public logInRestoreUserProfile(tokenProfile: TokenProfile): Action {
//         return {
//             type: LogInActionTypes.LOG_IN_RESTORE_USER_PROFILE,
//             payload: tokenProfile
//         };
//     }

//     public logInRestoreLastLogin(tokenProfile: TokenProfile): Action {
//         return {
//             type: LogInActionTypes.LOG_IN_RESTORE_LAST_LOGIN,
//             payload: tokenProfile
//         };
//     }

// }
