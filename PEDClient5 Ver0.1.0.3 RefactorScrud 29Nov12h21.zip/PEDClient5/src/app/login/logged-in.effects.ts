﻿// import { Http, Response } from '@angular/http';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Action } from '@ngrx/store';
import { Actions, Effect, toPayload } from '@ngrx/effects';
// import { go } from '@ngrx/router-store';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/mapTo';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import { AuthService } from '../core/services/auth/auth.service';
// import { LogInActionTypes, LogInActions } from './logged-in.actions';
import { LoginModel, TokenProfile } from '../core/services/auth/auth-model';
import { LogInService } from './log-in.service';

import * as login from './logged-in.actions';


@Injectable()
export class LogInEffects {
    constructor(private http: HttpClient,
        private router: Router,
        private actions$: Actions,
        // private logInActions: LogInActions,
        private authService: AuthService,
        private logInService: LogInService
        ) {
            // alert('LogInEffects');
    }

    @Effect()
    login$: Observable<any> = this.actions$.ofType(login.LogInActionTypes.LOG_IN_START)
    // Map the payload into JSON to use as the request body
    .map(toPayload) // LoginModel
    .switchMap(payload => {
        return this.authService.logIn(payload)
        // If successful, dispatch success action with result
        .map((res: Object) =>
            new login.LogInSuccess(Object.assign({}, { response: res, loginmodel: payload }))) // res: Object
            // If request fails, dispatch failed action
        .catch(error => Observable.of(new login.LogInFail(error.json())));
    });

    @Effect()
    saveToken$ = this.actions$
        .ofType(login.LogInActionTypes.LOG_IN_SUCCESS)
        .map(toPayload)
        .map(payload => payload.response)
        .switchMap(payload => Observable.of(this.authService.saveTokenLocalStorage(payload))
            .map((res) => new login.LogInUpdateUserProfile(res))
            .catch(error => Observable.of(error))
        );

    @Effect()
    updateNumEvents$ = this.actions$
        .ofType(login.LogInActionTypes.LOG_IN_UPDATE_USER_PROFILE)
        .map(toPayload) // TokenProfile
        .switchMap(payload => this.logInService.getUserNumEvents(payload)
            .map((res: any) => new login.LogInUpdateUserNumEventSuccess(res)) // res: Object
            .catch(error => Observable.of(new login.LogInUpdateUserNumEventFail(error)))
        );

    @Effect({dispatch: false})
    navigateHome$ = this.actions$
    .ofType(login.LogInActionTypes.LOG_IN_UPDATE_USER_PROFILE)
    .map(toPayload)
    .do((payload) => {
        // alert('Navigate to Home!');
        this.router.navigate(['/home']);
    }).ignoreElements();

    @Effect({dispatch: false})
    logOut$ = this.actions$
        .ofType(login.LogInActionTypes.LOG_OUT)
        .map(toPayload) //
        .do((payload) => {
            // Delete token from local storage
            // alert('this.authTokenService.deleteTokens()!');
            this.authService.deleteTokens();
        });
}
