import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; // If your component use Angular directive (ngIf, ngFor...)
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; // If your component use [(ngModel)] => you have to import FormModule

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

// import { SharedModule } from '../shared/shared.module';
import { LogInService } from './log-in.service';

import { LoginComponent } from './login.component';
import { loginRouting } from './login.routes';
// import { LogInActions } from './logged-in.actions';

import { loggedInReducer } from './logged-in.reducer';
import { LogInEffects } from './logged-in.effects';

@NgModule({
    imports: [
        CommonModule, // If your component use Angular directive (ngIf, ngFor...) => you have to import CommonModule
        FormsModule, // If your component use [(ngModel)] => you have to import FormModule
        loginRouting,
        ReactiveFormsModule,
        StoreModule.forFeature('loggedIn', loggedInReducer),
        EffectsModule.forFeature([LogInEffects]),
    ],
    declarations: [LoginComponent],
    providers: [
        // LogInActions,
        LogInService
    ]
})
export class LoginModule { }
