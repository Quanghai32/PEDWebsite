﻿import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, NavigationStart, NavigationEnd, RouterState, RouterStateSnapshot } from '@angular/router';

import { Observable, Subscription } from 'rxjs/Rx';
import { Store } from '@ngrx/store';

import { LogInService } from './log-in.service';

import { LoginModel } from '../core/services/auth/auth-model';
import { LogInState } from './log-in.state';
import * as login from './logged-in.actions';

import { MyModalService } from '../shared/my-modal/my-modal.service';



@Component({
    selector: 'app-login',
    templateUrl: './login.component.html'
})

export class LoginComponent implements OnInit, OnDestroy {
    public loggedIn$: Observable<boolean>;
    public formLogin: FormGroup;
    public valueChangeSub: Subscription;
    formErrors = {
        'username': '',
        'password': '',
    };
    validationMessages = {
        'username': {
            'required': 'Username is required.'
        },
        'password': {
            'required': 'Password is required.'
        }
    };

    constructor(
        public router: Router,
        public logInService: LogInService,
        public store$: Store<LogInState>,
        public fb: FormBuilder,
        public myModalService: MyModalService
    ) {
        this.loggedIn$ = store$.select<boolean>(state => state.loggedIn);
        this.createForm();
        // alert('Login!');
    }


    ngOnInit() {
    }

    ngOnDestroy() {
        if (this.valueChangeSub !== undefined) {
            this.valueChangeSub.unsubscribe();
        }
    }

    createForm() {
        this.formLogin = this.fb.group({
            username: ['', Validators.required],
            password: ['', Validators.required]
        });
        // Subscribe to value change
        this.valueChangeSub = this.formLogin.valueChanges
            .subscribe(data => this.onValueChanged(data));
    }

    onValueChanged(data?: any) {
        if (!this.formLogin) { return; }
        const form = this.formLogin;

        for (const field in this.formErrors) {
            if (this.formErrors.hasOwnProperty(field)) {
                // clear previous error message (if any)
                this.formErrors[field] = '';
                const control = form.get(field);

                if (control && control.dirty && !control.valid) {
                    const messages = this.validationMessages[field];
                    for (const key in control.errors) {
                        if (control.errors.hasOwnProperty(key)) {
                            this.formErrors[field] += messages[key] + ' ';
                        }
                    }
                }
            }
        }
    }

    public onSubmit() {
        this.store$.dispatch(new login.LogInStart(this.formLogin.value));
        // this.myModalService.MessageOut('Test Title', 'Test Body Message');
    }
}
