﻿import { Injectable } from '@angular/core';
// import { Headers, Response, RequestOptions, URLSearchParams } from '@angular/http';
import { HttpClient, HttpParams } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
// import { AuthHttp } from 'angular2-jwt';
import { Store } from '@ngrx/store';

import { backendUrl } from '../app.setting';
import { AuthService } from '../core/services/auth/auth.service';
import { LoginModel } from '../core/services/auth/auth-model';

import { LogInState } from './log-in.state';
// import { LogInActions } from './logged-in.actions';
import * as login from './logged-in.actions';

@Injectable()
export class LogInService {

    constructor(
        private authService: AuthService,
        private store$: Store<LogInState>,
        // private loggedInActions: LogInActions,
        private http: HttpClient
    ) {
    }

    // Get User Number Events Info
    getUserNumEvents(data: any): Observable<Object> {
        // const params = new URLSearchParams();
        // params.set('userId', data.userid);

        const params = new HttpParams()
        .set('userId', data.userid);

        return this.http.get(backendUrl + '/api/UserEvents' + '/DataInfo', { params: params});
    }

    // Check if last time log-in tken is still valid or not
    checkLastTokenValid() {
        const testToken = this.authService.loggedIn();
        // If last token is still valid => we decode it & restore user profile
        if (testToken) {
            const profile = this.authService.restoreTokenProfile();
            this.store$.dispatch(new login.LogInRestoreUserProfile(profile));
        }
        return testToken;
    }

    //
    restoreLastLogin() {
        const testToken = this.authService.loggedIn();
        // If last token is still valid => we decode it & restore user profile
        if (testToken) {
            const profile = this.authService.restoreTokenProfile();
            this.store$.dispatch(new login.LogInRestoreLastLogin(profile));
        }
        return testToken;
    }

}
