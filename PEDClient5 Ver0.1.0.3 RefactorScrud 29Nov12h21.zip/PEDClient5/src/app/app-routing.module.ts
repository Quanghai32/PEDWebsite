
import { NgModule } from '@angular/core';
import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './home/home.component';
// import { UnauthorizedComponent } from './layout/Unauthorized/unauthorized.component';

// import { DatePickerComponent } from './datePicker/date-picker.component';
// import { AuthGuard } from './auth/auth-guard.service';

// import { AuthGuard } from '../app/core/services/auth/auth-guard.service';


const routes: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'home', component: HomeComponent },
    { path: 'NewRegister', loadChildren: './+user-register/user-register.module#UserRegisterModule' },
    { path: 'ScrudApp/:appName', loadChildren: './+scrud-app/scrud-app.module#ScrudAppModule' },
    { path: 'AuditJigs', loadChildren: './+audit-jig/audit-jig.module#AuditJigModule' }
];


@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule { }
