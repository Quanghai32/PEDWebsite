import { Component, OnInit, ElementRef, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

import { ModalSearchSetting, ModalSearchOutput } from './modal-search/modal-search.model';

@Component({
  selector: 'app-my-modal',
  templateUrl: './my-modal.component.html',
  styleUrls: ['./my-modal.component.css']
})
export class MyModalComponent implements OnInit {

  @ViewChild('btnModal') btnModal: ElementRef;
  @ViewChild('btnCloseModal') btnCloseModal: ElementRef;
  @Output() modalClose: EventEmitter<any> = new EventEmitter();
  @Output() mdOutput: EventEmitter<any> = new EventEmitter();
  @Input() buttons: string[];
  mdSearchSetting: ModalSearchSetting; // For searching mode mdSearchSetting
  mdSearchOutput: ModalSearchOutput;
  viewMode: string; // 'dialog': app-modal-dialog
                      // 'search': app-modal-search
  formModal: FormGroup;

  constructor(
    public fb: FormBuilder
  ) {
    this.viewMode = 'dialog';
    this.createForm();
  }

  ngOnInit() {
    // this.buttons = ['Test1', 'Test2', 'Test3'];
  }

  createForm() {
    this.formModal = this.fb.group({
      modalTitle: '',
      modalBody: '',
      modalFooter: ''
    });
  }

  setMessage(title: string, body: string) {
    this.formModal.patchValue({
      modalTitle: title
    });
    this.formModal.patchValue({
      modalBody: body
    });
  }

  buttonClick(i: number) { // User click on button event. i: id of button
    // alert(i);
    this.mdOutput.emit(i);
  }

  SearchOutput(event: any) {
    // alert(JSON.stringify(event));
    this.mdSearchOutput = event;
  }

  show() {
    const event = new MouseEvent('click', {bubbles: true});
    this.btnModal.nativeElement.dispatchEvent(event);
  }

  close() {
    // alert('close!');
    const event2 = new MouseEvent('click', {bubbles: true});
    this.btnCloseModal.nativeElement.dispatchEvent(event2);
  }

  closeEmitEvent() {
    this.modalClose.emit(true);
  }

}
