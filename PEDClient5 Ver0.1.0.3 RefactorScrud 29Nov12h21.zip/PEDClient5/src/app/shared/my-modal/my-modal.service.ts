
import { Injectable, ComponentFactoryResolver, ViewContainerRef } from '@angular/core';
import { ApplicationRef, ComponentRef, Injector, ComponentFactory, Component, EventEmitter, Output } from '@angular/core';

import { Observable } from 'rxjs/Observable';

// import { ModalApproveComponent } from './modal-approve.component';
import { MyModalComponent } from './my-modal.component';
import { ModalSearchSetting, ModalSearchOutput } from './modal-search/modal-search.model';

import { RootAppService } from '../../core/services/root/root-app.service';

@Injectable()
export class MyModalService {
    viewContainerRef: ViewContainerRef;
    mdOutput = new Observable<any>(); // For button click handle
    mdSearchSetting: ModalSearchSetting; // For searching mode
    cRef: ComponentRef<MyModalComponent>;
    viewMode: string; // 'dialog': app-modal-dialog
                      // 'search': app-modal-search


    constructor(
        public componentFactoryResolver: ComponentFactoryResolver,
        public rootAppService: RootAppService
    ) {
        this.viewMode = 'dialog';
        this.viewContainerRef = this.rootAppService.getViewContainerRef();
    }

    // For general message pop up
    MessageOut(title: string, body: any, buttons?: [any]) {
        this.viewMode = 'dialog';
        this.PushOut(title, body, buttons);
    }

    // For Searching Mode
    setSearchSetting(setting: ModalSearchSetting) {
        this.mdSearchSetting = setting;
    }

    SearchPopUp(title: string, body: string, buttons?: [any]) {
        this.viewMode = 'search';
        this.PushOut(title, body, buttons);
    }

    getSearchOutput(): any {
        if (this.cRef !== undefined) {
            return this.cRef.instance.mdSearchOutput;
        } else {
            return undefined;
        }
    }

    // Call out Modal form
    PushOut(title: string, body: string, buttons?: [any]) {
        const factory = this.componentFactoryResolver
            .resolveComponentFactory(MyModalComponent); // const => should not re-asigned again!
        if (this.viewContainerRef === undefined) {
            this.viewContainerRef = this.rootAppService.getViewContainerRef(); // We need this to avoid undefined error!
        }
        const ref = this.viewContainerRef.createComponent(factory); // const => should not re-asigned again!
        // viewContainerRef.remove();
        ref.instance.viewMode = this.viewMode;
        ref.instance.mdSearchSetting = this.mdSearchSetting;
        ref.instance.setMessage(title, body);
        ref.instance.buttons = buttons;
        this.mdOutput = ref.instance.mdOutput;
        ref.instance.show(); // Show Modal Dialog
        ref.instance.modalClose.subscribe(value => {
            // alert('remove');
            this.viewContainerRef.remove(); // When modal open, it attach to the end of body
                                            // => we need to clean it after modal close to prevent memory leak!
        });
        ref.changeDetectorRef.detectChanges();
        this.cRef = ref;
    }

    // Close Modal Form
    close() {
        if (this.cRef !== undefined) {
            this.cRef.instance.close();
        }
    }
}
