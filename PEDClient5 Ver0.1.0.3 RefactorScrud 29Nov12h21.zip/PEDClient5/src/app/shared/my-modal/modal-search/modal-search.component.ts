import { Component, Input, Output, EventEmitter} from '@angular/core';
import { OnInit, OnChanges, OnDestroy, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
// import { Headers, Response, RequestOptions, URLSearchParams } from '@angular/http';
import { HttpClient, HttpParams } from '@angular/common/http';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';

import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subscription } from 'rxjs/Subscription';

// import { AuthHttp } from 'angular2-jwt';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { backendUrl } from '../../../app.setting';

import { ModalSearchSetting, ModalSearchOutput, SelectObject } from './modal-search.model';
import { DynamicFormBase, ElementDescription, PropertyDescription } from '../../dynamic-form/dynamic-form.model';
import { PropertiesBase} from '../../dynamic-form/properties-base';
import { ParentObjInfo } from '../../dynamic-form/dynamic-form.model';
import { DynamicFormModelInfo } from '../../dynamic-form/dynamic-form.model';
import { DynamicFormService } from '../../dynamic-form/dynamic-form.service';

@Component({
    selector: 'app-modal-search',
    templateUrl: './modal-search.component.html',
    styleUrls: ['./modal-search.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush
})

export class ModalSearchComponent implements OnInit, OnChanges, OnDestroy {
    @Input() mdSearchSetting: ModalSearchSetting; // mdSearchSetting
    @Output() mdSearchOutput: EventEmitter<any> = new EventEmitter();
    formSearch: FormGroup;
    //
    dynamicFormBasess: DynamicFormBase[][];
    subscription: Subscription;
    selectObjects: SelectObject[];

    constructor(
        public cdRef: ChangeDetectorRef,
        public http: HttpClient,
        public fb: FormBuilder,
        public dynamicFormService: DynamicFormService
    ) {
        // Ini for FormGroup
        this.formSearch = this.fb.group({
            searchCriteria: 'Any',
            searchQuery: '',
            result: ''
        });
    }

    ngOnInit() {

    }

    ngOnChanges() {
        // var test: any;
        // test = this.mdSearchSetting;
        if (this.mdSearchSetting !== undefined) {
            this.calDynamicFormBase(undefined);
        }
    }

    ngOnDestroy() {
        if (this.subscription !== undefined) {
            this.subscription.unsubscribe();
        }
    }

    searchBackend(searchCriteria: string, searchQuery: string): any {
        // Create seaching url
        // var url = this.mdSearchSetting.elDescription.searchUrl + '/' + criteria + '/' + content;
        const url = this.mdSearchSetting.elDescription.searchUrl;
        const params: URLSearchParams = new URLSearchParams();
        params.set('searchCriteria', searchCriteria);
        params.set('searchQuery', searchQuery);
        // Request Backend. Note that we need to subcribe because angular http is Cold Observable?
        if (this.subscription !== undefined) {
            this.subscription.unsubscribe();
        }
        this.subscription = this.http.get(backendUrl + url, {
            params: new HttpParams().set('searchCriteria', searchCriteria).set('searchQuery', searchQuery)
        })
            // .map(res => {
            //     return res.json();
            // })
            .map((lstRet: any[]) => {
                this.selectObjects = [];
                this.selectObjects = lstRet.map(item => Object.assign({}, { obj: item, selected: false }));
                return lstRet.map(stat => stat);
                //
            })
            .subscribe(result => { // We need subscribe because angular http return cold observable
                // alert(JSON.stringify(result));
                this.mdSearchOutput.emit(result);
                this.calDynamicFormBase(result);
                this.cdRef.detectChanges(); // This command is necessary for Update View
                                            // Because use backend service with subscribe here somehow break change detect of Angular
                                            // => we have to do it manually!
            });
    }

    searchClick() {
        const searchCriteria: string = this.formSearch.get('searchCriteria').value;
        const searchQuery: string = this.formSearch.get('searchQuery').value;

        this.searchBackend(searchCriteria, searchQuery);
    }

    selectHandle(i: number, checked: boolean) { // selectObjects[i].selected = $event.target.checked;
        // alert(i);
        this.selectObjects[i].selected = checked;
        this.mdSearchOutput.emit(this.selectObjects);
        // alert(JSON.stringify(this.selectObjects));
    }

    calDynamicFormBase(lstObj: any[]) {
        // Property Base for List
        const propertiesBasess = this.dynamicFormService
            .listElementPropertiesBase(this.mdSearchSetting.elDescription, lstObj);

        let FA: FormArray; // in case of 'list'
        FA = this.fb.array([]); // Ini for Form Array

        this.dynamicFormBasess = propertiesBasess.map(propertiesBases => {
            const FG = this.dynamicFormService.toFormGroup(propertiesBases);
            FA.push(FG);

            let dynamicFormBases: DynamicFormBase[];
            return dynamicFormBases = propertiesBases.map((base, k) => {
                return Object.assign({}, {
                    formGroup: FG, // single element must belong to same FormGroup of its parent
                    propertiesBase: base,
                    cssStyle: this.mdSearchSetting.elDescription.propertyDescriptions[k].cssStyle
                });
            });
        });

        // Add to Search Form Group
        this.formSearch.setControl('result', FA);
        const test = this.formSearch.value;
    }


    get searchCriterias(): string[] {
        const result: string[] = [];
        result.push('Any'); // Default search criteria is Any
        if (this.mdSearchSetting.elDescription.propertyDescriptions.constructor === Array) {
            this.mdSearchSetting.elDescription.propertyDescriptions.forEach(item => {
                result.push(item.displayName);
            });
        }
        return result;
    }

    showMessage(msg: string, title: string) {
        this.mdSearchSetting.title = title;
        this.mdSearchSetting.message = msg;
        this.mdSearchSetting.isVisible = true;
    }

    setTitle(title: string) {
        this.mdSearchSetting.title = title;
    }

    setMessage(msg: string) {
        this.mdSearchSetting.message = msg;
    }

    showMe() {
        this.mdSearchSetting.isVisible = false;
    }

    hideMe() {
        this.mdSearchSetting.isVisible = false;
    }

    buttonClick(index: number) {
        const output = <ModalSearchOutput>{};
        // Copy Info from setting
        output.source = this.mdSearchSetting.source;
        output.sourceID = this.mdSearchSetting.sourceID;
        // Inform what button pressed?
        output.buttonDatas = this.mdSearchSetting.buttons.map((item, i) => (i === index) ? true : false);
        output.buttonPress = this.mdSearchSetting.buttons.filter((item, i) => (i === index))[0];
        // Attach Info of Item user select
        output.outputObjects = this.selectObjects.filter(item => item.selected === true)
            .map(i => i.obj);
        // Emit
        this.mdSearchOutput.emit(output);
    }
}
