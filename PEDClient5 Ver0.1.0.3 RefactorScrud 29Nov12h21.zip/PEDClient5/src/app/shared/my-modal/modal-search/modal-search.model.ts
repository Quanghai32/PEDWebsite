﻿
import { ElementDescription } from '../../dynamic-form/dynamic-form.model';

// Input Info of Searching
export interface ModalSearchSetting {
    source: any; // name of source which is owner of modal dialog
    sourceID: any; // ID of source Action (The ID of List Item Element?)
    // Info of element
    elDescription: ElementDescription;
    // Search Criterias
    // searchCriterias: string[];
    // Setting for modal view
    isVisible: boolean; // Control visibility of Modal Dialog
    title: string; // Title of Modal Dialog
    message: string; // Main Message of Modal Dialog
    buttons: string[]; // User can add a number of custom button to Modal Dialog
}

export interface SearchItemSetting {
    criteria: string; // Searching Criteria
    limitResult: number; // Limit desired the number of result return. If limitResult=0 => return all found result
    searchUrl: string; // Url for searching
}

// Output of Searching
export interface ModalSearchOutput {
    source: any; // name of source which is owner of modal dialog
    sourceID: any; // ID of source Action (The ID of List Item Element?)

    // Result
    buttonPress: string; // Name of button press
    buttonDatas: boolean[]; // Indicate what button user already press

    // For searching output
    // When display modal form for searching,
    // user will select some object from result table & press some button
    // Output of all these action is list of selected object!
    outputObjects: any[];
}

export interface SelectObject {
    obj: any; // object instance
    selected: boolean; // Indicate user select action status with object obj
}
