﻿
export interface ApplicationUser {
    Id: string;
    Name: string;
    UserName: string;
    Email: string;
    EmailConfirmed: string;
    Dept: string;
    Password: string;
}

export interface SelectUser {
    appUser: ApplicationUser; // object instance
    selected: boolean; // Indicate user select action status with object obj
}

export interface BackendApproveSetting { // Same as backend class
    requireApprove: boolean;
    approveActionInfos: BackendApproveActionSetting[];
}

export interface BackendApproveActionSetting { // Same as backend class
    actionName: string;
    explanation: string;
}

export interface VerifyRequest { // Same as backend class
    ID: string; // Primary Key
    ApplicationName: string; // Name of Application need approval
    ActionDescription: string; // Description of action need approval

    ObjectID: string; // ID of Object want to assign approve status Info
    BackendLink: string; // Api link of backend which is target when do verify for item (send from Frontend to save Verify request)
    FrontendLink: string; // Link for Approve

    RequestorUserName: string; // UserName of Requestor
    RequestorComment: string; // Comment of Requestor
    RequestTime: Date; // Timing do verify request

    ApproverUserName: string; // UserName of Approver
}

export interface VerifyResult { // Same as backend class
    ID: string; // Primary Key
    isDone: boolean; // Indicate Approve request is done or not
    Result: string; // Approve result is OK (Accept) or NG (Reject) or another...
    Comment: string; // Comment of Approver
    VerifyTime: Date; // Timing do verify action

    // Foreign Key
    VerifyRequest: VerifyRequest;
}
