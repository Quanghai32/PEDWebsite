﻿import { Component, Output, EventEmitter, ChangeDetectorRef, ChangeDetectionStrategy, ViewChild, ElementRef } from '@angular/core';
// import { URLSearchParams } from '@angular/http';
import { HttpClient, HttpParams } from '@angular/common/http';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';

// import { AuthHttp } from 'angular2-jwt';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { backendUrl} from '../../app.setting';

import { ApplicationUser, SelectUser, VerifyRequest, VerifyResult } from './standard-approve.model';
import { UserService } from '../../core/services/user/user.service';

@Component({
    selector: 'modal-approve',
    templateUrl: './modal-approve.component.html',
    styleUrls: ['./modal-approve.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ModalApproveComponent {
    @ViewChild('btnModal') btnModal: ElementRef;
    @ViewChild('btnCloseModal') btnCloseModal: ElementRef;
    @Output() modalClose: EventEmitter<any> = new EventEmitter();
    @Output() mdOutput: EventEmitter<any> = new EventEmitter();

    isVisible: boolean;
    aprRequest: VerifyRequest;
    selectUsers: SelectUser[]; // List of User search result
    subscription: Subscription;
    formApprove: FormGroup;
    viewMode: string; // 'search': searching view (Default).
                      // 'sendrequest': finish select approver & prepare for sending approve request
                      // 'notFoundApprover': User cannot find approver in database
                      // => help them sending email to someone & suggest to join PED website
                      // 'resultInfo': When sending request approve to backend & get back result
    constructor(
        public cdRef: ChangeDetectorRef,
        // public authHttp: AuthHttp,
        public http: HttpClient,
        public fb: FormBuilder,
        public userService: UserService
    ) {
        this.isVisible = false;
        this.selectUsers = [];
        // Ini for FormGroup
        this.formApprove = this.fb.group({
            searchCriteria: 'Any',
            searchQuery: '',
            approveResult: '',
            requestorComment: ''
        });
        this.viewMode = 'search'; // Default value
    }


    searchBackend(searchCriteria: string, searchQuery: string): any {
        // Create seaching url
        // var url = this.mdSetting.elDescription.searchUrl + '/' + criteria + '/' + content;
        const url = backendUrl + '/api/AppUsers/Search';
        // const params: URLSearchParams = new URLSearchParams();
        // params.set('searchCriteria', searchCriteria);
        // params.set('searchQuery', searchQuery);
        // Request Backend. Note that we need to subcribe because angular http is Cold Observable?
        if (this.subscription !== undefined) {
            this.subscription.unsubscribe();
        }
        this.subscription = this.http.get(url, {
            params: new HttpParams().set('searchCriteria', searchCriteria)
            .set('searchQuery', searchQuery)
        })
            // .map(res => {
            //     return res.json();
            // })
            .map((lstRet: any[]) => {
                this.selectUsers = [];
                this.selectUsers = lstRet.map(item => Object.assign({}, { appUser: item, selected: false}));
                return this.selectUsers;
                //
            })
            .subscribe(result => { // We need subscribe because angular http return cold observable
                this.cdRef.detectChanges(); // This command is necessary for Update View
                // Because use backend service with subscribe here somehow break change detect of Angular => we have to do it manually!
            });
    }

    selectUserHandle(index: number, value: boolean) {
        if (value === true) {
            this.selectUsers.map(item => {
                if (item.selected === true) {
                    item.selected = false;
                }
            });
        }
        this.selectUsers[index].selected = value;
    }

    get canSendRequest(): boolean {
        if (this.selectUsers.length === 0) {
            return false;
        }
        const test = this.selectUsers.filter(s => s.selected === true);
        if (test.length > 0) {
            return true;
        }
        return false;
    }

    get selectedUser(): ApplicationUser {
        if (this.selectUsers.length === 0) {
            return undefined;
        }
        const test = this.selectUsers.filter(s => s.selected === true);
        if (test.length > 0) {
            return test[0].appUser;
        }
        return undefined;
    }


    searchClick() {
        const searchCriteria: string = this.formApprove.get('searchCriteria').value;
        const searchQuery: string = this.formApprove.get('searchQuery').value;
        this.selectUsers = [];
        this.searchBackend(searchCriteria, searchQuery);
    }

    // After user select approver, write comment => sending request approval to backend & send email to approver (by backend)
    sendApproveRequest() {

        this.sendVerifyRequest();
        // // Create seaching url
        // // const url = backendUrl + '/api/StandardApproves';
        // const url = this.aprRequest.ApproveBackendLink + '/ApproveStatus';

        // // Create Approve Model & send to backend
        // const approveRequest = <BackendApproveStatus>Object.assign({}, this.aprRequest, {
        //     ApproveStatus: 'waiting for approve',
        //     RequestorUserName: this.userService.currentUserName(),
        //     ApproverUserName: this.selectUsers.filter(s => s.selected === true)[0].appUser.UserName,
        //     RequestorComment: this.formApprove.get('requestorComment').value,
        // });

        // const body = JSON.stringify(approveRequest);
        // // Request Backend. Note that we need to subcribe because angular http is Cold Observable?
        // this.authHttp.post(url + '/', body)
        //     .map(res => {
        //         // alert(res.json());
        //         this.requestResultInform(res.json());
        //         return res.json(); // Return from Backend
        //     })
        //     .catch(error => {
        //         // alert(error.json()); //Error description from backend
        //         this.requestResultInform(error.json());
        //         return Observable.of(error);
        //     })
        //     .subscribe(result => { // We need subscribe because angular http return cold observable
        //         this.cdRef.detectChanges(); // This command is necessary for Update View
        //         // Because use backend service with subscribe here somehow break change detect of Angular => we have to do it manually!
        //     });
    }

        // After user select approver, write comment => sending request approval to backend & send email to approver (by backend)
    sendVerifyRequest() {
        // Create seaching url
        const url = backendUrl + '/api/StandardApproves/VerifyRequest';

        // Create Verify Request & send to backend
        const verifyRequest = <VerifyRequest> {
            // ID : '',
            ApplicationName: this.aprRequest.ApplicationName,
            ActionDescription: this.aprRequest.ActionDescription,
            ObjectID: this.aprRequest.ObjectID,
            BackendLink: this.aprRequest.BackendLink,
            FrontendLink: this.aprRequest.FrontendLink,

            RequestorUserName: this.userService.currentUserName(),
            RequestorComment: this.formApprove.get('requestorComment').value,
            RequestTime: new Date(),
            ApproverUserName: this.selectUsers.filter(s => s.selected === true)[0].appUser.UserName
        };

        const body = JSON.stringify(verifyRequest);
        // Request Backend. Note that we need to subcribe because angular http is Cold Observable?
        this.http.post(url + '/', body)
            .map(res => {
                // alert(res.json());
                this.requestResultInform(res);
                return res; // Return from Backend
            })
            .catch(error => {
                // alert(error.json()); //Error description from backend
                this.requestResultInform(error.json());
                return Observable.of(error);
            })
            .subscribe(result => { // We need subscribe because angular http return cold observable
                this.cdRef.detectChanges(); // This command is necessary for Update View
                // Because use backend service with subscribe here somehow break change detect of Angular => we have to do it manually!
            });
    }

    // Inform to user about result of approve request send frombackend
    requestResultInform(info: any) {
        // this.modal.alert().body(info).open();
        this.formApprove.patchValue({ approveResult: info });
        this.viewMode = 'resultInfo';
    }

    // In case user cannot find approver => user input name & approver email => sending email to this person.
    sendEmailNotFoundApprover() {

    }

    sendRequestHandle() {
        this.changeViewMode('sendrequest');
    }

    changeViewMode(viewMode: string) {
        this.viewMode = viewMode; //
    }

    show() {
        const event = new MouseEvent('click', {bubbles: true});
        this.btnModal.nativeElement.dispatchEvent(event);
    }

    close() {
        // alert('close!');
        const event2 = new MouseEvent('click', {bubbles: true});
        this.btnCloseModal.nativeElement.dispatchEvent(event2);
    }

    closeEmitEvent() {
        this.modalClose.emit(true);
    }

}
