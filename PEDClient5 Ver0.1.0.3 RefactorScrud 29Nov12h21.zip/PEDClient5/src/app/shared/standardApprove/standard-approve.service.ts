﻿
// import { Injectable, ComponentFactoryResolver, ViewContainerRef, ComponentRef } from '@angular/core';
// import { ApplicationRef, Injector, ComponentFactory, Component } from '@angular/core';

import { Injectable, ComponentFactoryResolver, ViewContainerRef } from '@angular/core';
import { ApplicationRef, ComponentRef, Injector, ComponentFactory, Component, EventEmitter, Output } from '@angular/core';


import { ModalApproveComponent } from './modal-approve.component';

import { RootAppService } from '../../core/services/root/root-app.service';
import { VerifyRequest } from './standard-approve.model';

@Injectable()
export class StandardApproveService {

    viewContainerRef: ViewContainerRef;
    cRef: ComponentRef<ModalApproveComponent>;

    constructor(
        public componentFactoryResolver: ComponentFactoryResolver,
        public rootAppService: RootAppService
    ) {
        this.viewContainerRef = this.rootAppService.getViewContainerRef();
    }

    pushRequestApproveMessage(approveRequest: VerifyRequest) {
        const factory = this.componentFactoryResolver
            .resolveComponentFactory(ModalApproveComponent); // const => should not re-asigned again!
        if (this.viewContainerRef === undefined) {
            this.viewContainerRef = this.rootAppService.getViewContainerRef(); // We need this to avoid undefined error!
        }
        const ref = this.viewContainerRef.createComponent(factory); // const => should not re-asigned again!
        // viewContainerRef.remove();
        // ref.instance.isVisible = true; // Show Modal Dialog
        ref.instance.show(); // Show Modal Dialog
        ref.instance.aprRequest = approveRequest;
        ref.instance.mdOutput.subscribe(value => { // Output of Modal
            alert(value);
        });
        ref.instance.modalClose.subscribe(value => {
            this.viewContainerRef.remove(); // When modal open, it attach to the end of body
                                            // => we need to clean it after modal close to prevent memory leak!
        });

        ref.changeDetectorRef.detectChanges();
        this.cRef = ref;
    }

    // Close Modal Form
    close() {
        if (this.cRef !== undefined) {
            this.cRef.instance.close();
        }
    }

}
