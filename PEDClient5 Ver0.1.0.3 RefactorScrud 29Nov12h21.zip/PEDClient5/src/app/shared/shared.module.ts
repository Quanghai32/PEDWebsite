﻿import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common'; // (ngIf, ngFor...) => you have to import CommonModule
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; // [(ngModel)] => you have to import FormModule
import { RouterModule } from '@angular/router';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { standardCrudReducer } from './standard-crud/standardCrud.reducer';
import { StandardCrudEffects } from './standard-crud/standardCrud.effects';

import { NgxMyDatePickerModule } from 'ngx-mydatepicker';
import { DatePickerComponent } from './datePicker/date-picker.component';

import { MyPaginationComponent } from './pagination/my-pagination.component';

import { MyModalComponent } from './my-modal/my-modal.component';
import { ModalDialogComponent } from './my-modal/modal-dialog/modal-dialog.component';
import { ModalSearchComponent } from './my-modal/modal-search/modal-search.component';
import { MyModalService } from './my-modal/my-modal.service';

import { StandardApproveService } from './standardApprove/standard-approve.service';
import { ModalApproveComponent } from './standardApprove/modal-approve.component';

import { ScrudComponent } from './standard-crud/scrud/scrud.component';
import { ScrudDetailComponent } from './standard-crud/scrud-detail/scrud-detail.component';
import { ScrudEditComponent } from './standard-crud/scrud-edit/scrud-edit.component';
import { ScrudCreateComponent } from './standard-crud/scrud-create/scrud-create.component';
import { ScrudListComponent } from './standard-crud/scrud-list/scrud-list.component';
import { StandardCrudBackEndService } from './standard-crud/standardCrud-backend.service';
import { StandardCrudService } from './standard-crud/standardCrud.service';

import { DynamicFormComponent } from './dynamic-form/dynamic-form.component';
import { DynamicFormService } from './dynamic-form/dynamic-form.service';
import { MyFocusDirective } from './directives/myFocus.directive';


@NgModule({
    imports: [
        CommonModule, // (ngIf, ngFor...) => you have to import CommonModule
        FormsModule, // [(ngModel)] => you have to import FormModule
        RouterModule,
        ReactiveFormsModule,
        NgxMyDatePickerModule,
        StoreModule.forFeature('standardCrud', standardCrudReducer),
        EffectsModule.forFeature([StandardCrudEffects]),
    ],
    declarations: [
        MyFocusDirective,
        DatePickerComponent,
        ModalSearchComponent,
        DynamicFormComponent,
        ScrudComponent,
        ScrudDetailComponent,
        ScrudEditComponent,
        ScrudCreateComponent,
        ScrudListComponent,
        MyPaginationComponent,
        ModalApproveComponent,
        MyModalComponent,
        ModalDialogComponent,
        ModalSearchComponent
    ],
    entryComponents: [
        ModalApproveComponent,
        MyModalComponent
    ],
    exports: [
        CommonModule,
        RouterModule,
        FormsModule,
        ReactiveFormsModule,
        MyFocusDirective,
        MyPaginationComponent,
        DynamicFormComponent,
        ScrudComponent,
        ScrudDetailComponent,
        ScrudEditComponent,
        ScrudCreateComponent,
        ScrudListComponent,
        DatePickerComponent,
        MyModalComponent,
        ModalDialogComponent,
        ModalSearchComponent,
        ModalApproveComponent
    ],
    providers: [
    ]
})
export class SharedModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: SharedModule,
            providers: [
                // Providers
                MyModalService,
                DynamicFormService,
                StandardApproveService,
                StandardCrudService,
                StandardCrudBackEndService,
            ]
        };
    }
}
