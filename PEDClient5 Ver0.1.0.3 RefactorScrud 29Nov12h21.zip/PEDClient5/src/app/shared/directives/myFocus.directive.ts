﻿import { Directive, Input, EventEmitter, ElementRef, Renderer, Inject } from '@angular/core';

@Directive({
    selector: '[myfocus]'
})
export class MyFocusDirective {
    @Input('myfocus') myFocusEvent: EventEmitter<boolean>;

    constructor( @Inject(ElementRef) private element: ElementRef, private renderer: Renderer) {
        // element.nativeElement.style.backgroundColor = 'yellow';
        // element.nativeElement.focus();
    }

    ngOnInit() {
        this.myFocusEvent.subscribe(event => {
            this.renderer.invokeElementMethod(this.element.nativeElement, 'focus', []);
        });
    }
}
