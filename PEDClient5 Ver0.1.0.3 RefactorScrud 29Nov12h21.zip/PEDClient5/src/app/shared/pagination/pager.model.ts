﻿
export interface PagerModel {
    totalItems: number; // Total number items
    currentPage: number; // Current Page
    pageSize: number; // Page Size
    totalPages: number; // Total page number
    startPage: number; // Start Page number
    endPage: number;
    startIndex: number; // Diplay item on active page will start from this index
    endIndex: number; // Diplay item on active page will End by this index
    pages: any[]; // Contain all number will be display on pagination
}
