﻿
import { Component, OnInit, Input, Output, OnChanges, EventEmitter, ChangeDetectionStrategy } from '@angular/core';

import { PagerModel } from './pager.model';

@Component({
    selector: 'my-pagination',
    templateUrl: './my-pagination.component.html',
    styleUrls: ['./my-pagination.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class MyPaginationComponent implements OnInit, OnChanges {

    @Input() pagerIn: PagerModel;
    @Output() pagerOutEmit: EventEmitter<any> = new EventEmitter();


    // pager object
    public pager: PagerModel = <PagerModel>{};

    constructor(
    ) {
    }

    ngOnInit() {
        // initialize to page 1
        this.setPage(this.pagerIn.currentPage);
    }

    ngOnChanges() {
        // initialize to page 1
        this.setPage(this.pagerIn.currentPage);
    }

    setPage(page: number) {
        if (page < 1 || page > this.pager.totalPages) {
            return;
        }
        // get pager object from service
        this.pager = this.getPager(this.pagerIn.totalItems, page, this.pagerIn.pageSize);

        // Emit Output
        this.pagerOutEmit.emit(this.pager);
    }

    getPager(totalItems: number, currentPage: number = 1, pageSize: number = 5) {
        // calculate total pages
        const totalPages = Math.ceil(totalItems / pageSize);

        let startPage: number, endPage: number;
        if (totalPages <= 10) {
            // less than 10 total pages so show all
            startPage = 1;
            endPage = totalPages;
        } else {
            // more than 10 total pages so calculate start and end pages
            if (currentPage <= 6) {
                startPage = 1;
                endPage = 10;
            } else if (currentPage + 4 >= totalPages) {
                startPage = totalPages - 9;
                endPage = totalPages;
            } else {
                startPage = currentPage - 5;
                endPage = currentPage + 4;
            }
        }

        // calculate start and end item indexes
        const startIndex = (currentPage - 1) * pageSize;
        const endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);

        // create an array of pages to ng-repeat in the pager control
        // let pages = _.range(startPage, endPage + 1);
        const pages = [];
        let i: number;
        for (i = startPage; i < endPage + 1; i++) {
            pages.push(i);
        }

        // return object with all pager properties required by the view
        return <PagerModel>{
            totalItems: totalItems,
            currentPage: currentPage,
            pageSize: pageSize,
            totalPages: totalPages,
            startPage: startPage,
            endPage: endPage,
            startIndex: startIndex,
            endIndex: endIndex,
            pages: pages
        };
    }
}
