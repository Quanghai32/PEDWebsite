import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScrudEditComponent } from './scrud-edit.component';

describe('ScrudEditComponent', () => {
  let component: ScrudEditComponent;
  let fixture: ComponentFixture<ScrudEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScrudEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScrudEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
