﻿import { Action, ActionReducer } from '@ngrx/store';

import { StandardCrudState, StandardCrudInitialState } from './standardCrud.state';
import { StandardCrudViewModel, ViewMode, StandardDataInfo } from './standardCrud.model';

// import { StandardCrudActionTypes } from '../standardCrud/standardCrud.actions';
import { ScrudActionApproveInfo } from './standardCrud.model';

import { VerifyRequest, VerifyResult } from '../standardApprove/standard-approve.model';

import * as scrudAction from './standardCrud.actions';


export function standardCrudReducer(
  state = StandardCrudInitialState,
  action: scrudAction.Actions
): StandardCrudState {
  switch (action.type) {

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_SET_CRUD_APP_INFO:
        const newState = Object.assign({}, StandardCrudInitialState, { standardCrudAppInfo: action.payload });
        return newState;

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_GET_INFO_SUCCESS: // payload: standard crud model info
        return <StandardCrudState>Object.assign({}, state, {
            standardCrudInfo: action.payload
        });

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_GET_INFO_FAIL: // payload: error
        return state;

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ITEMS_SUCCESS:
        return Object.assign({}, state, {
            viewMode: ViewMode.viewList,
            standardCrudViewModels: action.payload.standardCrudViewModels,
            pagerModel: Object.assign({}, state.pagerModel, { currentPage: 1})
        });

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ITEMS_FAIL:
        return state;

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ROUTING_ITEM_INFO_SUCCESS:
        return Object.assign({}, state, {
            standardCrudItemInfo: action.payload
        });

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ROUTING_PAGING_ITEMS_SUCCESS:

        // We need to alter state with following things
        //  1. Page model => cal Page number which contains routing target item
        //  2. Selected object => view models need to mark it
        //  3. Selected object => assign
        const itemIndex = state.standardCrudItemInfo.index % 10;
        const testvms = <StandardCrudViewModel[]>(action.payload.standardCrudViewModels);
        const newViewModels = testvms.map((s, i) => (i !== itemIndex) ? s : Object.assign({}, { obj: s.obj, selected: true }));
        const selectedObj = newViewModels[itemIndex];

        return Object.assign({}, state, {
            viewMode: ViewMode.viewDetail,
            standardCrudViewModels: newViewModels,
            pagerModel: Object.assign({}, state.pagerModel, {
                currentPage: (Math.floor(state.standardCrudItemInfo.index / 10) + 1),
                startIndex: (Math.floor(state.standardCrudItemInfo.index / 10) + 1) * 10
            }),
            selectedObj: selectedObj
        });

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ITEMS_FAIL:
        return state;

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_GET_DATA_INFO_SUCCESS: // payload: standard crud data info
            // We need update both standardDataInfo & pagerModel
            const newPagerModel = Object.assign({}, state.pagerModel, { totalItems: (<StandardDataInfo>action.payload).total });

            return <StandardCrudState>Object.assign({}, state, { standardDataInfo: action.payload, pagerModel: newPagerModel });

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_GET_DATA_INFO_FAIL: // payload: error
        return state;

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_CHANGE_VIEW_MODE:
        return Object.assign({}, state, { viewMode: action.payload });

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_VIEW_LIST_SUCCESS:
        return Object.assign({}, state, {
            viewMode: ViewMode.viewList,
            standardCrudViewModels: action.payload.standardCrudViewModels,
            pagerModel: action.payload.pagerModel
        });

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_VIEW_LIST_FAIL:
        return state;

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_VIEW_LIST_SELECT:

        const objVM = action.payload;
        let newVM0s: any[];
        // Looking for primary key
        let primaryKey: string;
        state.standardCrudInfo.model.forEach((item, index) => {
            if ((item.type === 'item') && (item.propertyDescriptions[0].isPrimaryKey === true)) {
                primaryKey = item.propertyDescriptions[index].propertyName;
            }
        });

        newVM0s = state.standardCrudViewModels.map(standardCrudvm => {
            if (standardCrudvm.obj[primaryKey] === objVM.obj[primaryKey]) {
                return Object.assign({}, standardCrudvm, { selected: objVM.selected});
            }
            return standardCrudvm;
        });

        return Object.assign({}, state,
            {
                viewMode: ViewMode.viewList,
                standardCrudViewModels: newVM0s,
                selectedObj: objVM
            });

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_VIEW_LIST_PAGE_SELECT:
        return Object.assign({}, state, { pagerModel: action.payload });

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_GET_APPROVE_STATUS_SUCCESS:
        // alert('STANDARD_CRUD_GET_APPROVE_STATUS_SUCCESS');
        return Object.assign({}, state, { verifyResults: action.payload });

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_CREATE_SUCCESS:

        // Update new View Model to current state
        const newVM1s = state.standardCrudViewModels.map(item => item); // convert 'Object' to Array so 'push' is possible in runtime!
        newVM1s.push(Object.assign({}, { obj: action.payload, selected: false })); // push newVM

        // We need to find id of created item & create approve info if config
        const aprRequest = <VerifyRequest>{};
        if ((state.standardCrudInfo.approveModel !== undefined) &&
            (state.standardCrudInfo.approveModel !== null) &&
            (state.standardCrudInfo.approveModel.requireApprove === true)
        ) {
            // Looking for primary key
            let primKey: string;
            state.standardCrudInfo.model.forEach((item, index) => {
                if ((item.type === 'item') && (item.propertyDescriptions[0].isPrimaryKey === true)) {
                    primKey = item.propertyDescriptions[index].propertyName;
                }
            });
            const itemId = action.payload[primKey];
            //
            aprRequest.ObjectID = itemId;
            aprRequest.BackendLink = state.standardCrudAppInfo.apiLink;
            aprRequest.ApplicationName = state.standardCrudAppInfo.appName;
            aprRequest.ActionDescription = 'Create new item';
            aprRequest.FrontendLink = state.standardCrudAppInfo.frontEndLink + '/' + itemId;
        }

        return Object.assign({}, state, <StandardCrudState>{
            viewMode: ViewMode.viewList,
            standardCrudViewModels: newVM1s,
            approveRequest: aprRequest
        }); // newState

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_CREATE_FAIL:

        const test = action.payload;
        return state;

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_EDIT_SUCCESS:
        // Need to update with edited item
        let newObjectVM: StandardCrudViewModel;
        newObjectVM = { obj: action.payload, selected: true };
        // Looking for primary key
        let primaryKey2 = '';
        state.standardCrudInfo.model.forEach((item, index) => {
            if ((item.type === 'item') && (item.propertyDescriptions[0].isPrimaryKey === true)) {
                primaryKey2 = item.propertyDescriptions[index].propertyName;
            }
        });

        const newVM2s = state.standardCrudViewModels.map((item, index) => {
            return item.obj[primaryKey2] === newObjectVM.obj[primaryKey2] ? newObjectVM : item; // Becareful!!!
        });

        return <StandardCrudState>Object.assign({}, state, { standardCrudViewModels: newVM2s });

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_EDIT_FAIL:
        return state;

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_DELETE_SUCCESS:

        // Remove deleted item
        let standardCrudsVM: StandardCrudViewModel[];
        // Looking for primary key
        let primaryKey3: string;
        state.standardCrudInfo.model.forEach((item, index) => {
            if ((item.type === 'item') && (item.propertyDescriptions[0].isPrimaryKey === true)) {
                primaryKey3 = item.propertyDescriptions[index].propertyName;
            }
        });

        standardCrudsVM = state.standardCrudViewModels.filter(x => x.obj[primaryKey3] !== action.payload); // payload: id

        return Object.assign({}, state, { standardCrudViewModels: standardCrudsVM });

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_DELETE_FAIL:
        return state;

    // *****************************SEARCHING ITEMS*******************************************
    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_SEARCH_SUCCESS:
        return Object.assign({}, state, {
            viewMode: ViewMode.viewList,
            standardCrudViewModels: action.payload.standardCrudViewModels
        });

    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_SEARCH_FAIL:
        return state;

    // *****************************For Approve Actions*******************************************
    case scrudAction.StandardCrudActionTypes.STANDARD_CRUD_DO_APPROVE_SUCCESS:
        const tempState = Object.assign({}, state);
        const index = tempState.standardCrudViewModels.findIndex(vm => vm.selected === true);
        if ( index !== -1) {
            tempState.verifyResults[index] = action.payload;
        }
        return tempState;

    // ****************************************************************************************
    default: {
      return state;
    }
  }
}


