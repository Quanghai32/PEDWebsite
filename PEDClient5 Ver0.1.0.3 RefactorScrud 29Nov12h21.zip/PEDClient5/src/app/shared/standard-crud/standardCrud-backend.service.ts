﻿import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { AuthHttp } from 'angular2-jwt';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import * as appSetting from '../../app.setting';
import { ViewMode, StandardCrudAppInfo } from './standardCrud.model';
import { StandardCrudState } from './standardCrud.state';
import { VerifyResult } from '../standardApprove/standard-approve.model';

@Injectable()
export class StandardCrudBackEndService {
    private standardCrudAppInfo: StandardCrudAppInfo; // Url to Web Api

    // constructor(private authHttp: AuthHttp) {
    // }

    constructor(private http: HttpClient) {
    }

    setStandardCrudAppInfo(appInfoInput: StandardCrudAppInfo) {
        this.standardCrudAppInfo = appInfoInput;
    }

    // Get info of standard crud model from backend, so we need necessary info for redering dynamic form
    getStandardCrudInfo(): Observable<Object> {
        // return this.http.get(this.standardCrudAppInfo.apiLink + '/info', { search: this.standardCrudAppInfo.urlSearchParams });
        return this.http.get(this.standardCrudAppInfo.apiLink + '/info', {
            params: this.standardCrudAppInfo.urlSearchParams
        });
    }

    // Get total number of item in database
    getDataInfo(): Observable<Object> {
        return this.http.get(this.standardCrudAppInfo.apiLink + '/DataInfo', {
            params: this.standardCrudAppInfo.urlSearchParams
        });
    }

    // Get total number of item in database
    getItemInfo(itemId: string): Observable<Object> {
        // const params = new URLSearchParams();
        // if (this.standardCrudAppInfo.urlSearchParams !== undefined) {
        //     params.appendAll(this.standardCrudAppInfo.urlSearchParams);
        // }
        // params.set('itemId', itemId);

        return this.http.get(this.standardCrudAppInfo.apiLink + '/ItemInfo', {
            params: (this.standardCrudAppInfo.urlSearchParams !== undefined) ?
            this.standardCrudAppInfo.urlSearchParams.set('itemId', itemId) :
            new HttpParams().set('itemId', itemId)
        });
    }

    // Not get all items, but take some from them for pagination
    getSelectItems(offset: number, take: number): Observable<Object> {
        // const params = new URLSearchParams();
        // if (this.standardCrudAppInfo.urlSearchParams !== undefined) {
        //     params.appendAll(this.standardCrudAppInfo.urlSearchParams);
        // }

        // params.set('offset', offset.toString());
        // params.set('take', take.toString());
        return this.http.get(this.standardCrudAppInfo.apiLink, {
            params: (this.standardCrudAppInfo.urlSearchParams !== undefined) ?
            this.standardCrudAppInfo.urlSearchParams.set('offset', offset.toString())
                .set('take', take.toString()) :
                new HttpParams().set('offset', offset.toString()).set('take', take.toString())
        });
    }

    // Get Approve Status of list of items
    // Not get all items, but take some from them for pagination
    getApproveStatusItems(offset: number, take: number): Observable<Object> {
        // const params = new URLSearchParams();
        // if (this.standardCrudAppInfo.urlSearchParams !== undefined) {
        //     params.appendAll(this.standardCrudAppInfo.urlSearchParams);
        // }

        // params.set('offset', offset.toString());
        // params.set('take', take.toString());
        return this.http.get(this.standardCrudAppInfo.apiLink + '/VerifyResult', {
            params: (this.standardCrudAppInfo.urlSearchParams !== undefined) ?
            this.standardCrudAppInfo.urlSearchParams.set('offset', offset.toString())
                .set('take', take.toString()) :
                new HttpParams().set('offset', offset.toString()).set('take', take.toString())
        });
    }

    // Searching some items
    SearchItems(searchQuery: string, searchCriteria: string): Observable<Object> {
        // const params = new URLSearchParams();
        // if (this.standardCrudAppInfo.urlSearchParams !== undefined) {
        //     params.appendAll(this.standardCrudAppInfo.urlSearchParams);
        // }

        // params.set('searchQuery', searchQuery);
        // params.set('searchCriteria', searchCriteria);
        return this.http.get(this.standardCrudAppInfo.apiLink + '/Search', {
            params: (this.standardCrudAppInfo.urlSearchParams !== undefined) ?
             this.standardCrudAppInfo.urlSearchParams.set('searchQuery', searchQuery)
                .set('searchCriteria', searchCriteria) :
                new HttpParams().set('searchQuery', searchQuery).set('searchCriteria', searchCriteria)
        });
    }

    // Create new standardCrud
    postStandardCrud(model: any): Observable<Object> {
        const body = JSON.stringify(model);
        return this.http.post(this.standardCrudAppInfo.apiLink + '/', body, {
            params: this.standardCrudAppInfo.urlSearchParams
        });
    }

    // Edit standardCrud
    putStandardCrud(model: any): Observable<Object> {
        const body = JSON.stringify(model);
        return this.http.put(this.standardCrudAppInfo.apiLink, body, {
            params: this.standardCrudAppInfo.urlSearchParams
        });
    }

    deleteStandardCrud(id: any): Observable<Object> {
        return this.http.delete(`${this.standardCrudAppInfo.apiLink}/${id}`, {
            params: this.standardCrudAppInfo.urlSearchParams
        });
    }

    // Approve action
    doApprove(verifyResult: VerifyResult):  Observable<Object> { // VerifyResult
        const body = JSON.stringify(verifyResult);
        return this.http.put(
            appSetting.backendUrl + '/api/StandardApproves/VerifyResult', body, {
                params: this.standardCrudAppInfo.urlSearchParams
            });
    }

}
