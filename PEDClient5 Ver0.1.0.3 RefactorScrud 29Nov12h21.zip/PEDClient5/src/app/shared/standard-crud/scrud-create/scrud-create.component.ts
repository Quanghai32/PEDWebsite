//////////////////////////////////////////////////////////////////////////////////////////////////////////
// What is the point when using FormGroup? Why we need it if we can directly binding data to View?
//      1. Sometimes we need separate Data & View. A View normally need to display differently from data.
//          => In some case, we can simplify code on the view!
//      2. By using FormGroup, we can use validators easily
//      3. Easily handle submit data from form
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////

import { Component, Input, Output, EventEmitter, OnChanges, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import { DynamicFormService } from '../../dynamic-form/dynamic-form.service';
import { StandardCrudState } from '../standardCrud.state';

import { DynamicFormBase } from '../../dynamic-form/dynamic-form.model';
import { DynamicFormModelInfo } from '../../dynamic-form/dynamic-form.model';
import { ParentObjInfo } from '../../dynamic-form/dynamic-form.model';

import { ModalSearchSetting, ModalSearchOutput } from '../../my-modal/modal-search/modal-search.model';
import { MyModalService } from '../../my-modal/my-modal.service';


@Component({
  selector: 'app-scrud-create',
  templateUrl: './scrud-create.component.html',
  styleUrls: ['./scrud-create.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ScrudCreateComponent implements OnChanges {

  @Input() objectState: StandardCrudState; // The object want to edit
  @Output() newCreate: EventEmitter<any> = new EventEmitter();

  // Parent Object Info - Hold all information of Parent Object
  parentObjInfo: ParentObjInfo;

  //
  mdSetting: ModalSearchSetting;

  constructor(
      public dynamicFormService: DynamicFormService,
      public modalService: MyModalService,
      public cdRef: ChangeDetectorRef
  ) {
  }

  ngOnChanges() {

      // Create Model Info Object
      let modelInfo: DynamicFormModelInfo;
      modelInfo = Object.assign({}, {
          model: this.objectState.standardCrudInfo.model,
          obj: undefined, // Set to undefined, so in create new mode, we don't display current object value
                         // With item type: obj is a single object
                         // With list type: obj is an array of object (all object instances is same class type)
      });
      // Now, create elements info for display
      this.parentObjInfo = this.dynamicFormService.getParentObjectInfo(modelInfo);
      // Check all element Info, If element create new method is 'select' => remove 1st blank row
      this.parentObjInfo.deInfos.forEach(deInfo => {

          if (deInfo.elementDescription.type === 'list') {
              deInfo.dynamicFormBasess.splice(0, 1); // Remove from view
              const test = this.parentObjInfo.parentFG.get(deInfo.elementDescription.elementName) as FormArray;
              test.removeAt(0); // Remove from data send to backend
          }
      });
  }

  RemoveItem(listId: number, itemId: number) { // Remove item by Id of list
      //
      this.dynamicFormService.RemoveItemFromElementOfParentObject(
          this.parentObjInfo,
          listId,
          itemId
      );
  }

  AddItem(listId: number) { // Add more item to list with list ID input
      if (this.parentObjInfo.deInfos[listId].elementDescription.createMethod === 'select') { // Add item by select from existing entity
          // Ini for modal search dialog
          this.mdSetting = <ModalSearchSetting>{};
          this.mdSetting.source = 'AddItem';
          this.mdSetting.sourceID = listId;
          this.mdSetting.elDescription = this.parentObjInfo.deInfos[listId].elementDescription;
          //
          this.mdSetting.title = 'Search Item to Add';
          this.mdSetting.message = 'Please select items want to add to list.';
          // this.mdSetting.buttons = ['Add', 'Remove', 'Close'];
          this.mdSetting.isVisible = true;

          this.modalService.setSearchSetting(this.mdSetting);
          this.modalService.SearchPopUp('Test Search', 'body not show', ['Add', 'Close']);
          this.modalService.mdOutput.subscribe(value => {
              // alert(value);
              const testsearch = this.modalService.getSearchOutput();
              // alert(JSON.stringify(testsearch));
              if (value === 0) { // Add
                  const addObjects = testsearch
                  .filter(item => item.selected === true)
                  .map(item => item.obj);
                  // alert(addObjects);
                  this.AddListItemBySelect(this.mdSetting.sourceID, addObjects);
                  this.cdRef.detectChanges();
              } else if (value === 1 ) { // Close
                  this.modalService.close();
              }
          });

      } else { // Default Add item by Input info directly
          this.AddItemByInput(listId);
      }
  }

  AddItemByInput(listId: number) {

      this.dynamicFormService.AddItemToElementOfParentObject(
          this.parentObjInfo,
          this.objectState.standardCrudInfo.model[listId],
          listId,
          undefined
      );

  }

  AddListItemBySelect(listId: number, addObjects: any[]) {
      if (addObjects.constructor === Array) {
          addObjects.forEach(obj => {
              this.AddItemBySelect(listId, obj);
          });
      }
  }

  AddItemBySelect(listId: number, addObject: any[]) { // Add Item By select form existing list

      this.dynamicFormService.AddItemToElementOfParentObject(
          this.parentObjInfo,
          this.objectState.standardCrudInfo.model[listId],
          listId,
          addObject
      );

  }

  // In new create handle, all properties already convert to array of array (FormArray)
  // Before transfer to backend, we need to restore to original format
  restoreBackendModel(data: any): any { // data: this.parentObjInfo.parentFG.value
      const keys = Object.keys(data);
      const restoreData: any = {};
      keys.forEach((key, index) => {
          if (this.parentObjInfo.deInfos[index].elementDescription.type === 'list') {
              restoreData[key] = data[key]; // An array of item
          } else { // Default is 'item' => An item is an array which has only 1 item!
              restoreData[key] = ((<Array<any>>data[key])[0])[key]; // An array has only 1 item
          }
      });
      return restoreData;
  }


  onSubmit() {
      let test: any;
      test = this.parentObjInfo.parentFG.value;

      let test2: any;
      test2 = this.restoreBackendModel(test);

      this.newCreate.emit(test2);
  }


}
