import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScrudCreateComponent } from './scrud-create.component';

describe('ScrudCreateComponent', () => {
  let component: ScrudCreateComponent;
  let fixture: ComponentFixture<ScrudCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScrudCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScrudCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
