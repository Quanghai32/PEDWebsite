﻿
import { Injectable } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Actions, Effect, toPayload } from '@ngrx/effects';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/mapTo';
import 'rxjs/add/operator/withLatestFrom';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/ignoreElements'; // withLatestFrom
import 'rxjs/add/operator/withLatestFrom'; //
import 'rxjs/add/operator/filter'; //
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Store } from '@ngrx/store';

import { MyModalService } from '../my-modal/my-modal.service';
import { StandardApproveService } from '../standardApprove/standard-approve.service';

import { StandardCrudState } from './standardCrud.state';
import { StandardCrudBackEndService } from './standardCrud-backend.service';
import { StandardCrudActionTypes } from './standardCrud.actions';

import { ViewMode, StandardCrudAppInfo } from './standardCrud.model';
import { PagerModel } from '../pagination/pager.model';
import { SearchModel } from './standardCrud.model';

import * as scrudAction from './standardCrud.actions';
import * as fromState from './standardCrud.state';

@Injectable()
export class StandardCrudEffects {

    constructor(
        public store$: Store<any>,
        public actions$: Actions,
        public standardCrudBackEndService: StandardCrudBackEndService,
        public approveService: StandardApproveService,
        public modalService: MyModalService
    ) {
    }

    // Step1. Ini for scrud app, need to set app info first
    @Effect({dispatch: false})
    setApiLink$ = this.actions$
    .ofType(scrudAction.StandardCrudActionTypes.STANDARD_CRUD_SET_CRUD_APP_INFO)
    .map(toPayload)
    .do(payload => {
        this.standardCrudBackEndService.setStandardCrudAppInfo(payload);
    });

    // Step2. Get model info from backend
    @Effect()
    getModelInfo$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_GET_INFO)
        .map(toPayload)
        .switchMap(payload => this.standardCrudBackEndService.getStandardCrudInfo()
            // If successful, dispatch success action with result
            // .map((res) => {
            //     return res.json();
            // }) // return standardCruds info from backend
            .map((res) => new scrudAction.StandardCrudGetModelInfoSuccess(res)) // res: StandardCrud Info
            // If request fails, dispatch failed action
            .catch(error => Observable.of(new scrudAction.StandardCrudGetModelInfoFail(error)))
        );

    @Effect()
    getModelInfoSuccess$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_GET_INFO_SUCCESS)
        .map(toPayload) // payload: backend model info
        .withLatestFrom(this.store$)
        .switchMap(payload => {
            // Here we need to handle routing
            //  1. If user use default routing => get ini items from 0 -> 10 & turn to View List mode as normally
            //  2. But if user request routing target to certain item by ID:
            //      - We have to get info of that single item
            //      - The info about single item should include paging info also (indicate that item belong to what page)
            //      - Loading all items of that page
            //      - Turn to another view mode (Detail, Edit...) with
            const routingId = payload[1].standardCrud.standardCrudAppInfo.routingId;
            if (routingId !== null && routingId !== undefined) {
                // alert('from effects test routingId: ' + routingId);
                return Observable.of(new scrudAction.StandardCrudIniGetRoutingItemInfo(routingId));
            } else {
                // alert('from effects test: null');
                return Observable.of(new scrudAction.StandardCrudIniGetItems(undefined));
            }
        });

    @Effect({dispatch: false})
    getModelInfoFail$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_GET_INFO_FAIL)
        .map(toPayload) // action.payload: backend model info
        .do(payload => {
            this.modalService.MessageOut('Get Application Info fail', (<HttpErrorResponse>payload).status===403?'Warning: You do not have right to access here!':payload.error);
        });

    // Step3.1 (Routing case) Get items info from Routing handle => Get item info
    @Effect()
    iniGetItemInfo$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ROUTING_ITEM_INFO)
        .map(toPayload) //
        .switchMap(
        payload => this.standardCrudBackEndService.getItemInfo(payload)
            // .map((res) => {
            //     return res.json();
            // })
            .map((info) => new scrudAction.StandardCrudIniGetRoutingItemInfoSuccess(info)) // info: StandardCrudItemInfo
            // If request fails, dispatch failed action
            .catch(error => Observable.of(new scrudAction.StandardCrudIniGetRoutingItemInfoFail(error)))
        );

    @Effect() // If get item info success => we request backend to get all item of page which routing target item belong to
    iniGetItemInfoSuccess$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ROUTING_ITEM_INFO_SUCCESS)
        .map(toPayload) // StandardCrudItemInfo
        .map(
            payload => new scrudAction.StandardCrudIniGetRoutingPagingItem(payload)
        );

    @Effect() // If get item info success => we request backend to get all item of page which routing target item belong to
    iniGetRoutingPagingItems$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ROUTING_PAGING_ITEMS)
        .map(toPayload) // StandardCrudItemInfo
        .switchMap(
        payload => this.standardCrudBackEndService.getSelectItems(Math.floor(payload.index / 10) * 10, 10) // Get default 10 items
            // If successful, dispatch success action with result
            // .map((res) => {
            //     return res.json();
            // }) // Objects
            .map((res: any[]) => {
                return res.map(stat => ({ obj: stat, selected: false })); // ViewModels
            }) // return StandardCrudViewModels - target object view model (+selected property)
            .map((res) => ({ viewMode: ViewMode.viewList, standardCrudViewModels: res })) // return StandardCrudState
            .map((data) => new scrudAction.StandardCrudIniGetRoutingPagingItemSuccess(data)) // res: StandardCrud State
            // If request fails, dispatch failed action
            .catch(error => Observable.of(new scrudAction.StandardCrudIniGetRoutingPagingItemFail(error)))
        );

    @Effect()
    iniGetIniRoutingPagingItemsSuccess$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ROUTING_PAGING_ITEMS_SUCCESS)
        .map(toPayload) //
        .switchMap(payload => Observable.of(new scrudAction.StandardCrudGetDataInfo(undefined))
        );


    // Step3.2 (Normal routing case) => get 10 first items
    @Effect()
    iniGetItems$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ITEMS)
        .map(toPayload) // PagerModel
        .switchMap(
            payload => this.standardCrudBackEndService.getSelectItems(0, 10) // Get default first 10 items
            // If successful, dispatch success action with result
            // .map((res) => {
            //     return res.json();
            // }) // return standardCruds - target object model
            .map((res: any[]) => {
                return res.map(stat => ({ obj: stat, selected: false }));
            }) // return StandardCrudViewModels - target object view model (+selected property)
            .map((res) => ({ viewMode: ViewMode.viewList, standardCrudViewModels: res})) // return StandardCrudState
            .map((res) => new scrudAction.StandardCrudIniGetItemsSuccess(res)) // res: StandardCrud State
            // If request fails, dispatch failed action
            .catch(error => Observable.of(new scrudAction.StandardCrudIniGetItemsFail(error)))
        );

    @Effect()
    iniGetItemsSuccess$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ITEMS_SUCCESS)
        .map(toPayload) //
        .switchMap(payload => Observable.of(new scrudAction.StandardCrudGetDataInfo(undefined))
        );

    @Effect()
    iniGetItemsFail$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ITEMS_FAIL)
        .map(toPayload) //
        .do(payload => {
            this.modalService.MessageOut('Get list item fail', <HttpErrorResponse>payload.error);
        })
        .ignoreElements();


    // ****************************************************************************************************

    // Step4. Get Data info (number of record...) from backend (to display total number of items)
    @Effect()
    getDataInfo$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_GET_DATA_INFO)
        .map(toPayload)
        .switchMap(payload => this.standardCrudBackEndService.getDataInfo()
            // If successful, dispatch success action with result
            // .map((res) => {
            //     return res.json();
            // }) // return Data info from backend
            .map((res) => new scrudAction.StandardCrudGetDataInfoSuccess(res)) // res: StandardCrud Data Info
            // If request fails, dispatch failed action
            .catch(error => Observable.of(new scrudAction.StandardCrudGetDataInfoFail(error)))
        );

    @Effect()
    getDataInfoFail$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_GET_DATA_INFO_FAIL)
        .map(toPayload) // action.payload: Http Response
        .do(payload => {
            this.modalService.MessageOut('Get application data information fail', <HttpErrorResponse>payload.error);
        })
        .ignoreElements();


    // Step5. View list handle (when user click on View List mode or Paging number click handle)
    @Effect()
    viewList$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_VIEW_LIST)
        .map(toPayload) // PagerModel
        .switchMap(
            payload => this.standardCrudBackEndService.getSelectItems(payload.startIndex, payload.pageSize)
            // If successful, dispatch success action with result
            // .map((res) => {
            //     return res.json();
            // }) // return standardCruds - target object model
            .map((res: any[]) => {
                return res.map(stat => ({ obj: stat, selected: false }));
            }) // return StandardCrudViewModels - target object view model (+selected property)
            .map((res) => ({ viewMode: ViewMode.viewList, standardCrudViewModels: res, pagerModel: payload})) // StandardCrudState
            .map((res) => new scrudAction.StandardCrudViewListSuccess(res)) // res: StandardCrud State
            // If request fails, dispatch failed action
            .catch(error => Observable.of(new scrudAction.StandardCrudViewListFail(error)))
        );

    // If view list success, then we load approve status if necessary
    @Effect()
    viewListSuccess$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_VIEW_LIST_SUCCESS,
            StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ITEMS_SUCCESS,
            StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ROUTING_ITEM_INFO_SUCCESS
        )
        .withLatestFrom(this.store$)
        .filter(([action, state]) =>
            (state.standardCrud.standardCrudInfo.approveModel !== null) && // initial state is already assigned to null, not undefined
            (state.standardCrud.standardCrudInfo.approveModel.requireApprove === true) // Approve is required?
        )
        .switchMap(
            payload => this.standardCrudBackEndService.getApproveStatusItems(
                (<PagerModel>payload[1].standardCrud.pagerModel).startIndex,
                (<PagerModel>payload[1].standardCrud.pagerModel).pageSize
            )
            // If successful, dispatch success action with result
            // .map((res) => {
            //     return res.json();
            // }) // List of BackendApproveStatus
            .map((res) => new scrudAction.StandardCrudGetApproveStatusSuccess(res)) // List of BackendApproveStatus
            // If request fails, dispatch failed action
            .catch(error => Observable.of(new scrudAction.StandardCrudGetApproveStatusFail(error)))
        );

    @Effect()
    viewListFail$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_VIEW_LIST_FAIL)
        .map(toPayload) // action.payload: Http Response
        .do(payload => {
            this.modalService.MessageOut('Get list item to view fail', <HttpErrorResponse>payload.error);
        })
        .ignoreElements();

    @Effect()
    createStandardCrud$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_CREATE)
        .map(toPayload)
        .switchMap(payload => this.standardCrudBackEndService.postStandardCrud(payload)
            // If successful, dispatch success action with result
            // .map((res) => new scrudAction.StandardCrudCreateSuccess(payload))
            .map((res) => new scrudAction.StandardCrudCreateSuccess(res))
            // If request fails, dispatch failed action
            .catch(error => Observable.of(new scrudAction.StandardCrudCreateFail(error)))
        );

    @Effect()
    createSuccess$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_CREATE_SUCCESS)
        .map(toPayload) // action.payload: backend model info
        // Update number of items in list view mode
        .switchMap(payload => Observable.of(new scrudAction.StandardCrudGetDataInfo(undefined))
        );

    @Effect()
    createSuccessThenRequestApprove$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_CREATE_SUCCESS)
        // .map(action => action.payload) //action.payload: backend model info
        .withLatestFrom(this.store$)
        .filter(([action, state]) =>
            (state.standardCrud.standardCrudInfo.approveModel !== null) && // initial state is already assigned to null, not undefined
            (state.standardCrud.standardCrudInfo.approveModel.requireApprove === true) // Approve is required?
        )
        .switchMap(payload => Observable.of(
            new scrudAction.StandardCrudRequestApprove(payload[1].standardCrud.approveRequest)
        ));

    @Effect({ dispatch: false })
    requestApprove$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_REQUEST_APPROVE)
        .map(toPayload) // BackendApproveStatus
        .do(payload => {
            // alert('request approve');
            this.approveService.pushRequestApproveMessage(payload); // BackendApproveStatus
        })
        .ignoreElements();

    @Effect()
    createFail$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_CREATE_FAIL)
        .map(toPayload) // action.payload: Http Response
        .do(payload => {
                this.modalService.MessageOut('Create Fail', <HttpErrorResponse>payload.error , ['OK']); // payload.json()
                this.modalService.mdOutput
                .subscribe(value => {
                    // alert('effects STANDARD_CRUD_CREATE_FAIL: ' + value);
                    if (value === 0) {
                        this.modalService.close();
                    }
                });
        })
        .ignoreElements();

    @Effect()
    editStandardCrud$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_EDIT)
        .map(toPayload) // payload: StandardCrud
        .switchMap(payload => this.standardCrudBackEndService.putStandardCrud(payload)
            // If successful, dispatch success action with result
            .map((res) => new scrudAction.StandardCrudEditSuccess(res)) // res.json()
            // If request fails, dispatch failed action
            .catch(error => Observable.of(new scrudAction.StandardCrudEditFail(error)))
        );

    @Effect()
    editStandardCrudSuccess$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_EDIT_SUCCESS)
        .map(toPayload) // payload: StandardCrud
        .switchMap(payload => Observable.of(new scrudAction.StandardCrudChangeViewMode(ViewMode.viewList)));

    @Effect()
    editStandardCrudFail$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_EDIT_FAIL)
        .map(toPayload) // action.payload: Http Response
        .do(payload => {
            this.modalService.MessageOut('Edit Item Error', <HttpErrorResponse>payload.error);
        })
        .ignoreElements();


    @Effect()
    deleteConfirm$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_DELETE_CONFIRM)
        .map(toPayload) // payload: need  to be Primary key!!!
        .do(payload => {
            this.modalService.MessageOut('Delete Confirm',
                'Do you really want to delete this item?',
                ['DELETE', 'CANCEL']
            );
            this.modalService.mdOutput.subscribe(value => {
                if (value === 0) { // Delete
                    // alert(payload);
                    this.store$.dispatch(new scrudAction.StandardCrudDelete(payload));
                }
                this.modalService.close();
            });
        })
        .ignoreElements();

    @Effect()
    delete$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_DELETE)
        .map(toPayload) // payload: need  to be Primary key!!!
        .switchMap(payload => this.standardCrudBackEndService.deleteStandardCrud(payload) // payload: id
            // If successful, dispatch success action with result
            .map((res) => new scrudAction.StandardCrudDeleteSuccess(payload)) // payload: id
            // If request fails, dispatch failed action
            .catch(error => Observable.of(new scrudAction.StandardCrudDeleteFail(error)))
        );

    @Effect()
    deleteSuccess$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_DELETE_SUCCESS)
        .map(toPayload) // action.payload: backend model info
        .switchMap(payload => Observable.of(new scrudAction.StandardCrudGetDataInfo(undefined))
        );

    @Effect()
    deleteFail$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_DELETE_FAIL)
        .map(toPayload) // action.payload: Http Response
        .do(payload => {
            this.modalService.MessageOut('Delete Item Error', <HttpErrorResponse>payload.error);
        })
        .ignoreElements();

    // ******************************FOR SEARCHING ITEM******************************************
    @Effect()
    startSearch$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_SEARCH)
        .map(toPayload) // SearchModel
        .switchMap(
        payload => this.standardCrudBackEndService.SearchItems(payload.searchQuery, payload.searchCriteria)
            // If successful, dispatch success action with result
            // .map((res) => {
            //     return res.json();
            // }) // return standardCruds - target object model
            .map((res: any[]) => {
                return res.map(stat => ({ obj: stat, selected: false }));
            }) // return StandardCrudViewModels - target object view model (+selected property)
            .map((res) => ({ viewMode: ViewMode.viewList, standardCrudViewModels: res })) // return a part of StandardCrudState
            .map((res) => new scrudAction.StandardCrudSearchSuccess(res)) // res: a part of StandardCrud State
            // If request fails, dispatch failed action
            .catch(error => Observable.of(new scrudAction.StandardCrudSearchFail(error)))
        );

    @Effect()
    searchFail$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_SEARCH_FAIL)
        .map(toPayload) // action.payload: Http Response
        .do(payload => {
            this.modalService.MessageOut('Searching Item Error', <HttpErrorResponse>payload.error);
        })
        .ignoreElements();

    // ************************ For Approve Action ************************
    @Effect()
    doApprove$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_DO_APPROVE)
        .map(toPayload) // BackendApproveStatus
        .switchMap(
            payload => this.standardCrudBackEndService.doApprove(payload) // BackendApproveStatus
            // If successful, dispatch success action with result
            .map((res) => new scrudAction.StandardCrudDoApproveSuccess(payload)) // BackendApproveStatus
            // If request fails, dispatch failed action
            .catch(error => Observable.of(new scrudAction.StandardCrudErrorMessage(error)))
        );

    @Effect({ dispatch: false })
    doApproveOK$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_DO_APPROVE_SUCCESS)
        .map(toPayload) //
        .do(
            // payload => this.modalService.MessageOut('Error Message', JSON.stringify(payload))
            payload => this.modalService.MessageOut('Approve Action', 'Do Approve Ok!')
        )
        .ignoreElements();

    // ************************ For Common Error Message ************************
    @Effect({ dispatch: false })
    errorMessage$ = this.actions$
        .ofType(StandardCrudActionTypes.STANDARD_CRUD_ERR_MESSAGE)
        .map(toPayload) //
        .do(
            // payload => this.modalService.MessageOut('Error Message', JSON.stringify(payload))
            payload => this.modalService.MessageOut('Error Message', <HttpErrorResponse>payload.error)
        )
        .ignoreElements();

}
