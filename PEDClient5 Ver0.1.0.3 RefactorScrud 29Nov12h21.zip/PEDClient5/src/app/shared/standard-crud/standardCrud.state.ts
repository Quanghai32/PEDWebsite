﻿import { PagerModel } from '../pagination/pager.model';
import {
    StandardCrudAppInfo,
    StandardCrudInfo,
    StandardDataInfo,
    StandardCrudItemInfo,
    ScrudActionApproveInfo,
    StandardCrudViewModel,
    ViewMode
} from './standardCrud.model';
import { createSelector, createFeatureSelector } from '@ngrx/store';

import { VerifyRequest, VerifyResult } from '../standardApprove/standard-approve.model';

export interface StandardCrudState {
    standardCrudAppInfo: StandardCrudAppInfo;
    standardCrudInfo: StandardCrudInfo;
    standardDataInfo: StandardDataInfo;
    standardCrudItemInfo: StandardCrudItemInfo; // For routing with target item
    approveRequest: VerifyRequest; // For only item selected (current selecting item)
    verifyResults: VerifyResult[]; // list of backend approve status of all items
    viewMode: ViewMode;
    standardCrudViewModels: StandardCrudViewModel[];
    selectedObj: StandardCrudViewModel;
    pagerModel: PagerModel;
}

export const StandardCrudInitialState: StandardCrudState = {
    standardCrudAppInfo: <StandardCrudAppInfo>{},
    standardCrudInfo: <StandardCrudInfo>{},
    standardDataInfo: <StandardDataInfo>{},
    standardCrudItemInfo: <StandardCrudItemInfo>{}, // For routing with target item
    approveRequest: <VerifyRequest>{},
    verifyResults: <VerifyResult[]>{},
    viewMode: ViewMode.viewList,
    standardCrudViewModels: <StandardCrudViewModel[]>{},
    selectedObj: <StandardCrudViewModel>{},
    pagerModel: <PagerModel>{
        pageSize : 10,
        startIndex: 0
    }
};

export const getScrudState = createFeatureSelector<StandardCrudState>('standardCrud');
