﻿import { Injectable } from '@angular/core';
import { Headers, Response, RequestOptions } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

// import { AppState } from '../../app-store';
import { StandardCrudViewModel, ViewMode, StandardCrudAppInfo } from './standardCrud.model';
import { StandardCrudState } from './standardCrud.state';
// import { StandardCrudActions } from './standardCrud.actions';
import * as scrudAction from './standardCrud.actions';
import * as fromState from './standardCrud.state';

import { PagerModel } from '../pagination/pager.model';
import { SearchModel } from './standardCrud.model';
import { VerifyResult } from '../standardApprove/standard-approve.model';
import { MyModalService } from '../my-modal/my-modal.service';

@Injectable()
export class StandardCrudService {

    public standardCrudState$: Observable<StandardCrudState>;

    constructor(
        public store$: Store<StandardCrudState>,
        public modalService: MyModalService
    ) {
        this.standardCrudState$ = store$.select(fromState.getScrudState);
    }

    // Set StandardCrud App Info
    setAppInfo(appInfoInput: StandardCrudAppInfo) {
        this.store$.dispatch(new scrudAction.StandardCrudSetAppInfo(appInfoInput));
    }

    // Collect info of objective model
    // (properties name - type - display type...)
    getModelInfo() {
        this.store$.dispatch(new scrudAction.StandardCrudGetModelInfo(undefined));
    }

    // Switch view mode (view list - view create new - view Edit - View Detail)
    changeViewMode(viewMode: ViewMode) {
        this.store$.dispatch(new scrudAction.StandardCrudChangeViewMode(viewMode));
    }

    StandardCrudViewList(pagerModel: PagerModel) {
        this.store$.dispatch(new scrudAction.StandardCrudViewList(pagerModel));
    }

    // When user click to select an item on view list => Update to store
    viewListSelect(standardCrudVM: StandardCrudViewModel) {
        this.store$.dispatch(new scrudAction.StandardCrudViewListSelect(standardCrudVM));
    }

    // User select page handle on View List mode
    selectPageHandle(pagerModel: PagerModel) {
        // When user select new Page Item => we need to request Back-end & take new list of Items
        this.StandardCrudViewList(pagerModel);
    }

    // User request search handle on View List Mode
    searchRequestHandle(searchModel: SearchModel) {
        this.store$.dispatch(new scrudAction.StandardCrudSearch(searchModel));
    }


    // Create new objective item
    createItem(newStandardCrud: any) {
        this.store$.dispatch(new scrudAction.StandardCrudCreate(newStandardCrud));
    }

    // Handle Edit process => Update Database
    editItem(editedStandardCrud: any) {
        this.store$.dispatch(new scrudAction.StandardCrudEdit(editedStandardCrud));
    }

    // Confirm Delete
    deleteConfirm() {
        let currentState: StandardCrudState;
        currentState = this.getStateValue();

        // Looking for primary key
        let primaryKey: string;
        currentState.standardCrudInfo.model.forEach((item, index) => {
            if ((item.type === 'item') && (item.propertyDescriptions[0].isPrimaryKey === true)) {
                primaryKey = item.propertyDescriptions[index].propertyName;
            }
        });

        // alert(currentState.selectedObj.obj[primaryKey]);

        this.store$.dispatch(new scrudAction.StandardCrudDeleteConfirm(currentState.selectedObj.obj[primaryKey]));
    }

    // Delete selected item (only 1)
    deleteItem() {
        let currentState: StandardCrudState;
        currentState = this.getStateValue();

        // Looking for primary key
        let primaryKey: string;
        currentState.standardCrudInfo.model.forEach((item, index) => {
            if ((item.type === 'item') && (item.propertyDescriptions[0].isPrimaryKey === true)) {
                primaryKey = item.propertyDescriptions[index].propertyName;
            }
        });

        // this.store$.dispatch(new scrudAction.StandardCrudDelete(currentState.selectedObj.obj));
        this.store$.dispatch(new scrudAction.StandardCrudDelete(currentState.selectedObj.obj[primaryKey]));
    }

    // When approver want to do approve action, handle here
    approveHandle(actionName: string) {
        // alert(actionName);
        let currentState: StandardCrudState;
        currentState = this.getStateValue();

        let approve: VerifyResult;
        if (this.getSelectedItemIndex() !== -1) {
            approve = currentState.verifyResults[this.getSelectedItemIndex()];
            approve.Result = actionName;
            this.store$.dispatch(new scrudAction.StandardCrudDoApprove(approve)); // payload: VerifyResult
        } else {
            this.modalService.MessageOut('No item select', 'Please select 1 item first!' );
        }
    }

    // Get current state value
    getStateValue(): StandardCrudState {
        let currentState: StandardCrudState;
        this.standardCrudState$.take(1).subscribe(s => currentState = s);
        return currentState;
    }

    // Get state observable stream
    getState(): Observable<StandardCrudState> {
        return this.standardCrudState$;
    }

    // Searching selected item index
    getSelectedItemIndex(): number {
        const currentState = this.getStateValue();
        const index = currentState.standardCrudViewModels.findIndex(vm => vm.selected === true);
        return index;
    }

}
