
import { Component, Input, Output, EventEmitter, OnInit, OnChanges, OnDestroy, AfterViewInit } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/take';

import { LogInService } from '../../../login/log-in.service';

import { ScrudDetailComponent } from '../scrud-detail/scrud-detail.component';
import { ScrudEditComponent } from '../scrud-edit/scrud-edit.component';
import { ScrudCreateComponent } from '../scrud-create/scrud-create.component';
import { ScrudListComponent } from '../scrud-list/scrud-list.component';

import { StandardCrudViewModel } from '../standardCrud.model';
import { ViewMode, StandardCrudAppInfo } from '../standardCrud.model';
import { StandardCrudState } from '../standardCrud.state';
import { StandardCrudService } from '../standardCrud.service';

import { StandardCrudActionTypes } from '../standardCrud.actions';
// For pagination
import { PagerModel } from '../../pagination/pager.model';
import { SearchModel } from '../standardCrud.model';

import { StandardApproveService } from '../../standardApprove/standard-approve.service';

@Component({
  selector: 'app-scrud',
  templateUrl: './scrud.component.html',
  styleUrls: ['./scrud.component.css']
})
export class ScrudComponent implements OnChanges, OnInit, OnDestroy, AfterViewInit {

  enumViewMode = ViewMode;
  standardCrudState$: Observable<StandardCrudState>;

  // Setting for each application
  standardCrudAppName = 'Stardard CRUD Application';
  @Input() appInfoInput: StandardCrudAppInfo; // Object Input hold app name & api link. {appName:...,apiLink:...}
  @Output() userLinkHandle: EventEmitter<any> = new EventEmitter();

  private subscriptions: Subscription[];

  constructor(
      private logInService: LogInService,
      private standardCrudService: StandardCrudService,
      private approveService: StandardApproveService
  ) {
      this.subscriptions = [];
      this.standardCrudState$ = this.standardCrudService.getState();
  }

  ngOnInit() {
      // this.logInService.checkLastTokenValid();
      if (this.appInfoInput !== undefined) {
          // this.standardCrudIni(this.appInfoInput.appName, this.appInfoInput.apiLink); //Set BackEnd Api Link
          this.standardCrudIni(this.appInfoInput); // setting for backend api http

          this.standardCrudService.getModelInfo(); // Get Info from BackEnd

          // Here we need to handle routing
          //  1. If user use default routing => get ini items from 0 -> 10 & turn to View List mode as normally
          //  2. But if user request routing target to certain item by ID:
          //      - We have to get info of that single item
          //      - The info about single item should include paging info also (indicate that item belong to what page)
          //      - Loading all items of that page
          //      - Turn to another view mode (Detail, Edit...) with
          // Not Handle here, but in effects?
      }
  }

  ngAfterViewInit() {
      // this.standardApproveService.testInjectView()
  }

  ngOnChanges() {
      // alert('ngOnChanges(): ' + this.appInfoInput.appName);
      this.ngOnInit();
  }

  // On destroy, we unsubscribe to get rid of memory leak
  ngOnDestroy() {
      this.subscriptions.forEach(s => s.unsubscribe());
  }

  get pagerModel(): PagerModel {
      return this.standardCrudService.getStateValue().pagerModel;
  }

  // This function setting for each individual app
  standardCrudIni(appInfoInput: StandardCrudAppInfo) {
      this.standardCrudAppName = appInfoInput.appName;
      this.standardCrudService.setAppInfo(appInfoInput);
  }

  ChangeViewMode(viewMode: ViewMode) {
      this.standardCrudService.changeViewMode(viewMode);
  }

  // Handle user select item on view list mode
  changeOptionHandle(objectVM: any) {
      const newStandardCrudVM = Object.assign({}, <StandardCrudViewModel>{ obj: objectVM.obj, selected: objectVM.selected });
      this.standardCrudService.viewListSelect(newStandardCrudVM);
  }

  // Handle user select new page
  selectPageHandle(pagerModel: PagerModel) {
      this.standardCrudService.selectPageHandle(pagerModel);
  }

  // Handle user search action
  searchRequestHandle(searchModel: SearchModel) {
      this.standardCrudService.searchRequestHandle(searchModel);
  }

  newCreateHandle(newStandardCrud: any) {
      this.standardCrudService.createItem(newStandardCrud);
  }

  // Handle Edit process => Update Database
  newEditHandle(editedStandardCrud: any) {
      this.standardCrudService.editItem(editedStandardCrud);
  }

  // Hanle Edit click => Change to Edit view
  editStandardCrudHandle() {
      this.standardCrudService.changeViewMode(ViewMode.viewEdit);
  }

  detailStandardCrudHandle() {
      this.standardCrudService.changeViewMode(ViewMode.viewDetail);
  }

  delStandardCrudHandle() {
      this.standardCrudService.deleteConfirm();
  }

  get isApproveRequired(): boolean {
      let currentState = <StandardCrudState>{};
      this.standardCrudState$.take(1).subscribe(s => currentState = s);

      try { // prevent undefined
          return currentState.standardCrudInfo.approveModel.requireApprove;
      } catch (error) {
          return false;
      }
  }

  requestApprove(actionName: string) {
      let currentState = <StandardCrudState>{};
      this.standardCrudState$.take(1).subscribe(s => currentState = s);
      this.approveService.pushRequestApproveMessage(currentState.approveRequest);
  }

  approveHandle(actionName: string) {
      // alert(actionName);
      this.standardCrudService.approveHandle(actionName);
  }

  userLinkStandardCrudHandle() {
      // alert('userLinkStandardCrudHandle()');
      const currentState = this.standardCrudService.getStateValue();
      // Emit event
      this.userLinkHandle.emit(currentState);
  }

}
