import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScrudComponent } from './scrud.component';

describe('ScrudComponent', () => {
  let component: ScrudComponent;
  let fixture: ComponentFixture<ScrudComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScrudComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScrudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
