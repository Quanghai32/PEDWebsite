﻿// import { URLSearchParams } from '@angular/http';
import { HttpParams } from '@angular/common/http';

import { DynamicFormBase, ElementDescription, ParentObjInfo } from '../dynamic-form/dynamic-form.model';
import { PagerModel } from '../pagination/pager.model';
import { BackendApproveSetting } from '../standardApprove/standard-approve.model';

export interface ScrudActionApproveInfo { // Create in frontend with CRUD actions
    actionName: string; // Name of action need to approve: Create new, Edit, Delete...
    itemId: any; // Id of target item
}

export interface StandardCrudViewModel {
    obj: any; // The model of object to work with
    selected: boolean; // Indicate user select action status with object obj
}

export interface StandardCrudViewList {
    parentObjInfos: ParentObjInfo[]; // contains all info of list of parent object (each parent object is an object in list of application)
    selected: boolean[]; // Array indicate what item was selected by user in view list
}

export interface StandardCrudAppInfo {
    appName: string; // The name of application will display on view
    apiLink: string; // The API link for access api controller to get data
    urlSearchParams: HttpParams; // List of user parameters => use to add necessary info send to backend
    frontEndLink: string; // The url link of application (routing address)
    userRouterLinks: StandardCrudUserRouterLink[]; // Use to add more option on Control panel of StandardCrud App

    // Handle Routing
    routingViewMode: string; // routing required what view mode
    routingId: string; // If routing require ID => What ID?
}

export interface StandardCrudUserRouterLink {
    displayName: string;
    userLink: string;
    userParam: any;
}

export interface StandardCrudInfo {
    model: ElementDescription[]; // contains model's propeties info list
    approveModel: BackendApproveSetting;
}

export interface StandardDataInfo {
    total: number; // Total number of item in data table
}

export interface StandardCrudItemInfo { // When do routing with 1 target certain item
    id: any; // Id of item
    total: number; // Total number of item in data table
    index: number; // Index of Item in all list
}

export enum ViewMode {
    viewList,
    viewCreate,
    viewEdit,
    viewDetail
}

export interface SearchModel {
    searchQuery: string; // User Input search content
    searchCriteria: string; // Criteria of searching
}
