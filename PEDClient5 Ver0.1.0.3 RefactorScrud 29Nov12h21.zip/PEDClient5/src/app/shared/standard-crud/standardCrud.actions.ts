﻿import { type } from '../../util/action-name-helper';
import { Action } from '@ngrx/store';
import { Injectable } from '@angular/core';

import { StandardCrudInfo, StandardDataInfo, StandardCrudAppInfo } from './standardCrud.model';
import { PagerModel } from '../pagination/pager.model';
import { SearchModel } from './standardCrud.model';
import { VerifyResult } from '../standardApprove/standard-approve.model';

export const StandardCrudActionTypes = {

    // ***************************Do only 1 time when component ini***********************************************************
    // Setting App Info
    STANDARD_CRUD_SET_CRUD_APP_INFO: type('[StandardCrud] SetCrudAppInfo'), // 1st action - Do only 1 time when ini component

    // Getting standard crud model info from backend
    STANDARD_CRUD_GET_INFO: type('[StandardCrud] GetInfo'), // 2nd action - Do only 1 time when ini component
    STANDARD_CRUD_GET_INFO_SUCCESS: type('[StandardCrud] GetInfoSuccess'),
    STANDARD_CRUD_GET_INFO_FAIL: type('[StandardCrud] GetInfoFail'),

    // After get Model Info success from backend => Do ini load items with default setting (Get first 10 items, Offset = 0)
    STANDARD_CRUD_INI_GET_ITEMS: type('[StandardCrud] IniGetItems'), // 2nd action - Do only 1 time when ini component
    STANDARD_CRUD_INI_GET_ITEMS_SUCCESS: type('[StandardCrud] IniGetItemsSuccess'),
    STANDARD_CRUD_INI_GET_ITEMS_FAIL: type('[StandardCrud] IniGetItemsFail'),

    // If user use Routing target to certain item by ID => we need to handle it!
    STANDARD_CRUD_INI_GET_ROUTING_ITEM_INFO: type('[StandardCrud] IniGetRoutingItemInfo'), // 2nd action - Do only 1 time when ini component
    STANDARD_CRUD_INI_GET_ROUTING_ITEM_INFO_SUCCESS: type('[StandardCrud] IniGetRoutingItemInfoSuccess'),
    STANDARD_CRUD_INI_GET_ROUTING_ITEM_INFO_FAIL: type('[StandardCrud] IniGetRoutingItemInfoFail'),
    // 2nd action - Do only 1 time when ini component
    STANDARD_CRUD_INI_GET_ROUTING_PAGING_ITEMS: type('[StandardCrud] IniGetRoutingPagingItems'),
    STANDARD_CRUD_INI_GET_ROUTING_PAGING_ITEMS_SUCCESS: type('[StandardCrud] IniGetRoutingPagingItemsSuccess'),
    STANDARD_CRUD_INI_GET_ROUTING_PAGING_ITEMS_FAIL: type('[StandardCrud] IniGetRoutingPagingItemsFail'),

    // *************************************************************************************************************************
    // Get Data table Info
    STANDARD_CRUD_GET_DATA_INFO: type('[StandardCrud] GetDataInfo'), // 3rd action - Do only each time if
    STANDARD_CRUD_GET_DATA_INFO_SUCCESS: type('[StandardCrud] GetDataInfoSuccess'),
    STANDARD_CRUD_GET_DATA_INFO_FAIL: type('[StandardCrud] GetDataInfoFail'),

    // Change View Mode
    STANDARD_CRUD_CHANGE_VIEW_MODE: type('[StandardCrud] ChangeViewMode'),

    // View StandardCrud List
    STANDARD_CRUD_VIEW_LIST: type('[StandardCrud] ViewList'),
    STANDARD_CRUD_VIEW_LIST_SUCCESS: type('[StandardCrud] ViewListSuccess'),
    STANDARD_CRUD_VIEW_LIST_FAIL: type('[StandardCrud] ViewListFail'),

    STANDARD_CRUD_VIEW_LIST_SELECT: type('[StandardCrud] ViewListSelect'),

    STANDARD_CRUD_VIEW_LIST_PAGE_SELECT: type('[StandardCrud] ViewListPageSelect'),
    STANDARD_CRUD_VIEW_LIST_GET_ITEMS: type('[StandardCrud] ViewListPageGetItems'),

    // Loading Approve Status if require (after view list - load list of item is OK)
    STANDARD_CRUD_GET_APPROVE_STATUS: type('[StandardCrud] GetApproveStatus'),
    STANDARD_CRUD_GET_APPROVE_STATUS_SUCCESS: type('[StandardCrud] GetApproveStatusSuccess'),
    STANDARD_CRUD_GET_APPROVE_STATUS_FAIL: type('[StandardCrud] GetApproveStatusFail'),

    // Searching items
    STANDARD_CRUD_SEARCH: type('[StandardCrud] Search'),
    STANDARD_CRUD_SEARCH_SUCCESS: type('[StandardCrud] SearchSuccess'),
    STANDARD_CRUD_SEARCH_FAIL: type('[StandardCrud] SearchFail'),

    // Create new StandardCrud
    STANDARD_CRUD_CREATE: type('[StandardCrud] Create'),
    STANDARD_CRUD_CREATE_SUCCESS: type('[StandardCrud] CreateSuccess'),
    STANDARD_CRUD_CREATE_FAIL: type('[StandardCrud] CreateFail'),

    // Edit StandardCrud
    STANDARD_CRUD_EDIT: type('[StandardCrud] Edit'),
    STANDARD_CRUD_EDIT_SUCCESS: type('[StandardCrud] EditSuccess'),
    STANDARD_CRUD_EDIT_FAIL: type('[StandardCrud] EditFail'),

    // Delete standardCrud
    STANDARD_CRUD_DELETE: type('[StandardCrud] Delete'),
    STANDARD_CRUD_DELETE_CONFIRM: type('[StandardCrud] DeleteConfirm'),
    STANDARD_CRUD_DELETE_SUCCESS: type('[StandardCrud] DeleteSuccess'),
    STANDARD_CRUD_DELETE_FAIL: type('[StandardCrud] DeleteFail'),

    // Approve action
    STANDARD_CRUD_REQUEST_APPROVE: type('[StandardCrud] RequestApprove'),
    STANDARD_CRUD_REQUEST_APPROVE_SUCCESS: type('[StandardCrud] RequestApproveSuccess'),
    STANDARD_CRUD_REQUEST_APPROVE_FAIL: type('[StandardCrud] RequestApproveFail'),

    STANDARD_CRUD_DO_APPROVE: type('[StandardCrud] DoApprove'),
    STANDARD_CRUD_DO_APPROVE_SUCCESS: type('[StandardCrud] DoApproveSuccess'),
    STANDARD_CRUD_DO_APPROVE_FAIL: type('[StandardCrud] DoApproveFail'),

    // For Error Message
    STANDARD_CRUD_ERR_MESSAGE: type('[StandardCrud] ErrMessage')

};

// *************Set App Info************************
export class StandardCrudSetAppInfo implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_SET_CRUD_APP_INFO;

  constructor(public payload: StandardCrudAppInfo) {}
}

export class StandardCrudGetModelInfo implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_GET_INFO;

  constructor(public payload: any) {}
}

export class StandardCrudGetModelInfoSuccess implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_GET_INFO_SUCCESS;

  constructor(public payload: any) {}
}

export class StandardCrudGetModelInfoFail implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_GET_INFO_FAIL;

  constructor(public payload: any) {} // Error
}

export class StandardCrudIniGetItems implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ITEMS;

  constructor(public payload: any) {}
}

export class StandardCrudIniGetItemsSuccess implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ITEMS_SUCCESS;

  constructor(public payload: any) {} // Response
}

export class StandardCrudIniGetItemsFail implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ITEMS_FAIL;

  constructor(public payload: any) {} // Error
}

// ************For Routing Handle*************************
export class StandardCrudIniGetRoutingItemInfo implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ROUTING_ITEM_INFO;

  constructor(public payload: any) {} // itemId
}

export class StandardCrudIniGetRoutingItemInfoSuccess implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ROUTING_ITEM_INFO_SUCCESS;

  constructor(public payload: any) {} // info
}

export class StandardCrudIniGetRoutingItemInfoFail implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ROUTING_ITEM_INFO_FAIL;

  constructor(public payload: any) {} // error
}

// Paging for target item
export class StandardCrudIniGetRoutingPagingItem implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ROUTING_PAGING_ITEMS;

  constructor(public payload: any) {} // info
}

export class StandardCrudIniGetRoutingPagingItemSuccess implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ROUTING_PAGING_ITEMS_SUCCESS;

  constructor(public payload: any) {} // data
}

export class StandardCrudIniGetRoutingPagingItemFail implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_INI_GET_ROUTING_PAGING_ITEMS_FAIL;

  constructor(public payload: any) {} // error
}

// *************Set Datatable Info************************
export class StandardCrudGetDataInfo implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_GET_DATA_INFO;

  constructor(public payload: any) {}
}

export class StandardCrudGetDataInfoSuccess implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_GET_DATA_INFO_SUCCESS;

  constructor(public payload: any) {} // StandardDataInfo
}

export class StandardCrudGetDataInfoFail implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_GET_DATA_INFO_FAIL;

  constructor(public payload: any) {} // error
}

// *************Change View Mode************************
export class StandardCrudChangeViewMode implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_CHANGE_VIEW_MODE;

  constructor(public payload: any) {} // viewMode
}

// *************View StandardCrud List************************
export class StandardCrudViewList implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_VIEW_LIST;

  constructor(public payload: PagerModel) {}
}

export class StandardCrudViewListSuccess implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_VIEW_LIST_SUCCESS;

  constructor(public payload: any) {} // Response
}

export class StandardCrudViewListFail implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_VIEW_LIST_FAIL;

  constructor(public payload: any) {} // Error
}

export class StandardCrudViewListSelect implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_VIEW_LIST_SELECT;

  constructor(public payload: any) {} // standardCrudVM
}

export class StandardCrudViewListSelectPage implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_VIEW_LIST_PAGE_SELECT;

  constructor(public payload: PagerModel) {}
}

export class StandardCrudViewListGetItems implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_VIEW_LIST_GET_ITEMS;

  constructor(public payload: PagerModel) {}
}

// *************For Loading Approve Status ************************
export class StandardCrudGetApproveStatus implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_GET_APPROVE_STATUS;

  constructor(public payload: PagerModel) {}
}

export class StandardCrudGetApproveStatusSuccess implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_GET_APPROVE_STATUS_SUCCESS;

  constructor(public payload: any) {} // VerifyResult
}

export class StandardCrudGetApproveStatusFail implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_GET_APPROVE_STATUS_FAIL;

  constructor(public payload: any) {} // error
}

// *************Searching Items************************
export class StandardCrudSearch implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_SEARCH;

  constructor(public payload: SearchModel) {}
}

export class StandardCrudSearchSuccess implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_SEARCH_SUCCESS;

  constructor(public payload: any) {} // response
}

export class StandardCrudSearchFail implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_SEARCH_FAIL;

  constructor(public payload: any) {} // error
}

// *************Create New StandardCrud************************
export class StandardCrudCreate implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_CREATE;

  constructor(public payload: any) {} // newStandardCrud
}

export class StandardCrudCreateSuccess implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_CREATE_SUCCESS;

  constructor(public payload: any) {} // response
}

export class StandardCrudCreateFail implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_CREATE_FAIL;

  constructor(public payload: any) {} // error
}

// *************Edit StandardCrud************************
export class StandardCrudEdit implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_EDIT;

  constructor(public payload: any) {} // standardCrud
}

export class StandardCrudEditSuccess implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_EDIT_SUCCESS;

  constructor(public payload: any) {} // standardCrud
}

export class StandardCrudEditFail implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_EDIT_FAIL;

  constructor(public payload: any) {} // error
}

// *************Delete StandardCrud************************
export class StandardCrudDelete implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_DELETE;

  constructor(public payload: any) {} // id
}

export class StandardCrudDeleteConfirm implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_DELETE_CONFIRM;

  constructor(public payload: any) {} // id
}

export class StandardCrudDeleteSuccess implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_DELETE_SUCCESS;

  constructor(public payload: any) {} // id
}

export class StandardCrudDeleteFail implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_DELETE_FAIL;

  constructor(public payload: any) {} // error
}

// *************Approve Action******************************************
export class StandardCrudRequestApprove implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_REQUEST_APPROVE;

  constructor(public payload: any) {} // data
}

export class StandardCrudRequestApproveSuccess implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_REQUEST_APPROVE_SUCCESS;

  constructor(public payload: any) {} // data
}

export class StandardCrudRequestApproveFail implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_REQUEST_APPROVE_FAIL;

  constructor(public payload: any) {} // error
}

export class StandardCrudDoApprove implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_DO_APPROVE;

  constructor(public payload: any) {} // data
}

export class StandardCrudDoApproveSuccess implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_DO_APPROVE_SUCCESS;

  constructor(public payload: any) {} // data
}

export class StandardCrudDoApproveFail implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_DO_APPROVE_FAIL;

  constructor(public payload: any) {} // error
}

// For Error Message
export class StandardCrudErrorMessage implements Action {
  readonly type = StandardCrudActionTypes.STANDARD_CRUD_ERR_MESSAGE;

  constructor(public payload: any) {} // error
}



export type Actions =
  | StandardCrudSetAppInfo
  | StandardCrudGetModelInfo
  | StandardCrudGetModelInfoSuccess
  | StandardCrudGetModelInfoFail
  | StandardCrudIniGetItems
  | StandardCrudIniGetItemsSuccess
  | StandardCrudIniGetItemsFail
  | StandardCrudIniGetRoutingItemInfo
  | StandardCrudIniGetRoutingItemInfoSuccess
  | StandardCrudIniGetRoutingItemInfoFail
  | StandardCrudIniGetRoutingPagingItem
  | StandardCrudIniGetRoutingPagingItemSuccess
  | StandardCrudIniGetRoutingPagingItemFail
  | StandardCrudGetDataInfo
  | StandardCrudGetDataInfoSuccess
  | StandardCrudGetDataInfoFail
  | StandardCrudChangeViewMode
  | StandardCrudViewList
  | StandardCrudViewListSuccess
  | StandardCrudViewListFail
  | StandardCrudViewListSelect
  | StandardCrudViewListSelectPage
  | StandardCrudViewListGetItems
  | StandardCrudGetApproveStatus
  | StandardCrudGetApproveStatusSuccess
  | StandardCrudGetApproveStatusFail
  | StandardCrudSearch
  | StandardCrudSearchSuccess
  | StandardCrudSearchFail
  | StandardCrudCreate
  | StandardCrudCreateSuccess
  | StandardCrudCreateFail
  | StandardCrudEdit
  | StandardCrudEditSuccess
  | StandardCrudEditFail
  | StandardCrudDelete
  | StandardCrudDeleteConfirm
  | StandardCrudDeleteSuccess
  | StandardCrudDeleteFail
  | StandardCrudRequestApprove
  | StandardCrudRequestApproveSuccess
  | StandardCrudRequestApproveFail
  | StandardCrudDoApprove
  | StandardCrudDoApproveSuccess
  | StandardCrudDoApproveFail
  | StandardCrudErrorMessage;
