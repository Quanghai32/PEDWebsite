
import { Component, Input, OnChanges, ChangeDetectionStrategy } from '@angular/core';

import { DynamicFormService } from '../../dynamic-form/dynamic-form.service';
import { StandardCrudState } from '../standardCrud.state';
import { DynamicFormBase, ElementDescription, PropertyDescription } from '../../dynamic-form/dynamic-form.model';
import { DynamicFormModelInfo } from '../../dynamic-form/dynamic-form.model';
import { ParentObjInfo } from '../../dynamic-form/dynamic-form.model';

@Component({
  selector: 'app-scrud-detail',
  templateUrl: './scrud-detail.component.html',
  styleUrls: ['./scrud-detail.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ScrudDetailComponent implements OnChanges {

  @Input() objectState: StandardCrudState; // The object want to edit

  // Parent Object Info - Hold all information of Parent Object
  parentObjInfo: ParentObjInfo;

  constructor(
      private dynamicFormService: DynamicFormService
  ) {
  }

  ngOnChanges() {

      if (this.objectState.standardCrudViewModels.constructor === Array) {
          // Create new model to convert some control type to text for better view
          const newModel = this.objectState.standardCrudInfo.model.map(item => {
              let newElementDesc: ElementDescription;
              let newPropertyDescriptions: PropertyDescription[];
              newPropertyDescriptions = item.propertyDescriptions.map(desc => {
                  const newDesc = Object.assign({}, desc, { controlType: this.convertToText(desc.controlType) });
                  return newDesc;
              });

              newElementDesc = Object.assign({}, item, { propertyDescriptions: newPropertyDescriptions });
              return newElementDesc;
          });


          // Create Model Info Object
          let modelInfo: DynamicFormModelInfo;
          modelInfo = Object.assign({}, {
              model: newModel,
              obj: this.objectState.selectedObj.obj
              // With item type: obj is a single object
              // With list type: obj is an array of object (all object instances is same class type)
          });
          // Now, create elements info for display
          this.parentObjInfo = this.dynamicFormService.getParentObjectInfo(modelInfo);
      }
  }

  convertToText(type: string): string {
      // Remove textbox
      if ((type === 'textbox') || (type === 'password')) {
          return 'text';
      }
      return type;
  }

}
