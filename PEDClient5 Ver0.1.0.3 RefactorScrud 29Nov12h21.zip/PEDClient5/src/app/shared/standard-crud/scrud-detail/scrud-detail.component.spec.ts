import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScrudDetailComponent } from './scrud-detail.component';

describe('ScrudDetailComponent', () => {
  let component: ScrudDetailComponent;
  let fixture: ComponentFixture<ScrudDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScrudDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScrudDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
