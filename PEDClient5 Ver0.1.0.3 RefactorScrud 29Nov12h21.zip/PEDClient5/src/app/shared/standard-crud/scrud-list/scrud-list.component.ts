import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy} from '@angular/core';
import { OnInit, OnChanges, SimpleChanges, SimpleChange } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';

import { StandardCrudState } from '../standardCrud.state';
import { StandardCrudViewModel, StandardCrudViewList } from '../standardCrud.model';
import { DynamicFormService } from '../../dynamic-form/dynamic-form.service';
import { DynamicFormBase, ElementDescription, PropertyDescription } from '../../dynamic-form/dynamic-form.model';
import { DynamicFormModelInfo } from '../../dynamic-form/dynamic-form.model';

import { ParentObjInfo } from '../../dynamic-form/dynamic-form.model';
import { PagerModel } from '../../pagination/pager.model';

@Component({
  selector: 'app-scrud-list',
  templateUrl: './scrud-list.component.html',
  styleUrls: ['./scrud-list.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ScrudListComponent implements OnChanges, OnInit {

  @Input() objectState: StandardCrudState;
  @Output() changeOption: EventEmitter<any> = new EventEmitter();
  @Output() updatePaging: EventEmitter<any> = new EventEmitter();
  @Output() searchRequest: EventEmitter<any> = new EventEmitter();

  // We will use dynamic form to display each property of each item
  //  - We have a list of item here
  //  - Each item in table has an array of property
  //  - Each property need 1 "DynamicFormBase" to build dynamic form element for display
  //  => We need an "array of an array of DynamicFormBase", on the other hand "2 dimension of array DynamicFormBase"
  viewListModel: StandardCrudViewList; // All items have
  pagedListItems: StandardCrudViewList; // Contains only items which display on current page

  // Form Searching
  formSearch: FormGroup;

  constructor(
      public dynamicFormService: DynamicFormService,
      public fb: FormBuilder
  ) {
      this.viewListModel = <StandardCrudViewList>{};
      this.pagedListItems = <StandardCrudViewList>{};
      // Ini for form searching
      this.formSearch = this.fb.group({
          searchQuery: '', // User Input searching content
          searchCriteria: '' // Criteria to do search
      });
  }

  convertToText(type: string): string {
      // Remove textbox
      if ((type === 'textbox') || (type === 'password') || (type === 'date')) {
          return 'text';
      }
      return type;
  }

  ngOnInit() {

  }

  ngOnChanges() {

      // Create list of parent object info
      if (this.objectState.standardCrudViewModels.constructor === Array) { // Handle loading at start-up not ontime
          // Create new model to convert some control type to text for better view
          const newModel = this.objectState.standardCrudInfo.model.map(item => {
              let newElementDesc: ElementDescription;
              let newPropertyDescriptions: PropertyDescription[];
              newPropertyDescriptions = item.propertyDescriptions.map(desc => {
                  const newDesc = Object.assign({}, desc,
                      { controlType: this.convertToText(desc.controlType) }
                  ); // convert some control type to text for better view
                  return newDesc;
              });

              newElementDesc = Object.assign({}, item, { propertyDescriptions: newPropertyDescriptions });
              return newElementDesc;
          });

          this.viewListModel.parentObjInfos = this.objectState.standardCrudViewModels.map(vm => {
              return this.dynamicFormService
                  .getParentObjectInfo(Object.assign({}, {
                      model: newModel,
                      obj: vm.obj
                  }));
          });
          // check if selected array is already initilized or not, if not, ini for it
          this.viewListModel.selected = this.objectState.standardCrudViewModels.map(item => item.selected);

          // Well, now we do not load all items anymore => so basically pagedListItems === viewListModel?
          // Maybe only in the future if Search function added => pagedListItems !== viewListModel
          const startSliceIndex = this.objectState.pagerModel.startIndex;
          const endSliceIndex = this.objectState.pagerModel.startIndex + this.objectState.pagerModel.pageSize + 1;

          this.pagedListItems = Object.assign({}, this.viewListModel);
      }
  }

  // User select page on Pagination control => Handle
  selectPage(pagerModel: PagerModel) {

      if (this.objectState.pagerModel.currentPage !== undefined) { // Prevent triple loading item in start-up time
          if (this.objectState.pagerModel.currentPage !== pagerModel.currentPage) { // We need to add this to prevent forever looping!
              this.updatePaging.emit(pagerModel);
          }
      }
  }

  // For Searching
  searchHandle() {
      // Check search Query
      // If search Query === '' => restore to normal view with current page?
      const searchQuery: string = this.formSearch.get('searchQuery').value;
      if (searchQuery.trim() === '') {
          this.updatePaging.emit(this.objectState.pagerModel);
      } else {
          const test = this.formSearch.value;
          this.searchRequest.emit(test);
      }
  }

  get tableHeaders(): string[] {
      let result: string[] = [];
      //
      if ((this.objectState.standardCrudInfo.model !== undefined)
          && (this.objectState.standardCrudInfo.model.constructor === Array)) {
          result = this.objectState.standardCrudInfo.model // Reject PrimaryKey => do not display for user
              .filter(item => (item.type !== 'item') || (item.propertyDescriptions[0].isPrimaryKey !== true))
              .map(i => i.displayName);
      }
      //
      return result;
  }

  updateCheckBoxOption(index: number) {
      // Cal new value for view model
      const objectVM = Object.assign({}, this.objectState.standardCrudViewModels[index],
          { selected: this.pagedListItems.selected[index] });
      // Emit event
      this.changeOption.emit(objectVM);
  }

}
