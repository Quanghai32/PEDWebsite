﻿import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { INgxMyDpOptions } from 'ngx-mydatepicker';

@Component({
    selector: 'date-picker',
    templateUrl: './date-picker.component.html'
})
export class DatePickerComponent implements OnInit, OnChanges {

    public myOptions: INgxMyDpOptions = {
        // other options...
        dateFormat: 'dd.mm.yyyy',
    };

    public myForm: FormGroup; // For using only in component
    @Input() dateForm: FormGroup; // FormGroup instance - assign from parent element
    @Input() controlName: string; // Name of form control (Angular formControlName) - assign from parent element
    @Input() iniDate: Date; // current Date value - assign from parent element

    constructor(public formBuilder: FormBuilder) {
        const group: any = {};
        this.myForm = new FormGroup(group);
    }

    ngOnInit() {
        const date = new Date(this.iniDate);
        this.calDateForm(date);
        // subscribe
        this.myForm.valueChanges.subscribe(value => {
            // convert value to jsdate -> for backend understanding
            const group: any = {};

            group[this.controlName] = value[this.controlName].jsdate;
            this.dateForm.setValue(group);
        });
    }

    ngOnChanges() {
        const date = new Date(this.iniDate);
        this.calDateForm(date);
    }

    calDateForm(date: Date) {
        const group: any = {};
        let myDate: any;
        if (!isNaN(date.valueOf())) { // Valid Date?
            myDate = {
                date: { // Format compatible with ngx-mydatepicker
                    year: date.getFullYear(),
                    month: date.getMonth() + 1, // Month has zero-based!
                    day: date.getDate()
                }
            };
        } else { // Invalid date
            myDate = null;
        }
        //
        group[this.controlName] = new FormControl(myDate);
        this.myForm = new FormGroup(group);
    }


    setDate(): void {
        // Set today date using the setValue function
        const date = new Date();
        this.calDateForm(date);
    }

    clearDate(): void {
        // Clear the date using the setValue function
        this.calDateForm(null);
    }
}
