﻿import { PropertiesBase } from './properties-base';

export class SelectProperty extends PropertiesBase<string> {
    controlType = 'select';
    options: { key: string, value: string }[] = [];

    constructor(options: {} = {}) {
        super(options);
        this.options = options['options'] || [];
    }
}
