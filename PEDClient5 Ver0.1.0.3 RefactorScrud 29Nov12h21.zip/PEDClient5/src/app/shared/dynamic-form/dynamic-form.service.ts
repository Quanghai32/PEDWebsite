﻿import { Injectable } from '@angular/core';

import { FormGroup, FormArray, FormControl, Validators, FormBuilder } from '@angular/forms';

import { ElementDescription, PropertyDescription, DynamicElementInfo, DynamicFormBase } from './dynamic-form.model';
import { PropertiesBase } from './properties-base';
import { TextboxProperty } from './property-textbox';
import { TextProperty } from './property-text';
import { HrefProperty } from './property-href';
import { CheckboxProperty } from './property-checkbox';
import { SelectProperty } from './property-select';
import { PasswordProperty } from './property-password';
import { DateProperty } from './property-date';
import { PreProperty } from './property-pre';

import { DynamicFormModelInfo } from './dynamic-form.model';

import { ParentObjInfo } from './dynamic-form.model';


@Injectable()
export class DynamicFormService {

    constructor(
        public fb: FormBuilder
    ) {
    }

    toFormGroup(propertiesBases: PropertiesBase<any>[]) { // Form Group
        const group: any = {};

        propertiesBases.forEach(property => {

            if (typeof (property.value) === 'boolean') {
                group[property.key] = property.required ? new FormControl(property.value, Validators.required)
                    : new FormControl(property.value);
            } else { // default is text file
                group[property.key] = property.required ? new FormControl(property.value || '', Validators.required)
                    : new FormControl(property.value || '');
            }
        });
        return new FormGroup(group);
    }

    // Highest layer object - Parent object info
    // return ParentObjInfo
    // an object has a number of property (child object)
    // each property need a DynamicElementInfo for display
    // Totally, we need a list of DynamicElementInfo
    getParentObjectInfo(dfModelInfo: DynamicFormModelInfo): ParentObjInfo {
        // objInput.model: information about parent object structure
        // objInput.obj: instance of parent object (can be undefined!!! -> in case of create new mode)
        let dynamicElementInfos: DynamicElementInfo[];
        let parentFormGroup: FormGroup;
        // Ini for parent form group
        const group: any = {};
        parentFormGroup = new FormGroup(group);
        //
        if (dfModelInfo !== undefined) {

            dynamicElementInfos = dfModelInfo.model.map((elementDesc, index) => {

                let propertiesBasess: PropertiesBase<any>[][];

                // objInput.obj: parent instance object
                // => we need to extract parent instance object to child object for analyzing
                // Create objList item
                //  - 'item' is list of Object has 1x1 dimension
                //  - 'list' => just pass
                let objElement;
                if (dfModelInfo.obj !== undefined) {
                    objElement = dfModelInfo.obj[elementDesc.elementName];
                }

                propertiesBasess = this.listElementPropertiesBase(elementDesc, objElement);

                let dynamicFormBasess: DynamicFormBase[][];

                let FA: FormArray; // in case of 'list'
                FA = this.fb.array([]); // Ini for Form Array

                dynamicFormBasess = propertiesBasess.map(propertiesBases => {
                    const FG = this.toFormGroup(propertiesBases);
                    FA.push(FG);

                    let dynamicFormBases: DynamicFormBase[];
                    return dynamicFormBases = propertiesBases.map((base, k) => {
                        return Object.assign({}, {
                            formGroup: FG, // single element must belong to same FormGroup of its parent
                            propertiesBase: base,
                            cssStyle: elementDesc.propertyDescriptions[k].cssStyle
                        });
                    });
                });

                // adding FG to parentFormGroup
                parentFormGroup.addControl(elementDesc.elementName, FA);

                let dynamicElementInfo: DynamicElementInfo;
                dynamicElementInfo = Object.assign({}, {
                    elementDescription: elementDesc,
                    elementObject: objElement,
                    dynamicFormBasess: dynamicFormBasess
                });
                return dynamicElementInfo;
            });
        }
        //
        return <ParentObjInfo>Object.assign({}, {
            parentFG: parentFormGroup,
            deInfos: dynamicElementInfos
        });
    }

    // Third last layer object
    // objList: list of list of single object (each item in list has same property) => only need 1 ElementDescription
    listElementPropertiesBase(element: ElementDescription, objList: any): PropertiesBase<any>[][] {
        let propertiesBasess: PropertiesBase<any>[][];
        // objList can be undefined or an instance
        // In any case, we need create an array of object
        let arrObj: any[] = [];
        if (objList === undefined) {
            arrObj.push(undefined); // array has 1 item which is undefined!
        } else {
            if ((objList !== null) && (objList.constructor === Array)) { // List type
                arrObj = objList;
            } else { // item type
                arrObj.push(objList);
            }
        }

        propertiesBasess = arrObj.map(objFlat => {
            return this.flatElementPropertiesBase(element, objFlat);
        });
        return propertiesBasess;
    }

    // Second last layer object
    // objFlat: object has some properties which are single object (list of single object)
    flatElementPropertiesBase(element: ElementDescription, objFlat: any): PropertiesBase<any>[] {
        let propertiesBases: PropertiesBase<any>[];
        //

        propertiesBases = element.propertyDescriptions.map((desc, index) => {
            if (objFlat === undefined) { // create new mode
                return this.createSinglePropertiesBase(desc, index, undefined);
            } else { // view mode
                const obj = (element.type === 'list') ? objFlat[desc.propertyName] : objFlat;
                return this.createSinglePropertiesBase(desc, index, obj);
            }
        });

        return propertiesBases;
    }

    // Last layer object
    // Create only a single properties base for only 1 control (textbox, checkbox...)
    createSinglePropertiesBase(item: PropertyDescription, index: number, obj: any): PropertiesBase<any> {
        switch (item.controlType) {
            case 'checkbox':
                return new CheckboxProperty({
                    key: item.propertyName,
                    label: item.displayName,
                    value: (obj !== undefined) ? obj : false,
                    type: item.controlType,
                    required: false,
                    order: index
                });

            case 'select':
                return new SelectProperty({
                    key: item.propertyName,
                    label: item.displayName,
                    value: (obj !== undefined) ? obj : '',
                    options: item.selectDatas,
                    order: index
                });
            case 'text':
                return new TextProperty({
                    key: item.propertyName,
                    label: item.displayName,
                    value: (obj !== undefined) ? obj : '',
                    type: item.controlType,
                    required: true,
                    order: index
                });
            case 'href':
                return new HrefProperty({
                    key: item.propertyName,
                    label: item.displayName,
                    value: (obj !== undefined) ? obj : '',
                    type: item.controlType,
                    required: true,
                    order: index
                });
            case 'password':
                return new PasswordProperty({
                    key: item.propertyName,
                    label: item.displayName,
                    value: (obj !== undefined) ? obj : '',
                    type: item.controlType,
                    required: true,
                    order: index
                });

            case 'date':
                return new DateProperty({
                    key: item.propertyName,
                    label: item.displayName,
                    value: (obj !== undefined) ? obj : '',
                    type: item.controlType,
                    required: true,
                    order: index
                });

            case 'pre':
                return new PreProperty({
                    key: item.propertyName,
                    label: item.displayName,
                    value: (obj !== undefined) ? obj : '',
                    type: item.controlType,
                    required: true,
                    order: index
                });

            default: // Default is text box
                return new TextboxProperty({
                    key: item.propertyName,
                    label: item.displayName,
                    value: (obj !== undefined) ? obj : '',
                    type: item.controlType,
                    required: true,
                    order: index
                });
        }
    }


    // **********************MODIFY EXISTING PARENT OBJECT INFO******************
    AddItemToElementOfParentObject(parentObjInfo: ParentObjInfo, elDesc: ElementDescription, elId: number, newValue: any) {
        // Add item action handle here
        // create new DynamicFormBase
        // let dynamicFormBases: DynamicFormBase[];
        // dynamicFormBases = Object.assign({}, this.dynamicElementInfos[listId].dynamicFormBasess[0]);
        const propertiesBases = this.flatElementPropertiesBase(
            elDesc,
            newValue
            );

        // Create new formGroup of new create item
        const FG = this.toFormGroup(propertiesBases);
        // adding FG to Form Array of list => so we can get new create value when user submit
        const test = parentObjInfo.parentFG.get(parentObjInfo.deInfos[elId].elementDescription.elementName) as FormArray;
        test.push(FG);

        // Add to dynamic form base collection => change on view, show new create item
        let dynamicFormBases: DynamicFormBase[];
        dynamicFormBases = propertiesBases.map((base, k) => {
            return Object.assign({}, {
                formGroup: FG,
                propertiesBase: base,
                cssStyle: parentObjInfo.deInfos[elId].elementDescription.propertyDescriptions[k].cssStyle
            });
        });

        parentObjInfo.deInfos[elId].dynamicFormBasess.push(dynamicFormBases);
    }


    RemoveItemFromElementOfParentObject(parentObjInfo: ParentObjInfo, elId: number, itemId: number) { // Remove item by Id of list
        // remove item action handle here
        // Remove item form dynamic form base => remove item on View
        parentObjInfo.deInfos[elId].dynamicFormBasess.splice(itemId, 1);
        // remove item from Parent form group => remove item from data of form group
        const test = parentObjInfo.parentFG.get(parentObjInfo.deInfos[elId].elementDescription.elementName) as FormArray;
        test.removeAt(itemId);
    }
}
