﻿
import { PropertiesBase } from './properties-base';

export class CheckboxProperty extends PropertiesBase<string> {
    controlType = 'checkbox';
    type: string;

    constructor(options: {} = {}) {
        super(options);
        this.type = options['type'] || '';
    }
}