﻿import { Component, Input } from '@angular/core';

import { DynamicFormBase } from './dynamic-form.model';


@Component({
    selector: 'df-property',
    templateUrl: './dynamic-form.component.html'
})
export class DynamicFormComponent {
    @Input() dynamicFormBase: DynamicFormBase;

    get isValid() { return this.dynamicFormBase.formGroup.controls[this.dynamicFormBase.propertiesBase.key].valid; }
}
