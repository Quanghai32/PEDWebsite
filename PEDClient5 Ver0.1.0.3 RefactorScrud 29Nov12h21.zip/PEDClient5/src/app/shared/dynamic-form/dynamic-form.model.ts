﻿import { FormGroup } from '@angular/forms';
import { PropertiesBase } from './properties-base';


// Hold all data necessary for Parent Object - Result of calculating process
export interface ParentObjInfo {
    parentFG: FormGroup;     // An instance of parent form group will pass to all lower level child object -> must be same for all
                             // This is for FormGroup only => deInfos: contains all necessary setting for dynamic view
    deInfos: DynamicElementInfo[]; // each DynamicElementInfo will hold necessary info for an element
                                  // (child object of child list object) of parent object
}

// Hold all data necessary of an element
export interface DynamicElementInfo {
    elementDescription: ElementDescription; // Contain original description for element - same as Backend Info
    elementObject: any; // Contain original instance of object
    dynamicFormBasess: DynamicFormBase[][]; // With item type => only need 1 DynamicFormBase.
                                        // But with list type => each item in list is actually a child object
                                        // Each child object has some property
                                        // Each property of child object need 1 DynamicFormBase
                                        // Totally we need array of array DynamicFormBase
}

export class DynamicFormBase { // For display 1 control only (textbox, checkbox,select...)
    formGroup: FormGroup; // Form Group Object, to hold all object (control) for display
    propertiesBase: PropertiesBase<any>; // Specify type, value...of control display
    cssStyle: CssStyle; // For dynamic apply CSS Style with Info reading from Backend
}

// Contain original information about object model - Get from Backend
export class DynamicFormModelInfo {
    model: ElementDescription[]; // contain metadata information of object for display label & type of form
    obj: any; // an instance of an object for display value
}

// Basic info of element (1 property of parent object) - same as backend define
export interface ElementDescription {
    type: string; // item or list
    elementName: string; // name of element property of object (F1 property)
    displayName: string; // Display name of element
    propertyDescriptions: PropertyDescription[]; // 1 element can be a single object or a list of object
    createMethod: string; // + createMethod = "input" - default.
                          // Create new element by input directly each property of element (textbox, checkbox...)
                          // + createMethod = "select" -
                          // Create new element by searching from existing entity.
                          // Frontend should provide search funtion for user search & select desired item.
    searchUrl: string; // Setting searching Url for element
    // For dynamic apply CSS Style with Info reading from Backend
    cssStyle: CssStyle;
}

// Description for each type of single object - how to display (same as backend define)
export interface PropertyDescription {
    isPrimaryKey: boolean; // Indicate property is Primary Key or not
    propertyName: string; // Ex: property4
    displayName: string; // display name for property. Ex: Label4
    dataType: string; // type of property (string, number, boolean...). Ex: string
    controlType: string; // Control type for property (textbox,checkbox, select...). Ex: select
    // For Select type
    selectDatas: string[]; // A,B,C,D,E,F

    // For dynamic apply CSS Style with Info reading from Backend
    cssStyle: CssStyle;
}

// CSS style support for Dynamic form base - same as backend define
export interface CssStyle {
    color: string;
    visibility: string;
    display: string;
    disabled: boolean;
}
