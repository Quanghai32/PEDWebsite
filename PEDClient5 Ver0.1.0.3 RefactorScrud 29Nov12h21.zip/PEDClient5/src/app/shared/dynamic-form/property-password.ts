﻿
import { PropertiesBase } from './properties-base';

export class PasswordProperty extends PropertiesBase<string> {
    controlType = 'password';
    type: string;

    constructor(options: {} = {}) {
        super(options);
        this.type = options['type'] || '';
    }
}