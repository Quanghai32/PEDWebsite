﻿
import { PropertiesBase } from './properties-base';

export class TextProperty extends PropertiesBase<string> {
    controlType = 'text';
    type: string;

    constructor(options: {} = {}) {
        super(options);
        this.type = options['type'] || '';
    }
}