﻿
import { PropertiesBase } from './properties-base';

export class HrefProperty extends PropertiesBase<string> {
    controlType = 'href';
    type: string;

    constructor(options: {} = {}) {
        super(options);
        this.type = options['type'] || '';
    }
}