﻿
import { PropertiesBase } from './properties-base';

export class TextboxProperty extends PropertiesBase<string> {
    controlType = 'textbox';
    type: string;

    constructor(options: {} = {}) {
        super(options);
        this.type = options['type'] || '';
    }
}