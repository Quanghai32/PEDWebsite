﻿
import { PropertiesBase } from './properties-base';

export class DateProperty extends PropertiesBase<string> {
    controlType = 'date';
    type: string;

    constructor(options: {} = {}) {
        super(options);
        this.type = options['type'] || '';
    }
}