﻿
import { PropertiesBase } from './properties-base';

export class PreProperty extends PropertiesBase<string> {
    controlType = 'pre';
    type: string;

    constructor(options: {} = {}) {
        super(options);
        this.type = options['type'] || '';
    }
}