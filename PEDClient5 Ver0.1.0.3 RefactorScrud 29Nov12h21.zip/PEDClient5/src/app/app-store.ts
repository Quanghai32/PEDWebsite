
import {
  ActionReducerMap,
  createSelector,
  createFeatureSelector,
  ActionReducer,
  Action,
  MetaReducer
} from '@ngrx/store';
import { environment } from '../environments/environment';

// ****************************Global App State****************************************
export interface State {
    dummyState: DummyState;
}

export const reducers: ActionReducerMap<State> = {
  dummyState: dummyReducer,
};

export interface DummyState {
  showSidenav: boolean;
}

const iniDummyState: DummyState = {
  showSidenav: false,
};

export const OPEN_SIDENAV = '[Layout] Open Sidenav';

export class OpenSidenavAction implements Action {
  readonly type = OPEN_SIDENAV;
}

export type DummyActions = OpenSidenavAction;

export function dummyReducer(state = iniDummyState, action: DummyActions): DummyState {
  switch (action.type) {
    default:
      return state;
  }
}

// console.log all actions
// export function logger(reducer: ActionReducer<State>): ActionReducer<any, any> {
//   return function(state: State, action: any): State {
//     console.log('state', state);
//     console.log('action', action);

//     return reducer(state, action);
//   };
// }


export function debug(reducer: ActionReducer<any>): ActionReducer<any> {
  return function(state, action) {
    console.log('state', state);
    console.log('action', action);

    return reducer(state, action);
  }
}

export const metaReducers: MetaReducer<any>[] = !environment.production? [debug]: [];


// export function logger(reducer): ActionReducer<any, any> {
//   return function(state, action) {
//     console.log('state', state);
//     console.log('action', action);

//     return reducer(state, action);
//   };
// }

// export const metaReducers: ActionReducer<any, any>[] = !environment.production
//   ? [logger]
//   : [];
