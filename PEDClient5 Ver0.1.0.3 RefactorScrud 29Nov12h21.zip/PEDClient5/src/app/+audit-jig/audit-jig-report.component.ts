﻿
import { Component, Input, Output, EventEmitter, OnChanges } from '@angular/core';

import { AuditJigReportDTO, AuditItemResultDTO } from './audit-jig.model';


@Component({
    selector: 'audit-jig-report',
    templateUrl: './audit-jig-report.component.html'
})

export class AuditJigReportComponent implements OnChanges {
    @Input() auditReport: AuditJigReportDTO;
    @Output() submitReport: EventEmitter<any> = new EventEmitter();


    ngOnChanges() {

    }

    get numberOK(): number {
        return this.auditReport.AuditItemResultDTOs
            .filter(item => item.Result === 'OK').length;
    }

    get numberNG(): number {
        return this.auditReport.AuditItemResultDTOs
            .filter(item => item.Result === 'NG').length;
    }

    submitReportHandle() {
        this.submitReport.emit(this.auditReport);
    }
}
