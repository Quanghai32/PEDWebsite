﻿
import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { StartAuditComponent } from './start-audit.component';

const routes: Routes = [
    { path: '', component: StartAuditComponent }
];


export const auditJigRouting: ModuleWithProviders = RouterModule.forChild(routes);
