﻿
import { NgModule } from '@angular/core';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { SharedModule } from '../shared/shared.module';

import { StartAuditComponent } from './start-audit.component';
import { AuditJigReportComponent } from './audit-jig-report.component';

import { auditJigRouting } from './audit-jig-routing';

import { AuditJigBackEndService } from './audit-jig.backend.service';
// import { ModalAuditService } from './modal-audit/modal-audit.service';

import { auditJigReducer } from './audit-jig.reducer';
import { AuditJigEffects } from './audit-jig.effects';

import { ModalAuditComponent} from './modal-audit/modal-audit.component';

@NgModule({
    imports: [
        auditJigRouting,
        SharedModule,
        StoreModule.forFeature('auditJig', auditJigReducer),
        EffectsModule.forFeature([AuditJigEffects]),
    ],
    declarations: [
        StartAuditComponent,
        AuditJigReportComponent,
        ModalAuditComponent
    ],
    // entryComponents: [ // Move to SharedModule. entryComponents cannot declared in lazy loading module
    //     ModalAuditComponent
    // ],
    exports: [
        ModalAuditComponent
    ],
    providers: [
        AuditJigBackEndService
        // ModalAuditService
    ]
})
export class AuditJigModule {}
