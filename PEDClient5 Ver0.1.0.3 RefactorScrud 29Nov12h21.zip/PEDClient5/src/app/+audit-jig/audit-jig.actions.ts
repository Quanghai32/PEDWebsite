﻿import { type } from '../util/action-name-helper';
import { Action } from '@ngrx/store';
import { Injectable } from '@angular/core';

import { ViewMode, JigProfile, AuditJigReportDTO } from './audit-jig.model';


export const AuditJigActionTypes = {
    AUDIT_JIG_CHANGE_VIEW_MODE: type('[AuditJig] ChangeViewMode'),

    AUDIT_JIG_GET_PRODUCT_MODEL: type('[AuditJig] GetProductModel'),
    AUDIT_JIG_GET_PRODUCT_MODEL_SUCCESS: type('[AuditJig] GetProductModelSuccess'),
    AUDIT_JIG_GET_PRODUCT_MODEL_FAIL: type('[AuditJig] GetProductModelFail'),

    AUDIT_JIG_GET_JIG_PROFILE_MODEL_INFO: type('[AuditJig] GetJigProfileModelInfo'),
    AUDIT_JIG_GET_JIG_PROFILE_MODEL_INFO_SUCCESS: type('[AuditJig] GetJigProfileModelInfoSuccess'),
    AUDIT_JIG_GET_JIG_PROFILE_MODEL_INFO_FAIL: type('[AuditJig] GetJigProfileModelInfoFail'),

    // Submit Audit Report
    AUDIT_JIG_SUBMIT_AUDIT_REPORT: type('[AuditJig] SubmitAuditReport'),
    AUDIT_JIG_SUBMIT_AUDIT_REPORT_SUCCESS: type('[AuditJig] SubmitAuditReportSuccess'),
    AUDIT_JIG_SUBMIT_AUDIT_REPORT_FAIL: type('[AuditJig] SubmitAuditReportFail'),

    // Submit Audit Report
    AUDIT_JIG_RESET: type('[AuditJig] Reset')
};

// *************Set App Info************************
export class AuditJigChangeViewMode implements Action {
  readonly type = AuditJigActionTypes.AUDIT_JIG_CHANGE_VIEW_MODE;

  constructor(public payload: ViewMode) {}
}

export class AuditJigGetProductModel implements Action {
  readonly type = AuditJigActionTypes.AUDIT_JIG_GET_PRODUCT_MODEL;

  constructor(public payload: any) {}
}

export class AuditJigGetProductModelSuccess implements Action {
  readonly type = AuditJigActionTypes.AUDIT_JIG_GET_PRODUCT_MODEL_SUCCESS;

  constructor(public payload: any) {}
}

export class AuditJigGetProductModelFail implements Action {
  readonly type = AuditJigActionTypes.AUDIT_JIG_GET_PRODUCT_MODEL_FAIL;

  constructor(public payload: any) {}
}

export class AuditJigGetJigProfileModelInfo implements Action {
  readonly type = AuditJigActionTypes.AUDIT_JIG_GET_JIG_PROFILE_MODEL_INFO;

  constructor(public payload: any) {}
}

export class AuditJigGetJigProfileModelInfoSuccess implements Action {
  readonly type = AuditJigActionTypes.AUDIT_JIG_GET_JIG_PROFILE_MODEL_INFO_SUCCESS;

  constructor(public payload: JigProfile[]) {}
}

export class AuditJigGetJigProfileModelInfoFail implements Action {
  readonly type = AuditJigActionTypes.AUDIT_JIG_GET_JIG_PROFILE_MODEL_INFO_FAIL;

  constructor(public payload: any) {}
}

export class AuditJigSubmitAuditReport implements Action {
  readonly type = AuditJigActionTypes.AUDIT_JIG_SUBMIT_AUDIT_REPORT;

  constructor(public payload: any) {}
}

export class AuditJigSubmitAuditReportSuccess implements Action {
  readonly type = AuditJigActionTypes.AUDIT_JIG_SUBMIT_AUDIT_REPORT_SUCCESS;

  constructor(public payload: any) {} // AuditJigReportDTO
}

export class AuditJigSubmitAuditReportFail implements Action {
  readonly type = AuditJigActionTypes.AUDIT_JIG_SUBMIT_AUDIT_REPORT_FAIL;

  constructor(public payload: any) {}
}

export class AuditJigReset implements Action {
  readonly type = AuditJigActionTypes.AUDIT_JIG_RESET;

  constructor(public payload: any) {}
}

export type Actions =
  | AuditJigChangeViewMode
  | AuditJigGetProductModel
  | AuditJigGetProductModelSuccess
  | AuditJigGetProductModelFail
  | AuditJigGetJigProfileModelInfo
  | AuditJigGetJigProfileModelInfoSuccess
  | AuditJigGetJigProfileModelInfoFail
  | AuditJigSubmitAuditReport
  | AuditJigSubmitAuditReportSuccess
  | AuditJigSubmitAuditReportFail
  | AuditJigReset;
