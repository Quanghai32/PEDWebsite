﻿
export interface JigProfile {
    ID: string;
    DesignID: string;
    JigName: string;
    JigCode: string;
    JigRev: string;
}

export interface ActualJigInfo {
    Barcode: string;
    JigProfileID: string; // ID of Jig Profile
    DesignID: string; // Analyze from Barcode
    JigName: string; // Searching through DesignID of Master Info JigProfile
    JigCode: string; // Searching through DesignID of Master Info JigProfile
    JigRev: string; // Analyze from Barcode
}

export interface ItemAuditResult {
    result: string; // OK - NG - Unknown
    note: string; // Note for result check
}

export interface AuditResult {
    actualJigInfo: ActualJigInfo;
    itemAuditResult: ItemAuditResult;
}

export interface AuditJigReportDTO {
    ID: string;
    AuditTime: Date;
    CellName: string;
    ProductModel: string;
    Auditor: string;
    AuditItemResultDTOs: AuditItemResultDTO[];
}

export interface AuditItemResultDTO {
    ID: string;
    Barcode: string;
    //
    JigProfileID: string;
    DesignID: string;
    JigName: string;
    JigCode: string;
    JigRev: string;
    //
    Result: string;
    Note: string;
}

// For View Mode Selection
export enum ViewMode {
    viewAuditAction,
    viewMasterInfo,
    viewAuditReport
}
