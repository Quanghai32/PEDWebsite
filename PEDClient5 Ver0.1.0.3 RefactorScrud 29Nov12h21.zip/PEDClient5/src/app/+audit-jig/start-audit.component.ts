﻿import { Component, Input, Output, EventEmitter, OnInit, OnChanges } from '@angular/core';
import { ChangeDetectionStrategy, ChangeDetectorRef, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { Store } from '@ngrx/store';

import { Observable } from 'rxjs/Observable';

import { LogInState } from '../login/log-in.state';
import { JigProfile, AuditResult, ActualJigInfo, ItemAuditResult } from './audit-jig.model';
import { ViewMode, AuditJigReportDTO, AuditItemResultDTO } from './audit-jig.model';
import { ModalAuditSetting, ModalAuditOutput } from './modal-audit.model';

import { AuditJigState } from './audit-jig.state';
import * as fromState from './audit-jig.state';
import * as fromLoginState from '../login/log-in.state';
import * as audit from './audit-jig.actions';
import { AuditJigReportComponent } from './audit-jig-report.component';

// import { ModalAuditService } from './modal-audit/modal-audit.service';
import { ModalAuditComponent } from './modal-audit/modal-audit.component';

@Component({
    selector: 'start-audit',
    templateUrl: 'start-audit.component.html',
    styleUrls: ['./start-audit.component.css']
})
export class StartAuditComponent implements OnInit {
    @ViewChild(ModalAuditComponent) modalAuditComponent: ModalAuditComponent;
    // State
    auditJigState$: Observable<AuditJigState>;
    loggedInState$: Observable<LogInState>;
    //
    enumViewMode = ViewMode;
    formAudit: FormGroup;
    auditResults: AuditResult[] = [];
    mdSetting: ModalAuditSetting;

    constructor(
        public fb: FormBuilder,
        public store$: Store<any>
        // public modalService: ModalAuditService
    ) {
        // alert('StartAuditComponent');
        // this.standardCrudState$ = store$.select(fromState.getScrudState);
        this.auditJigState$ = this.store$.select(fromState.getAuditJigState);
        this.loggedInState$ = this.store$.select(fromLoginState.getLoginState);
        this.createForm();
    }

    ngOnInit() {
        // Get Product Model list for user select
        this.store$.dispatch(new audit.AuditJigGetProductModel(undefined));
    }

    createForm() {
        this.formAudit = this.fb.group({
            productModel: '', // User select Product Model for Audit Jig
            cellName: '', // User input cell name for Audit Jig
        });
    }

    get auditJigReportDTO(): AuditJigReportDTO{
        const auditReport: AuditJigReportDTO = <AuditJigReportDTO>{};
        //
        let currentState: LogInState = <LogInState>{};
        this.loggedInState$.take(1).subscribe(l => currentState = l);


        auditReport.ProductModel = this.formAudit.get('productModel').value;
        auditReport.CellName = this.formAudit.get('cellName').value;
        // Get Auditor Info
        auditReport.Auditor = currentState.userProfile.name;
        // Get Audit Time
        auditReport.AuditTime = new Date();
        // Get Result Detail
        const test = this.auditResults.map(a => {
            const test2 = <AuditItemResultDTO>{
                Barcode: a.actualJigInfo.Barcode,
                JigProfileID: a.actualJigInfo.JigProfileID,
                DesignID: a.actualJigInfo.DesignID,
                JigName: a.actualJigInfo.JigName,
                JigCode: a.actualJigInfo.JigCode,
                JigRev: a.actualJigInfo.JigRev,
                Result: a.itemAuditResult.result,
                Note: a.itemAuditResult.note
            };
            return test2;
        });
        auditReport.AuditItemResultDTOs = test;

        //
        return auditReport;
    }

    changeViewMode(viewMode: ViewMode) {
        this.store$.dispatch(new audit.AuditJigChangeViewMode(viewMode));
    }

    // Reset all states, to prepare for new audit
    resetAllHandle() {
        // Reset form audit
        this.formAudit.reset();
        // Reset audit result
        this.auditResults = [];
        // setting for modal form
        this.mdSetting = <ModalAuditSetting>{};
        // Reset state to ini
        this.store$.dispatch(new audit.AuditJigReset(undefined));
    }

    StartAuditClick() { // User Click Start Audit Handle
        // 1. First, we get master info from backend
        this.store$.dispatch(new audit.AuditJigGetJigProfileModelInfo(this.formAudit.get('productModel').value));

        // OK. Now display modal form for reading bacode & check
        this.mdSetting = <ModalAuditSetting>{};
        this.mdSetting.source = 'StartAudit';
        this.mdSetting.title = 'Audit Jig for cell ' + this.formAudit.get('cellName').value +
            ' of Model ' + this.formAudit.get('productModel').value;
        this.mdSetting.buttons = ['Check', 'Next', 'Close'];
        this.mdSetting.isVisible = true;

        // const newSetting = Object.assign({}, this.mdSetting);

        // this.modalService.setModalSetting(newSetting);
        // this.modalService.PushOut('title', 'body');

        // this.modalService.mdOutput.subscribe(value => {
        //     // alert(value);
        //     if (value.buttonPress === 'Check') { // User want to check input item immediately
        //         this.analyzeBarcodes(value.outputObjects);
        //     } else if (value.buttonPress === 'Next') { // User want to change to check next item

        //     } else { // Default is close Modal Dialog
        //         this.modalService.close();
        //         this.mdSetting = undefined;
        //     }
        // });

        // this.modalAuditComponent.show();
        this.modalAuditComponent.requestShow(this.mdSetting);
    }

    analyzeSingleBarcode(barcode: string) {

        // Only Analyze if not audit yet
        let exist = false;
        this.auditResults.every(result => {
            if (result.actualJigInfo.Barcode === barcode) { // Already audit
                exist = true;
                return false;
            } else {
                return true; // Keep going
            }
        });

        if (exist === false) {
            const newItemResult: AuditResult = <AuditResult>{};
            newItemResult.actualJigInfo = <ActualJigInfo>{};
            newItemResult.itemAuditResult = <ItemAuditResult>{};
            if (barcode.length === 10) { // Format OK?
                newItemResult.actualJigInfo.Barcode = barcode;
                // Get Design ID
                newItemResult.actualJigInfo.DesignID = barcode.substr(1, 4);
                newItemResult.actualJigInfo.JigRev = barcode.substr(5, 2);

                // Note that with 1 design ID, there can be some version exist => we need to looking for all
                // Looking for JigName, JigCode, JigRev through Design ID
                // Get current state
                let currentState: AuditJigState;
                this.auditJigState$.take(1).subscribe(s => currentState = s);

                // Looking for all revision has same Design ID
                const jigProfiles = currentState.jigProfiles
                    .filter(j => j.DesignID === newItemResult.actualJigInfo.DesignID);
                //
                if (jigProfiles.length === 0) {
                    newItemResult.itemAuditResult.result = 'NG';
                    newItemResult.itemAuditResult.note = 'Not Found Jig Profile';
                } else {
                    // Update Jig Profile Info to audit result
                    newItemResult.actualJigInfo.JigProfileID = jigProfiles[0].ID;
                    newItemResult.actualJigInfo.JigName = jigProfiles[0].JigName;
                    newItemResult.actualJigInfo.JigCode = jigProfiles[0].JigCode;

                    // Test Revision Matching
                    const testRevMatching = jigProfiles.filter(item => item.JigRev === newItemResult.actualJigInfo.JigRev);
                    if (testRevMatching.length > 0) { // Rev matching
                        newItemResult.itemAuditResult.result = 'OK';
                        newItemResult.itemAuditResult.note = '';
                    } else {
                        newItemResult.itemAuditResult.result = 'NG';
                        newItemResult.itemAuditResult.note = 'Rev not matching!';
                    }
                }
            } else { // Not length OK
                newItemResult.actualJigInfo.Barcode = barcode;
                newItemResult.itemAuditResult.result = 'NG';
                newItemResult.itemAuditResult.note = 'Barcode Format NG.';
            }
            // Push to array
            this.auditResults.push(newItemResult);

            // Save to md setting
            this.mdSetting.lastItemResult = newItemResult;
            // const newSetting = Object.assign({}, this.mdSetting);
            // this.modalService.setModalSetting(newSetting);


        } else {
            // Save to md setting
            this.mdSetting.lastItemResult = this.auditResults.find(item => item.actualJigInfo.Barcode === barcode);
            // const newSetting2 = Object.assign({}, this.mdSetting);
            // this.modalService.setModalSetting(newSetting2);
        }
    }

    analyzeBarcodes(barcodes: string[]) {
        barcodes.forEach(barcode => {
            this.analyzeSingleBarcode(barcode);
        });
    }

    modalResultHandle(output: ModalAuditOutput) {
        switch (output.setting.source) {
            case 'StartAudit':
                if (output.buttonPress === 'Check') { // User want to check input item immediately
                    this.analyzeBarcodes(output.outputObjects);
                } else if (output.buttonPress === 'Next') { // User want to change to check next item

                } else { // Default is close Modal Dialog
                    this.mdSetting = undefined;
                }
                break;
            default:
                // reset all => Close Modal Dialog
                this.mdSetting = undefined;
                break;
        }
    }

    // Submit Report
    submitReportHandle(auditJigReport: AuditJigReportDTO) {
        // var test = auditJigReport;
        this.store$.dispatch(new audit.AuditJigSubmitAuditReport(auditJigReport));
    }
}
