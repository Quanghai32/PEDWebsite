﻿
import { Injectable } from '@angular/core';
import { Actions, Effect, toPayload } from '@ngrx/effects';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/mapTo';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import { AuditJigBackEndService } from './audit-jig.backend.service';
import { AuditJigActionTypes } from './audit-jig.actions';

import { ViewMode } from './audit-jig.model';
import * as audit from './audit-jig.actions';

@Injectable()
export class AuditJigEffects {
    constructor(
        public actions$: Actions,
        public auditJigBackEndService: AuditJigBackEndService
        ) {
    }

    @Effect()
    getProductModels$ = this.actions$
        .ofType(AuditJigActionTypes.AUDIT_JIG_GET_PRODUCT_MODEL)
        .switchMap(payload => this.auditJigBackEndService.getProductModels()
            // If successful, dispatch success action with result
            // .map((res) => {
            //     return res.json();
            // })  // ProductModel[]
            .map((res: any[]) => { // ProductModel[]
                return res.map(obj => obj.ModelName); // Get ModelName only => models
            }) //
            .map((res) => new audit.AuditJigGetProductModelSuccess(res)) // model[]
            // If request fails, dispatch failed action
            .catch(error => Observable.of(new audit.AuditJigGetProductModelFail(undefined)))
        );


    @Effect()
    getJigProfileModelInfo$ = this.actions$
        .ofType(AuditJigActionTypes.AUDIT_JIG_GET_JIG_PROFILE_MODEL_INFO)
        .map(toPayload)
        .switchMap(payload => this.auditJigBackEndService.getJigProfileModelInfo(payload)
            // If successful, dispatch success action with result
            // .map((res) => {
            //     return res.json();
            // })  // JigProfile[]
            .map((res: any[]) => { // JigProfile[]
                return res.map(obj => obj);
            }) //
            .map((res) => new audit.AuditJigGetJigProfileModelInfoSuccess(res)) // JigProfile[]
            // If request fails, dispatch failed action
            .catch(error => Observable.of(new audit.AuditJigGetJigProfileModelInfoFail(undefined)))
        );

    // ******************************
    @Effect()
    submitAuditReport$ = this.actions$
        .ofType(AuditJigActionTypes.AUDIT_JIG_SUBMIT_AUDIT_REPORT)
        .map(toPayload)
        .switchMap(payload => this.auditJigBackEndService.SubmitAuditReport(payload)
            .map((res) => new audit.AuditJigSubmitAuditReportSuccess(res)) // res.json()
            .catch(error => Observable.of(new audit.AuditJigSubmitAuditReportFail(undefined)))
        );
}
