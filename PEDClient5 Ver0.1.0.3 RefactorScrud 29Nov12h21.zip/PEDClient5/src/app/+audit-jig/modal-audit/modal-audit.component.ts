
import { Component, Input, Output, EventEmitter, OnInit, OnChanges, OnDestroy, ElementRef, ViewChild } from '@angular/core';
import { ChangeDetectionStrategy, ChangeDetectorRef, AfterViewInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';

import { ModalAuditSetting, ModalAuditOutput } from '../modal-audit.model';

@Component({
  selector: 'app-modal-audit',
  templateUrl: './modal-audit.component.html',
  styleUrls: ['./modal-audit.component.css']
})
export class ModalAuditComponent implements OnInit, AfterViewInit, OnChanges {

  @ViewChild('btnModal') btnModal: ElementRef;
  @ViewChild('btnCloseModal') btnCloseModal: ElementRef;
  @Output() modalClose: EventEmitter<any> = new EventEmitter();
  // @Output() mdOutput: EventEmitter<any> = new EventEmitter();
  // @Input() buttons: string[];
  // mdSetting: ModalAuditSetting; //
  // viewMode: string; // 'dialog': app-modal-dialog
  //                     // 'search': app-modal-search
  // formModal: FormGroup;



  // @Input() mdSetting: ModalAuditSetting;
  mdSetting: ModalAuditSetting;
  @Output() mdOutput: EventEmitter<any> = new EventEmitter();
  // mdSetting: ModalAuditSetting;
  public myFocusTriggeringEventEmitter = new EventEmitter<boolean>();
  formModalAudit: FormGroup;

  constructor(
    public cdRef: ChangeDetectorRef,
    public fb: FormBuilder
  ) {
    // Ini for FormGroup
    this.formModalAudit = this.fb.group({
        autoNext: false,
        barcode: ''
    });
    // //
    // this.mdSetting.isVisible = true;
  }

  ngOnInit() {
    // this.buttons = ['Test1', 'Test2', 'Test3'];
    // this.show();
  }

  ngAfterViewInit() {
    // this.show();
  }

  ngOnChanges() {
    // this.show();
  }

  // buttonClick(i: number) { // User click on button event. i: id of button
  //   // alert(i);
  //   this.mdOutput.emit(i);
  // }

  // SearchOutput(event: any) {
  //   // alert(JSON.stringify(event));
  //   this.mdSearchOutput = event;
  // }

  checkEnter() {
    this.buttonClick(0);
  }

  buttonClick(index: number) {

    this.myFocusTriggeringEventEmitter.emit(true);

    const output = <ModalAuditOutput>{};
    output.setting = this.mdSetting;
    // Inform what button pressed?
    output.buttonDatas = this.mdSetting.buttons.map((item, i) => (i === index) ? true : false);
    output.buttonPress = this.mdSetting.buttons.filter((item, i) => (i === index))[0];
    // Inform about barcode
    output.outputObjects = [];
    output.outputObjects.push(this.formModalAudit.get('barcode').value);
    // Emit
    this.mdOutput.emit(output);

    // Clear current barcode value on input, prepare for new one audit
    this.formModalAudit.patchValue({'barcode': ''});
  }

  checkInputBarcode() {
    this.buttonClick(0);
  }

  show() {
    if (this.btnModal !== undefined) {
      const event = new MouseEvent('click', {bubbles: true});
      this.btnModal.nativeElement.dispatchEvent(event);
    }
    // const event = new MouseEvent('click', {bubbles: true});
    // this.btnModal.nativeElement.dispatchEvent(event);
  }

  requestShow(setting: ModalAuditSetting) {
    this.mdSetting = setting;
    // this.show();
    this.cdRef.detectChanges();
    this.show();
  }

  close() {
    // alert('close!');
    const event2 = new MouseEvent('click', {bubbles: true});
    this.btnCloseModal.nativeElement.dispatchEvent(event2);
  }

  closeEmitEvent() {
    this.modalClose.emit(true);
  }

}
