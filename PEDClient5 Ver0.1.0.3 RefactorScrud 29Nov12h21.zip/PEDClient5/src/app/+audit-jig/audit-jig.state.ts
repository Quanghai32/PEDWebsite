﻿import { createSelector, createFeatureSelector } from '@ngrx/store';

import { ViewMode, JigProfile } from './audit-jig.model';

export interface AuditJigState {
    viewMode: ViewMode; // View Mode of Audit Application
    models: string[]; // List of available model => user select 1 model to start audit
    jigProfiles: JigProfile[]; // List of Jig Profile correspond to Model want to do audit
    message: string; // Message display to inform or warning user
}

export const AuditJigInitialState: AuditJigState = {
    viewMode: ViewMode.viewAuditAction,
    models: [],
    jigProfiles: [],
    message : 'To start Audit Jig: First select model, Input Cell name and click START button!'
};

export const getAuditJigState = createFeatureSelector<AuditJigState>('auditJig');
