﻿import { AuditResult } from './audit-jig.model';


// Input Info of Searching
export interface ModalAuditSetting {
    source: any; // name of source which is owner of modal dialog
    sourceID: any; // ID of source Action (The ID of List Item Element?)

    // Setting for modal view
    isVisible: boolean; // Control visibility of Modal Dialog
    title: string; // Title of Modal Dialog
    message: string; // Main Message of Modal Dialog
    buttons: string[]; // User can add a number of custom button to Modal Dialog 

    // Hold Last item result checking
    lastItemResult: AuditResult;
}

// Output of Searching
export interface ModalAuditOutput {

    setting: ModalAuditSetting; // Original setting

    // Result
    buttonPress: string; // Name of button press
    buttonDatas: boolean[]; // Indicate what button user already press

    // For searching output
    // When display modal form for searching,
    // user will select some object from result table & press some button
    // Output of all these action is list of selected object!
    outputObjects: any[];
}
