﻿import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/Observable';

import * as appSetting from '../app.setting';
import { ViewMode, JigProfile, AuditJigReportDTO } from './audit-jig.model';

@Injectable()
export class AuditJigBackEndService {

    constructor(public http: HttpClient) {

    }

    // Get List of Product Model Info
    getProductModels(): Observable<Object> {
        const url: string = appSetting.backendUrl + '/api/productModels';
        return this.http.get(url);
    }

    // Get Jig Profiles of Model
    getJigProfileModelInfo(model: string): Observable<Object> {
        const url = appSetting.backendUrl + '/api/auditJigs/jigProfile';

        return this.http.get(url, {
            params: new HttpParams().set('model', model)
        });
    }

    // Submit Report
    SubmitAuditReport(auditJigReport: AuditJigReportDTO): Observable<Object> {
        const body = JSON.stringify(auditJigReport);
        return this.http.post(appSetting.backendUrl + '/api/auditJigs/', body);
    }
}
