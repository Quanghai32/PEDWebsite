﻿
import { Action, ActionReducer } from '@ngrx/store';

import { AuditJigState, AuditJigInitialState } from './audit-jig.state';
import { ViewMode, JigProfile } from './audit-jig.model';
import { AuditJigActionTypes } from './audit-jig.actions';

import * as audit from './audit-jig.actions';

export function auditJigReducer(
  state = AuditJigInitialState,
  action: audit.Actions
): AuditJigState {
  switch (action.type) {

    case audit.AuditJigActionTypes.AUDIT_JIG_CHANGE_VIEW_MODE: {
      return <AuditJigState>Object.assign({}, state, { viewMode: action.payload });
    }

    case audit.AuditJigActionTypes.AUDIT_JIG_GET_PRODUCT_MODEL_SUCCESS: {
        return <AuditJigState>Object.assign({}, state, { models: action.payload });
    }

    case audit.AuditJigActionTypes.AUDIT_JIG_GET_JIG_PROFILE_MODEL_INFO_SUCCESS: {
        return <AuditJigState>Object.assign({}, state, { jigProfiles: action.payload });
    }

    case audit.AuditJigActionTypes.AUDIT_JIG_SUBMIT_AUDIT_REPORT_SUCCESS: {
        return <AuditJigState>Object.assign({}, state,
                {
                    viewMode: ViewMode.viewAuditAction, // Return to main page
                    message: 'Successfully saving Audit Report. Click \'ResetAll\' to start new audit!'
                }
            );
    }

    case audit.AuditJigActionTypes.AUDIT_JIG_SUBMIT_AUDIT_REPORT_FAIL: {
        return <AuditJigState>Object.assign({}, state,
                {
                    viewMode: ViewMode.viewAuditAction, // Return to main page
                    message: 'Saving Audit Report Fail. Please contact PED for help or Click \'ResetAll\' to start new audit!'
                }
            );
    }

    case audit.AuditJigActionTypes.AUDIT_JIG_RESET: {
         return <AuditJigState>Object.assign({}, AuditJigInitialState,
                {
                    models: state.models // Keep model info already load
                }
            );
    }

    default: {
      return state;
    }
  }
}
