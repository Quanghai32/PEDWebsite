import { Component, OnInit } from '@angular/core';
import * as appSetting from '../../app.setting';

@Component({
  selector: 'app-bottom-bar',
  templateUrl: './bottom-bar.component.html',
  styleUrls: ['./bottom-bar.component.css']
})
export class BottomBarComponent {
  appVersion: string;
  constructor() {
    this.appVersion = appSetting.appVersion;
  }

}
