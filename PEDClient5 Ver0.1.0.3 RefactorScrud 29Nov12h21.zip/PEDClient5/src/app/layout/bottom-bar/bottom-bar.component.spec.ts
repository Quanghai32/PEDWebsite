import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BottomBarComponent } from './bottom-bar.component';
import { DebugElement } from '@angular/core/src/debug/debug_node';
// import { By } from 'selenium-webdriver';
import { By } from '@angular/platform-browser';

describe('BottomBarComponent', () => {
  let component: BottomBarComponent;
  let fixture: ComponentFixture<BottomBarComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BottomBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BottomBarComponent);
    component = fixture.componentInstance;
    de = fixture.debugElement.query(By.css('.ver'));
    el = de.nativeElement;
    //
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should display original title', () => {
    expect(el.textContent).toContain(component.appVersion);
  });

  it('should display different title', () => {
    component.appVersion = '123';
    fixture.detectChanges();
    expect(el.textContent).toContain('123');
  });

});
