import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ad-sidebar',
  templateUrl: './ad-sidebar.component.html',
  styleUrls: ['./ad-sidebar.component.css']
})
export class AdSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
