import { Component, OnInit } from '@angular/core';

import { UserService } from '../../core/services/user/user.service';

@Component({
  selector: 'app-top-header',
  templateUrl: './top-header.component.html',
  styleUrls: ['./top-header.component.css']
})
export class TopHeaderComponent implements OnInit {

  constructor(public userService: UserService) { }

  ngOnInit() {
  }

    logoutHandle() {
    this.userService.LogOutHandle();
  }

}
