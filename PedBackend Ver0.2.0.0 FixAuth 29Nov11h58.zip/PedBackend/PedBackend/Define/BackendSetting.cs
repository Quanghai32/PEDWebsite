﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PedBackend.Define
{
    public static class BackendSetting
    {
        public static string BackendAddress = "http://localhost:58310/";

        public static SymmetricSecurityKey GetSymmetricSecurityKey()
        {
            var keyByteArray = Encoding.ASCII.GetBytes("MySuperSecrets1111111111111111111111111111111111");
            return new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(keyByteArray);
        }
    }
}
