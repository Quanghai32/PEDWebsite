﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;

namespace PedServer.Define
{
    /// <summary>
    /// Since Asp .net core Authorization Attribute is declarative
    /// to avoid directly input string parameter, we define all Claims here to using VS intellisense
    /// </summary>
    public static class ClaimDefine
    {
        public static class WebAppRole
        {
            //ClaimType
            public const string ClaimType = "WebAppRole";

            //Role definition
            public const string Admin = "WebAppRole.Admin";
            public const string Mod = "WebAppRole.Mod";
            public const string PowerUser = "WebAppRole.PowerUser";
            public const string User = "WebAppRole.User";
            //Not yet assign user
            public const string None = "WebAppRole.None";

            public static List<Claim> GetAllClaim()
            {
                List<Claim> lstRet = new List<Claim>();

                lstRet.Add(new IdentityUserClaim<int>()
                {
                    ClaimType = WebAppRole.ClaimType,
                    ClaimValue = WebAppRole.Admin,
                }.ToClaim());

                lstRet.Add(new IdentityUserClaim<int>()
                {
                    ClaimType = WebAppRole.ClaimType,
                    ClaimValue = WebAppRole.Mod,
                }.ToClaim());

                lstRet.Add(new IdentityUserClaim<int>()
                {
                    ClaimType = WebAppRole.ClaimType,
                    ClaimValue = WebAppRole.PowerUser,
                }.ToClaim());

                lstRet.Add(new IdentityUserClaim<int>()
                {
                    ClaimType = WebAppRole.ClaimType,
                    ClaimValue = WebAppRole.User,
                }.ToClaim());

                lstRet.Add(new IdentityUserClaim<int>()
                {
                    ClaimType = WebAppRole.ClaimType,
                    ClaimValue = WebAppRole.None,
                }.ToClaim());

                return lstRet;
            }
        }

        //JigRequest Definition
        public static class JigRequest
        {
            //ClaimType
            public const string ClaimType = "JigRequestClaim";

            //ClaimValue
            public const string CanRequestorCreate = "JigRequest.CanRequestorCreate";
            public const string CanRequestorEdit = "JigRequest.CanRequestorEdit";
            public const string CanRequestorDelete = "JigRequest.CanRequestorDelete";
            public const string CanRequestorApprove = "JigRequest.CanRequestorDeptApprove";


            public static List<Claim> GetAllClaim()
            {
                List<Claim> lstRet = new List<Claim>();

                lstRet.Add(new IdentityUserClaim<int>()
                {
                    ClaimType = JigRequest.ClaimType,
                    ClaimValue = JigRequest.CanRequestorCreate,
                }.ToClaim());

                lstRet.Add(new IdentityUserClaim<int>()
                {
                    ClaimType = JigRequest.ClaimType,
                    ClaimValue = JigRequest.CanRequestorEdit,
                }.ToClaim());

                lstRet.Add(new IdentityUserClaim<int>()
                {
                    ClaimType = JigRequest.ClaimType,
                    ClaimValue = JigRequest.CanRequestorDelete,
                }.ToClaim());

                lstRet.Add(new IdentityUserClaim<int>()
                {
                    ClaimType = JigRequest.ClaimType,
                    ClaimValue = JigRequest.CanRequestorApprove,
                }.ToClaim());

                return lstRet;
            }
        }

        //For station control application
        public static class Station
        {
            //ClaimType
            public const string ClaimType = "StationClaim";

            //ClaimValue
            public const string CanCreate = "Station.CanCreate";
            public const string CanEdit = "Station.CanEdit";
            public const string CanDelete = "Station.CanDelete";
        }


        //Get all Claim into list
        public static List<Claim> GetAllClaim()
        {
            List<Claim> lstRet = new List<Claim>();

            //Add Web App Roles
            lstRet.AddRange(WebAppRole.GetAllClaim());

            //Add Jig Request Claim
            lstRet.AddRange(JigRequest.GetAllClaim());


            //Add Station Claim
            lstRet.Add(new IdentityUserClaim<int>()
            {
                ClaimType = Station.ClaimType,
                ClaimValue = Station.CanCreate
            }.ToClaim());

            lstRet.Add(new IdentityUserClaim<int>()
            {
                ClaimType = Station.ClaimType,
                ClaimValue = Station.CanEdit
            }.ToClaim());

            lstRet.Add(new IdentityUserClaim<int>()
            {
                ClaimType = Station.ClaimType,
                ClaimValue = Station.CanDelete
            }.ToClaim());

            //return list of claim
            return lstRet;
        }


        //Method to ini for all Claim Type - register all claim to Authorization service
        public static void RegisterAllClaims(ref AuthorizationOptions options)
        {
            List<Claim> lstClaim = GetAllClaim();
            foreach (var claim in lstClaim)
            {
                //Note: Do not use claim.Type => must use claim.Type!
                options.AddPolicy(claim.Value, policy => policy.RequireClaim(claim.Type));
            }
        }
    }
    
}

