﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PedServer.Models;

namespace PedServer.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            // Customize the ASP.NET Identity model and override the defaults if needed.
            // For example, you can rename the ASP.NET Identity table names and more.
            // Add your customizations after calling base.OnModelCreating(builder);
            builder.Entity<Models.UserControl.EventAssignment>()
                .HasKey(c => new { c.UserEventID, c.ApplicationUserID });

            builder.Entity<Models.ModelJigInfo.ModelJigProfileAssignment>()
                .HasKey(c => new { c.ModelJigInfoID, c.JigProfileID });

            builder.Entity<Models.MacAddress.MacAddressRange>()
                .HasKey(m => new { m.LowRange, m.HighRange });
        }

        //For General user control
        public DbSet<PedServer.Models.ApplicationRole> ApplicationRole { get; set; }
        public DbSet<PedServer.Models.UserControl.UserEvent> UserEvent { get; set; }
        public DbSet<Models.UserControl.EventAssignment> EventAssignments { get; set; }

        // For Standard Approve
        public DbSet<Models.standardApprove.VerifyRequest> VerifyRequests { get; set; }
        public DbSet<Models.standardApprove.VerifyResult> VerifyResults { get; set; }

        //For testing CRUD
        public DbSet<PedServer.Models.StandardCrud.TestCrud> TestCrud { get; set; }
        public DbSet<Models.StandardCrud.TestCrudItemList> TestCrudItemList { get; set; }

        //Product Model Control
        public DbSet<PedServer.Models.ProductModel.ProductModel> ProductModel { get; set; }

        //Product Model Info
        public DbSet<PedServer.Models.ProductModelInfo.ProductModelInfo> ProductModelInfos { get; set; }

        //Mac Address 
        public DbSet<Models.MacAddress.MacAddress> MacAddresses { get; set; }

        //Jig Profile Control
        public DbSet<PedServer.Models.JigProfile.JigProfile> JigProfile { get; set; }

        //For Model Jig Info Control
        public DbSet<PedServer.Models.ModelJigInfo.ModelJigInfo> ModelJigInfo { get; set; }
        public DbSet<PedServer.Models.ModelJigInfo.ModelJigProfileAssignment> ModelJigProfileAssignment { get; set; }
        public DbSet<PedServer.Models.JigBarcode.JigBarcode> JigBarcodes { get; set; }

        //For Station Control App
        public DbSet<PedServer.Models.StationControl.Station> Station { get; set; }

        //For Audit Jig
        public DbSet<PedServer.Models.AuditJig.AuditJigReport> AuditJigReports { get; set; }
        public DbSet<PedServer.Models.AuditJig.AuditItemResult> AuditItemResults { get; set; }

        //For Jig Request Control App
        public DbSet<PedServer.Models.JigRequest.JigRequest> JigRequest { get; set; }
        public DbSet<PedServer.Models.JigRequest.RequisitionArea> RequisitionArea { get; set; }
        public DbSet<PedServer.Models.JigRequest.RequestDeptReqInfo> RequestDeptReqInfo { get; set; }
        public DbSet<PedServer.Models.JigRequest.IssuedByInfo> IssuedByInfo { get; set; }


    }
}
