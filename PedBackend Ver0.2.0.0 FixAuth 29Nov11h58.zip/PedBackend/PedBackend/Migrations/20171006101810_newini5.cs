﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;

namespace PedServer.Migrations
{
    public partial class newini5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ApproveBackendLink",
                table: "BackendApproveStatus",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ObjectID",
                table: "BackendApproveStatus",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ApproveBackendLink",
                table: "BackendApproveStatus");

            migrationBuilder.DropColumn(
                name: "ObjectID",
                table: "BackendApproveStatus");
        }
    }
}
