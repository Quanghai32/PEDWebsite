﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;

namespace PedServer.Migrations
{
    public partial class newini8 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TestCrud_BackendApproveStatus_BackendApproveStatusID",
                table: "TestCrud");

            migrationBuilder.DropTable(
                name: "BackendApproveStatus");

            migrationBuilder.DropIndex(
                name: "IX_TestCrud_BackendApproveStatusID",
                table: "TestCrud");

            migrationBuilder.DropColumn(
                name: "BackendApproveStatusID",
                table: "TestCrud");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "BackendApproveStatusID",
                table: "TestCrud",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "BackendApproveStatus",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    ActionDescription = table.Column<string>(nullable: true),
                    ApplicationName = table.Column<string>(nullable: true),
                    ApproveBackendLink = table.Column<string>(nullable: true),
                    ApproveLink = table.Column<string>(nullable: true),
                    ApproveStatus = table.Column<string>(nullable: true),
                    ApproverUserName = table.Column<string>(nullable: true),
                    ObjectID = table.Column<string>(nullable: true),
                    RequestorComment = table.Column<string>(nullable: true),
                    RequestorUserName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BackendApproveStatus", x => x.ID);
                });

            migrationBuilder.CreateIndex(
                name: "IX_TestCrud_BackendApproveStatusID",
                table: "TestCrud",
                column: "BackendApproveStatusID");

            migrationBuilder.AddForeignKey(
                name: "FK_TestCrud_BackendApproveStatus_BackendApproveStatusID",
                table: "TestCrud",
                column: "BackendApproveStatusID",
                principalTable: "BackendApproveStatus",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
