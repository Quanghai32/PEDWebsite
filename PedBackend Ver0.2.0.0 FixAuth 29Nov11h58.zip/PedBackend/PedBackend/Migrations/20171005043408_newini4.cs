﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;

namespace PedServer.Migrations
{
    public partial class newini4 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "BackendApproveStatusID",
                table: "TestCrud",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_TestCrud_BackendApproveStatusID",
                table: "TestCrud",
                column: "BackendApproveStatusID");

            migrationBuilder.AddForeignKey(
                name: "FK_TestCrud_BackendApproveStatus_BackendApproveStatusID",
                table: "TestCrud",
                column: "BackendApproveStatusID",
                principalTable: "BackendApproveStatus",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TestCrud_BackendApproveStatus_BackendApproveStatusID",
                table: "TestCrud");

            migrationBuilder.DropIndex(
                name: "IX_TestCrud_BackendApproveStatusID",
                table: "TestCrud");

            migrationBuilder.DropColumn(
                name: "BackendApproveStatusID",
                table: "TestCrud");
        }
    }
}
