﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;

namespace PedServer.Migrations
{
    public partial class newini0 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AspNetRoles",
                columns: table => new
                {
                    Id = table.Column<string>(nullable: false),
                    ConcurrencyStamp = table.Column<string>(nullable: true),
                    Discriminator = table.Column<string>(nullable: false),
                    Name = table.Column<string>(maxLength: 256, nullable: true),
                    NormalizedName = table.Column<string>(maxLength: 256, nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: true),
                    Description = table.Column<string>(nullable: true),
                    IPAddress = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserTokens",
                columns: table => new
                {
                    UserId = table.Column<string>(nullable: false),
                    LoginProvider = table.Column<string>(nullable: false),
                    Name = table.Column<string>(nullable: false),
                    Value = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserTokens", x => new { x.UserId, x.LoginProvider, x.Name });
                });

            migrationBuilder.CreateTable(
                name: "OpenIddictApplications",
                columns: table => new
                {
                    Id = table.Column<string>(nullable: false),
                    ClientId = table.Column<string>(nullable: true),
                    ClientSecret = table.Column<string>(nullable: true),
                    DisplayName = table.Column<string>(nullable: true),
                    LogoutRedirectUri = table.Column<string>(nullable: true),
                    RedirectUri = table.Column<string>(nullable: true),
                    Type = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OpenIddictApplications", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "OpenIddictScopes",
                columns: table => new
                {
                    Id = table.Column<string>(nullable: false),
                    Description = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OpenIddictScopes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUsers",
                columns: table => new
                {
                    Id = table.Column<string>(nullable: false),
                    AccessFailedCount = table.Column<int>(nullable: false),
                    ConcurrencyStamp = table.Column<string>(nullable: true),
                    Dept = table.Column<string>(nullable: true),
                    Email = table.Column<string>(maxLength: 256, nullable: true),
                    EmailConfirmed = table.Column<bool>(nullable: false),
                    LockoutEnabled = table.Column<bool>(nullable: false),
                    LockoutEnd = table.Column<DateTimeOffset>(nullable: true),
                    Name = table.Column<string>(nullable: true),
                    NormalizedEmail = table.Column<string>(maxLength: 256, nullable: true),
                    NormalizedUserName = table.Column<string>(maxLength: 256, nullable: true),
                    PasswordHash = table.Column<string>(nullable: true),
                    PhoneNumber = table.Column<string>(nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(nullable: false),
                    SecurityStamp = table.Column<string>(nullable: true),
                    TwoFactorEnabled = table.Column<bool>(nullable: false),
                    UserName = table.Column<string>(maxLength: 256, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUsers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "JigProfile",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    DesignID = table.Column<string>(nullable: true),
                    JigCode = table.Column<string>(nullable: true),
                    JigName = table.Column<string>(nullable: true),
                    JigRank = table.Column<string>(nullable: true),
                    JigRev = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_JigProfile", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MacAddresses",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    MacModelName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MacAddresses", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "ProductModel",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    CodeName = table.Column<string>(nullable: true),
                    EngineName = table.Column<string>(nullable: true),
                    ModelName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductModel", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "BackendApproveStatus",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    ActionDescription = table.Column<string>(nullable: true),
                    ApplicationName = table.Column<string>(nullable: true),
                    ApproveLink = table.Column<string>(nullable: true),
                    ApproveStatus = table.Column<string>(nullable: true),
                    ApproverUserName = table.Column<string>(nullable: true),
                    RequestorComment = table.Column<string>(nullable: true),
                    RequestorUserName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BackendApproveStatus", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TestCrud",
                columns: table => new
                {
                    Id = table.Column<string>(nullable: false),
                    Property2 = table.Column<string>(nullable: true),
                    Property3 = table.Column<bool>(nullable: false),
                    Property4 = table.Column<string>(nullable: true),
                    SampleDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TestCrud", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Station",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Line = table.Column<string>(nullable: false),
                    ProductModel = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Station", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "UserEvent",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    Application = table.Column<string>(nullable: true),
                    EventLink = table.Column<string>(nullable: true),
                    EventName = table.Column<string>(nullable: true),
                    EventTime = table.Column<DateTime>(nullable: false),
                    Message = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserEvent", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoleClaims",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    ClaimType = table.Column<string>(nullable: true),
                    ClaimValue = table.Column<string>(nullable: true),
                    RoleId = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoleClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetRoleClaims_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "OpenIddictAuthorizations",
                columns: table => new
                {
                    Id = table.Column<string>(nullable: false),
                    ApplicationId = table.Column<string>(nullable: true),
                    Scope = table.Column<string>(nullable: true),
                    Subject = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OpenIddictAuthorizations", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OpenIddictAuthorizations_OpenIddictApplications_ApplicationId",
                        column: x => x.ApplicationId,
                        principalTable: "OpenIddictApplications",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserClaims",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    ClaimType = table.Column<string>(nullable: true),
                    ClaimValue = table.Column<string>(nullable: true),
                    UserId = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetUserClaims_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserLogins",
                columns: table => new
                {
                    LoginProvider = table.Column<string>(nullable: false),
                    ProviderKey = table.Column<string>(nullable: false),
                    ProviderDisplayName = table.Column<string>(nullable: true),
                    UserId = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserLogins", x => new { x.LoginProvider, x.ProviderKey });
                    table.ForeignKey(
                        name: "FK_AspNetUserLogins_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserRoles",
                columns: table => new
                {
                    UserId = table.Column<string>(nullable: false),
                    RoleId = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserRoles", x => new { x.UserId, x.RoleId });
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "IssuedByInfo",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    ApplicationUserID = table.Column<string>(nullable: true),
                    date = table.Column<DateTime>(nullable: false),
                    phoneNumber = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IssuedByInfo", x => x.ID);
                    table.ForeignKey(
                        name: "FK_IssuedByInfo_AspNetUsers_ApplicationUserID",
                        column: x => x.ApplicationUserID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "JigBarcodes",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    BarcodeData = table.Column<string>(nullable: true),
                    JigProfileID = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_JigBarcodes", x => x.ID);
                    table.ForeignKey(
                        name: "FK_JigBarcodes_JigProfile_JigProfileID",
                        column: x => x.JigProfileID,
                        principalTable: "JigProfile",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "MacAddressRange",
                columns: table => new
                {
                    LowRange = table.Column<string>(nullable: false),
                    HighRange = table.Column<string>(nullable: false),
                    MacAddressID = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MacAddressRange", x => new { x.LowRange, x.HighRange });
                    table.ForeignKey(
                        name: "FK_MacAddressRange_MacAddresses_MacAddressID",
                        column: x => x.MacAddressID,
                        principalTable: "MacAddresses",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "AuditJigReports",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    ApplicationUserID = table.Column<string>(nullable: true),
                    AuditTime = table.Column<DateTime>(nullable: false),
                    CellName = table.Column<string>(nullable: true),
                    ProductModelID = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuditJigReports", x => x.ID);
                    table.ForeignKey(
                        name: "FK_AuditJigReports_AspNetUsers_ApplicationUserID",
                        column: x => x.ApplicationUserID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_AuditJigReports_ProductModel_ProductModelID",
                        column: x => x.ProductModelID,
                        principalTable: "ProductModel",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ModelJigInfo",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    ProductModelID = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ModelJigInfo", x => x.ID);
                    table.ForeignKey(
                        name: "FK_ModelJigInfo_ProductModel_ProductModelID",
                        column: x => x.ProductModelID,
                        principalTable: "ProductModel",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ProductModelInfos",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    LoaderVersion = table.Column<string>(nullable: true),
                    ProductModelID = table.Column<string>(nullable: true),
                    RomVersion = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductModelInfos", x => x.ID);
                    table.ForeignKey(
                        name: "FK_ProductModelInfos_ProductModel_ProductModelID",
                        column: x => x.ProductModelID,
                        principalTable: "ProductModel",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "TestCrudItemList",
                columns: table => new
                {
                    Id = table.Column<string>(nullable: false),
                    ItemProperty1 = table.Column<string>(nullable: true),
                    ItemProperty2 = table.Column<string>(nullable: true),
                    ItemProperty3 = table.Column<bool>(nullable: false),
                    ItemProperty4 = table.Column<string>(nullable: true),
                    TestCrudID = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TestCrudItemList", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TestCrudItemList_TestCrud_TestCrudID",
                        column: x => x.TestCrudID,
                        principalTable: "TestCrud",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "EventAssignments",
                columns: table => new
                {
                    UserEventID = table.Column<string>(nullable: false),
                    ApplicationUserID = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EventAssignments", x => new { x.UserEventID, x.ApplicationUserID });
                    table.ForeignKey(
                        name: "FK_EventAssignments_AspNetUsers_ApplicationUserID",
                        column: x => x.ApplicationUserID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_EventAssignments_UserEvent_UserEventID",
                        column: x => x.UserEventID,
                        principalTable: "UserEvent",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "OpenIddictTokens",
                columns: table => new
                {
                    Id = table.Column<string>(nullable: false),
                    ApplicationId = table.Column<string>(nullable: true),
                    AuthorizationId = table.Column<string>(nullable: true),
                    Subject = table.Column<string>(nullable: true),
                    Type = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OpenIddictTokens", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OpenIddictTokens_OpenIddictApplications_ApplicationId",
                        column: x => x.ApplicationId,
                        principalTable: "OpenIddictApplications",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_OpenIddictTokens_OpenIddictAuthorizations_AuthorizationId",
                        column: x => x.AuthorizationId,
                        principalTable: "OpenIddictAuthorizations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "RequestDeptReqInfo",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    IssuedByInfoID = table.Column<string>(nullable: true),
                    deptCode = table.Column<string>(nullable: true),
                    deptName = table.Column<string>(nullable: true),
                    requestControlNo = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RequestDeptReqInfo", x => x.ID);
                    table.ForeignKey(
                        name: "FK_RequestDeptReqInfo_IssuedByInfo_IssuedByInfoID",
                        column: x => x.IssuedByInfoID,
                        principalTable: "IssuedByInfo",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "AuditItemResults",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    AuditJigReportID = table.Column<string>(nullable: true),
                    Barcode = table.Column<string>(nullable: true),
                    JigProfileID = table.Column<string>(nullable: true),
                    Note = table.Column<string>(nullable: true),
                    Result = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuditItemResults", x => x.ID);
                    table.ForeignKey(
                        name: "FK_AuditItemResults_AuditJigReports_AuditJigReportID",
                        column: x => x.AuditJigReportID,
                        principalTable: "AuditJigReports",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_AuditItemResults_JigProfile_JigProfileID",
                        column: x => x.JigProfileID,
                        principalTable: "JigProfile",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ModelJigProfileAssignment",
                columns: table => new
                {
                    ModelJigInfoID = table.Column<string>(nullable: false),
                    JigProfileID = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ModelJigProfileAssignment", x => new { x.ModelJigInfoID, x.JigProfileID });
                    table.ForeignKey(
                        name: "FK_ModelJigProfileAssignment_JigProfile_JigProfileID",
                        column: x => x.JigProfileID,
                        principalTable: "JigProfile",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ModelJigProfileAssignment_ModelJigInfo_ModelJigInfoID",
                        column: x => x.ModelJigInfoID,
                        principalTable: "ModelJigInfo",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "RequisitionArea",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    RequestDeptReqInfoID = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RequisitionArea", x => x.ID);
                    table.ForeignKey(
                        name: "FK_RequisitionArea_RequestDeptReqInfo_RequestDeptReqInfoID",
                        column: x => x.RequestDeptReqInfoID,
                        principalTable: "RequestDeptReqInfo",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "JigRequest",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    RequisitionAreaID = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_JigRequest", x => x.ID);
                    table.ForeignKey(
                        name: "FK_JigRequest_RequisitionArea_RequisitionAreaID",
                        column: x => x.RequisitionAreaID,
                        principalTable: "RequisitionArea",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                table: "AspNetRoles",
                column: "NormalizedName",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_AspNetRoleClaims_RoleId",
                table: "AspNetRoleClaims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserClaims_UserId",
                table: "AspNetUserClaims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserLogins_UserId",
                table: "AspNetUserLogins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_RoleId",
                table: "AspNetUserRoles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "IX_OpenIddictApplications_ClientId",
                table: "OpenIddictApplications",
                column: "ClientId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_OpenIddictAuthorizations_ApplicationId",
                table: "OpenIddictAuthorizations",
                column: "ApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_OpenIddictTokens_ApplicationId",
                table: "OpenIddictTokens",
                column: "ApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_OpenIddictTokens_AuthorizationId",
                table: "OpenIddictTokens",
                column: "AuthorizationId");

            migrationBuilder.CreateIndex(
                name: "EmailIndex",
                table: "AspNetUsers",
                column: "NormalizedEmail");

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                table: "AspNetUsers",
                column: "NormalizedUserName",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_AuditItemResults_AuditJigReportID",
                table: "AuditItemResults",
                column: "AuditJigReportID");

            migrationBuilder.CreateIndex(
                name: "IX_AuditItemResults_JigProfileID",
                table: "AuditItemResults",
                column: "JigProfileID");

            migrationBuilder.CreateIndex(
                name: "IX_AuditJigReports_ApplicationUserID",
                table: "AuditJigReports",
                column: "ApplicationUserID");

            migrationBuilder.CreateIndex(
                name: "IX_AuditJigReports_ProductModelID",
                table: "AuditJigReports",
                column: "ProductModelID");

            migrationBuilder.CreateIndex(
                name: "IX_JigBarcodes_JigProfileID",
                table: "JigBarcodes",
                column: "JigProfileID");

            migrationBuilder.CreateIndex(
                name: "IX_IssuedByInfo_ApplicationUserID",
                table: "IssuedByInfo",
                column: "ApplicationUserID");

            migrationBuilder.CreateIndex(
                name: "IX_JigRequest_RequisitionAreaID",
                table: "JigRequest",
                column: "RequisitionAreaID");

            migrationBuilder.CreateIndex(
                name: "IX_RequestDeptReqInfo_IssuedByInfoID",
                table: "RequestDeptReqInfo",
                column: "IssuedByInfoID");

            migrationBuilder.CreateIndex(
                name: "IX_RequisitionArea_RequestDeptReqInfoID",
                table: "RequisitionArea",
                column: "RequestDeptReqInfoID");

            migrationBuilder.CreateIndex(
                name: "IX_MacAddressRange_MacAddressID",
                table: "MacAddressRange",
                column: "MacAddressID");

            migrationBuilder.CreateIndex(
                name: "IX_ModelJigInfo_ProductModelID",
                table: "ModelJigInfo",
                column: "ProductModelID");

            migrationBuilder.CreateIndex(
                name: "IX_ModelJigProfileAssignment_JigProfileID",
                table: "ModelJigProfileAssignment",
                column: "JigProfileID");

            migrationBuilder.CreateIndex(
                name: "IX_ProductModelInfos_ProductModelID",
                table: "ProductModelInfos",
                column: "ProductModelID");

            migrationBuilder.CreateIndex(
                name: "IX_TestCrudItemList_TestCrudID",
                table: "TestCrudItemList",
                column: "TestCrudID");

            migrationBuilder.CreateIndex(
                name: "IX_EventAssignments_ApplicationUserID",
                table: "EventAssignments",
                column: "ApplicationUserID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AspNetRoleClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserLogins");

            migrationBuilder.DropTable(
                name: "AspNetUserRoles");

            migrationBuilder.DropTable(
                name: "AspNetUserTokens");

            migrationBuilder.DropTable(
                name: "OpenIddictScopes");

            migrationBuilder.DropTable(
                name: "OpenIddictTokens");

            migrationBuilder.DropTable(
                name: "AuditItemResults");

            migrationBuilder.DropTable(
                name: "JigBarcodes");

            migrationBuilder.DropTable(
                name: "JigRequest");

            migrationBuilder.DropTable(
                name: "MacAddressRange");

            migrationBuilder.DropTable(
                name: "ModelJigProfileAssignment");

            migrationBuilder.DropTable(
                name: "ProductModelInfos");

            migrationBuilder.DropTable(
                name: "BackendApproveStatus");

            migrationBuilder.DropTable(
                name: "TestCrudItemList");

            migrationBuilder.DropTable(
                name: "Station");

            migrationBuilder.DropTable(
                name: "EventAssignments");

            migrationBuilder.DropTable(
                name: "AspNetRoles");

            migrationBuilder.DropTable(
                name: "OpenIddictAuthorizations");

            migrationBuilder.DropTable(
                name: "AuditJigReports");

            migrationBuilder.DropTable(
                name: "RequisitionArea");

            migrationBuilder.DropTable(
                name: "MacAddresses");

            migrationBuilder.DropTable(
                name: "JigProfile");

            migrationBuilder.DropTable(
                name: "ModelJigInfo");

            migrationBuilder.DropTable(
                name: "TestCrud");

            migrationBuilder.DropTable(
                name: "UserEvent");

            migrationBuilder.DropTable(
                name: "OpenIddictApplications");

            migrationBuilder.DropTable(
                name: "RequestDeptReqInfo");

            migrationBuilder.DropTable(
                name: "ProductModel");

            migrationBuilder.DropTable(
                name: "IssuedByInfo");

            migrationBuilder.DropTable(
                name: "AspNetUsers");
        }
    }
}
