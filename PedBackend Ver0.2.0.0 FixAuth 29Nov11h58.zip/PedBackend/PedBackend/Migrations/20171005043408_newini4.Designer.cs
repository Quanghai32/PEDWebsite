﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using PedServer.Data;

namespace PedServer.Migrations
{
    [DbContext(typeof(ApplicationDbContext))]
    [Migration("20171005043408_newini4")]
    partial class newini4
    {
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("ProductVersion", "1.1.1")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("Microsoft.AspNetCore.Identity.EntityFrameworkCore.IdentityRole", b =>
                {
                    b.Property<string>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("ConcurrencyStamp")
                        .IsConcurrencyToken();

                    b.Property<string>("Discriminator")
                        .IsRequired();

                    b.Property<string>("Name")
                        .HasMaxLength(256);

                    b.Property<string>("NormalizedName")
                        .HasMaxLength(256);

                    b.HasKey("Id");

                    b.HasIndex("NormalizedName")
                        .IsUnique()
                        .HasName("RoleNameIndex");

                    b.ToTable("AspNetRoles");

                    b.HasDiscriminator<string>("Discriminator").HasValue("IdentityRole");
                });

            modelBuilder.Entity("Microsoft.AspNetCore.Identity.EntityFrameworkCore.IdentityRoleClaim<string>", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("ClaimType");

                    b.Property<string>("ClaimValue");

                    b.Property<string>("RoleId")
                        .IsRequired();

                    b.HasKey("Id");

                    b.HasIndex("RoleId");

                    b.ToTable("AspNetRoleClaims");
                });

            modelBuilder.Entity("Microsoft.AspNetCore.Identity.EntityFrameworkCore.IdentityUserClaim<string>", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("ClaimType");

                    b.Property<string>("ClaimValue");

                    b.Property<string>("UserId")
                        .IsRequired();

                    b.HasKey("Id");

                    b.HasIndex("UserId");

                    b.ToTable("AspNetUserClaims");
                });

            modelBuilder.Entity("Microsoft.AspNetCore.Identity.EntityFrameworkCore.IdentityUserLogin<string>", b =>
                {
                    b.Property<string>("LoginProvider");

                    b.Property<string>("ProviderKey");

                    b.Property<string>("ProviderDisplayName");

                    b.Property<string>("UserId")
                        .IsRequired();

                    b.HasKey("LoginProvider", "ProviderKey");

                    b.HasIndex("UserId");

                    b.ToTable("AspNetUserLogins");
                });

            modelBuilder.Entity("Microsoft.AspNetCore.Identity.EntityFrameworkCore.IdentityUserRole<string>", b =>
                {
                    b.Property<string>("UserId");

                    b.Property<string>("RoleId");

                    b.HasKey("UserId", "RoleId");

                    b.HasIndex("RoleId");

                    b.ToTable("AspNetUserRoles");
                });

            modelBuilder.Entity("Microsoft.AspNetCore.Identity.EntityFrameworkCore.IdentityUserToken<string>", b =>
                {
                    b.Property<string>("UserId");

                    b.Property<string>("LoginProvider");

                    b.Property<string>("Name");

                    b.Property<string>("Value");

                    b.HasKey("UserId", "LoginProvider", "Name");

                    b.ToTable("AspNetUserTokens");
                });

            modelBuilder.Entity("OpenIddict.Models.OpenIddictApplication", b =>
                {
                    b.Property<string>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("ClientId");

                    b.Property<string>("ClientSecret");

                    b.Property<string>("DisplayName");

                    b.Property<string>("LogoutRedirectUri");

                    b.Property<string>("RedirectUri");

                    b.Property<string>("Type");

                    b.HasKey("Id");

                    b.HasIndex("ClientId")
                        .IsUnique();

                    b.ToTable("OpenIddictApplications");
                });

            modelBuilder.Entity("OpenIddict.Models.OpenIddictAuthorization", b =>
                {
                    b.Property<string>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("ApplicationId");

                    b.Property<string>("Scope");

                    b.Property<string>("Subject");

                    b.HasKey("Id");

                    b.HasIndex("ApplicationId");

                    b.ToTable("OpenIddictAuthorizations");
                });

            modelBuilder.Entity("OpenIddict.Models.OpenIddictScope", b =>
                {
                    b.Property<string>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Description");

                    b.HasKey("Id");

                    b.ToTable("OpenIddictScopes");
                });

            modelBuilder.Entity("OpenIddict.Models.OpenIddictToken", b =>
                {
                    b.Property<string>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("ApplicationId");

                    b.Property<string>("AuthorizationId");

                    b.Property<string>("Subject");

                    b.Property<string>("Type");

                    b.HasKey("Id");

                    b.HasIndex("ApplicationId");

                    b.HasIndex("AuthorizationId");

                    b.ToTable("OpenIddictTokens");
                });

            modelBuilder.Entity("PedServer.Models.ApplicationUser", b =>
                {
                    b.Property<string>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("AccessFailedCount");

                    b.Property<string>("ConcurrencyStamp")
                        .IsConcurrencyToken();

                    b.Property<string>("Dept");

                    b.Property<string>("Email")
                        .HasMaxLength(256);

                    b.Property<bool>("EmailConfirmed");

                    b.Property<bool>("LockoutEnabled");

                    b.Property<DateTimeOffset?>("LockoutEnd");

                    b.Property<string>("Name");

                    b.Property<string>("NormalizedEmail")
                        .HasMaxLength(256);

                    b.Property<string>("NormalizedUserName")
                        .HasMaxLength(256);

                    b.Property<string>("PasswordHash");

                    b.Property<string>("PhoneNumber");

                    b.Property<bool>("PhoneNumberConfirmed");

                    b.Property<string>("SecurityStamp");

                    b.Property<bool>("TwoFactorEnabled");

                    b.Property<string>("UserName")
                        .HasMaxLength(256);

                    b.HasKey("Id");

                    b.HasIndex("NormalizedEmail")
                        .HasName("EmailIndex");

                    b.HasIndex("NormalizedUserName")
                        .IsUnique()
                        .HasName("UserNameIndex");

                    b.ToTable("AspNetUsers");
                });

            modelBuilder.Entity("PedServer.Models.AuditJig.AuditItemResult", b =>
                {
                    b.Property<string>("ID")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("AuditJigReportID");

                    b.Property<string>("Barcode");

                    b.Property<string>("JigProfileID");

                    b.Property<string>("Note");

                    b.Property<string>("Result");

                    b.HasKey("ID");

                    b.HasIndex("AuditJigReportID");

                    b.HasIndex("JigProfileID");

                    b.ToTable("AuditItemResults");
                });

            modelBuilder.Entity("PedServer.Models.AuditJig.AuditJigReport", b =>
                {
                    b.Property<string>("ID")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("ApplicationUserID");

                    b.Property<DateTime>("AuditTime");

                    b.Property<string>("CellName");

                    b.Property<string>("ProductModelID");

                    b.HasKey("ID");

                    b.HasIndex("ApplicationUserID");

                    b.HasIndex("ProductModelID");

                    b.ToTable("AuditJigReports");
                });

            modelBuilder.Entity("PedServer.Models.JigBarcode.JigBarcode", b =>
                {
                    b.Property<string>("ID")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("BarcodeData");

                    b.Property<string>("JigProfileID");

                    b.HasKey("ID");

                    b.HasIndex("JigProfileID");

                    b.ToTable("JigBarcodes");
                });

            modelBuilder.Entity("PedServer.Models.JigProfile.JigProfile", b =>
                {
                    b.Property<string>("ID")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("DesignID");

                    b.Property<string>("JigCode");

                    b.Property<string>("JigName");

                    b.Property<string>("JigRank");

                    b.Property<string>("JigRev");

                    b.HasKey("ID");

                    b.ToTable("JigProfile");
                });

            modelBuilder.Entity("PedServer.Models.JigRequest.IssuedByInfo", b =>
                {
                    b.Property<string>("ID")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("ApplicationUserID");

                    b.Property<DateTime>("date");

                    b.Property<string>("phoneNumber");

                    b.HasKey("ID");

                    b.HasIndex("ApplicationUserID");

                    b.ToTable("IssuedByInfo");
                });

            modelBuilder.Entity("PedServer.Models.JigRequest.JigRequest", b =>
                {
                    b.Property<string>("ID")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("RequisitionAreaID");

                    b.HasKey("ID");

                    b.HasIndex("RequisitionAreaID");

                    b.ToTable("JigRequest");
                });

            modelBuilder.Entity("PedServer.Models.JigRequest.RequestDeptReqInfo", b =>
                {
                    b.Property<string>("ID")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("IssuedByInfoID");

                    b.Property<string>("deptCode");

                    b.Property<string>("deptName");

                    b.Property<string>("requestControlNo");

                    b.HasKey("ID");

                    b.HasIndex("IssuedByInfoID");

                    b.ToTable("RequestDeptReqInfo");
                });

            modelBuilder.Entity("PedServer.Models.JigRequest.RequisitionArea", b =>
                {
                    b.Property<string>("ID")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("RequestDeptReqInfoID");

                    b.HasKey("ID");

                    b.HasIndex("RequestDeptReqInfoID");

                    b.ToTable("RequisitionArea");
                });

            modelBuilder.Entity("PedServer.Models.MacAddress.MacAddress", b =>
                {
                    b.Property<string>("ID")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("MacModelName");

                    b.HasKey("ID");

                    b.ToTable("MacAddresses");
                });

            modelBuilder.Entity("PedServer.Models.MacAddress.MacAddressRange", b =>
                {
                    b.Property<string>("LowRange");

                    b.Property<string>("HighRange");

                    b.Property<string>("MacAddressID");

                    b.HasKey("LowRange", "HighRange");

                    b.HasIndex("MacAddressID");

                    b.ToTable("MacAddressRange");
                });

            modelBuilder.Entity("PedServer.Models.ModelJigInfo.ModelJigInfo", b =>
                {
                    b.Property<string>("ID")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("ProductModelID");

                    b.HasKey("ID");

                    b.HasIndex("ProductModelID");

                    b.ToTable("ModelJigInfo");
                });

            modelBuilder.Entity("PedServer.Models.ModelJigInfo.ModelJigProfileAssignment", b =>
                {
                    b.Property<string>("ModelJigInfoID");

                    b.Property<string>("JigProfileID");

                    b.HasKey("ModelJigInfoID", "JigProfileID");

                    b.HasIndex("JigProfileID");

                    b.ToTable("ModelJigProfileAssignment");
                });

            modelBuilder.Entity("PedServer.Models.ProductModel.ProductModel", b =>
                {
                    b.Property<string>("ID")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("CodeName");

                    b.Property<string>("EngineName");

                    b.Property<string>("ModelName");

                    b.HasKey("ID");

                    b.ToTable("ProductModel");
                });

            modelBuilder.Entity("PedServer.Models.ProductModelInfo.ProductModelInfo", b =>
                {
                    b.Property<string>("ID")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("LoaderVersion");

                    b.Property<string>("ProductModelID");

                    b.Property<string>("RomVersion");

                    b.HasKey("ID");

                    b.HasIndex("ProductModelID");

                    b.ToTable("ProductModelInfos");
                });

            modelBuilder.Entity("PedServer.Models.standardApprove.BackendApproveStatus", b =>
                {
                    b.Property<string>("ID")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("ActionDescription");

                    b.Property<string>("ApplicationName");

                    b.Property<string>("ApproveLink");

                    b.Property<string>("ApproveStatus");

                    b.Property<string>("ApproverUserName");

                    b.Property<string>("RequestorComment");

                    b.Property<string>("RequestorUserName");

                    b.HasKey("ID");

                    b.ToTable("BackendApproveStatus");
                });

            modelBuilder.Entity("PedServer.Models.StandardCrud.TestCrud", b =>
                {
                    b.Property<string>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("BackendApproveStatusID");

                    b.Property<string>("Property2");

                    b.Property<bool>("Property3");

                    b.Property<string>("Property4");

                    b.Property<DateTime>("SampleDate");

                    b.HasKey("Id");

                    b.HasIndex("BackendApproveStatusID");

                    b.ToTable("TestCrud");
                });

            modelBuilder.Entity("PedServer.Models.StandardCrud.TestCrudItemList", b =>
                {
                    b.Property<string>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("ItemProperty1");

                    b.Property<string>("ItemProperty2");

                    b.Property<bool>("ItemProperty3");

                    b.Property<string>("ItemProperty4");

                    b.Property<string>("TestCrudID");

                    b.HasKey("Id");

                    b.HasIndex("TestCrudID");

                    b.ToTable("TestCrudItemList");
                });

            modelBuilder.Entity("PedServer.Models.StationControl.Station", b =>
                {
                    b.Property<int>("id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("strLine")
                        .IsRequired()
                        .HasColumnName("Line");

                    b.Property<string>("strProductModel")
                        .HasColumnName("ProductModel");

                    b.HasKey("id");

                    b.ToTable("Station");
                });

            modelBuilder.Entity("PedServer.Models.UserControl.EventAssignment", b =>
                {
                    b.Property<string>("UserEventID");

                    b.Property<string>("ApplicationUserID");

                    b.HasKey("UserEventID", "ApplicationUserID");

                    b.HasIndex("ApplicationUserID");

                    b.ToTable("EventAssignments");
                });

            modelBuilder.Entity("PedServer.Models.UserControl.UserEvent", b =>
                {
                    b.Property<string>("ID")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Application");

                    b.Property<string>("EventLink");

                    b.Property<string>("EventName");

                    b.Property<DateTime>("EventTime");

                    b.Property<string>("Message");

                    b.HasKey("ID");

                    b.ToTable("UserEvent");
                });

            modelBuilder.Entity("PedServer.Models.ApplicationRole", b =>
                {
                    b.HasBaseType("Microsoft.AspNetCore.Identity.EntityFrameworkCore.IdentityRole");

                    b.Property<DateTime>("CreatedDate");

                    b.Property<string>("Description");

                    b.Property<string>("IPAddress");

                    b.ToTable("ApplicationRole");

                    b.HasDiscriminator().HasValue("ApplicationRole");
                });

            modelBuilder.Entity("Microsoft.AspNetCore.Identity.EntityFrameworkCore.IdentityRoleClaim<string>", b =>
                {
                    b.HasOne("Microsoft.AspNetCore.Identity.EntityFrameworkCore.IdentityRole")
                        .WithMany("Claims")
                        .HasForeignKey("RoleId")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("Microsoft.AspNetCore.Identity.EntityFrameworkCore.IdentityUserClaim<string>", b =>
                {
                    b.HasOne("PedServer.Models.ApplicationUser")
                        .WithMany("Claims")
                        .HasForeignKey("UserId")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("Microsoft.AspNetCore.Identity.EntityFrameworkCore.IdentityUserLogin<string>", b =>
                {
                    b.HasOne("PedServer.Models.ApplicationUser")
                        .WithMany("Logins")
                        .HasForeignKey("UserId")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("Microsoft.AspNetCore.Identity.EntityFrameworkCore.IdentityUserRole<string>", b =>
                {
                    b.HasOne("Microsoft.AspNetCore.Identity.EntityFrameworkCore.IdentityRole")
                        .WithMany("Users")
                        .HasForeignKey("RoleId")
                        .OnDelete(DeleteBehavior.Cascade);

                    b.HasOne("PedServer.Models.ApplicationUser")
                        .WithMany("Roles")
                        .HasForeignKey("UserId")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("OpenIddict.Models.OpenIddictAuthorization", b =>
                {
                    b.HasOne("OpenIddict.Models.OpenIddictApplication", "Application")
                        .WithMany("Authorizations")
                        .HasForeignKey("ApplicationId");
                });

            modelBuilder.Entity("OpenIddict.Models.OpenIddictToken", b =>
                {
                    b.HasOne("OpenIddict.Models.OpenIddictApplication", "Application")
                        .WithMany("Tokens")
                        .HasForeignKey("ApplicationId");

                    b.HasOne("OpenIddict.Models.OpenIddictAuthorization", "Authorization")
                        .WithMany("Tokens")
                        .HasForeignKey("AuthorizationId");
                });

            modelBuilder.Entity("PedServer.Models.AuditJig.AuditItemResult", b =>
                {
                    b.HasOne("PedServer.Models.AuditJig.AuditJigReport", "AuditJigReport")
                        .WithMany("AuditItemResults")
                        .HasForeignKey("AuditJigReportID");

                    b.HasOne("PedServer.Models.JigProfile.JigProfile", "JigProfile")
                        .WithMany()
                        .HasForeignKey("JigProfileID");
                });

            modelBuilder.Entity("PedServer.Models.AuditJig.AuditJigReport", b =>
                {
                    b.HasOne("PedServer.Models.ApplicationUser", "ApplicationUser")
                        .WithMany()
                        .HasForeignKey("ApplicationUserID");

                    b.HasOne("PedServer.Models.ProductModel.ProductModel", "ProductModel")
                        .WithMany()
                        .HasForeignKey("ProductModelID");
                });

            modelBuilder.Entity("PedServer.Models.JigBarcode.JigBarcode", b =>
                {
                    b.HasOne("PedServer.Models.JigProfile.JigProfile", "JigProfile")
                        .WithMany()
                        .HasForeignKey("JigProfileID");
                });

            modelBuilder.Entity("PedServer.Models.JigRequest.IssuedByInfo", b =>
                {
                    b.HasOne("PedServer.Models.ApplicationUser", "user")
                        .WithMany()
                        .HasForeignKey("ApplicationUserID");
                });

            modelBuilder.Entity("PedServer.Models.JigRequest.JigRequest", b =>
                {
                    b.HasOne("PedServer.Models.JigRequest.RequisitionArea", "requisitionArea")
                        .WithMany()
                        .HasForeignKey("RequisitionAreaID");
                });

            modelBuilder.Entity("PedServer.Models.JigRequest.RequestDeptReqInfo", b =>
                {
                    b.HasOne("PedServer.Models.JigRequest.IssuedByInfo", "issuedByInfo")
                        .WithMany()
                        .HasForeignKey("IssuedByInfoID");
                });

            modelBuilder.Entity("PedServer.Models.JigRequest.RequisitionArea", b =>
                {
                    b.HasOne("PedServer.Models.JigRequest.RequestDeptReqInfo", "requestDeptReqInfo")
                        .WithMany()
                        .HasForeignKey("RequestDeptReqInfoID");
                });

            modelBuilder.Entity("PedServer.Models.MacAddress.MacAddressRange", b =>
                {
                    b.HasOne("PedServer.Models.MacAddress.MacAddress", "MacAddress")
                        .WithMany("MacAddressRanges")
                        .HasForeignKey("MacAddressID");
                });

            modelBuilder.Entity("PedServer.Models.ModelJigInfo.ModelJigInfo", b =>
                {
                    b.HasOne("PedServer.Models.ProductModel.ProductModel", "ProductModel")
                        .WithMany()
                        .HasForeignKey("ProductModelID");
                });

            modelBuilder.Entity("PedServer.Models.ModelJigInfo.ModelJigProfileAssignment", b =>
                {
                    b.HasOne("PedServer.Models.JigProfile.JigProfile", "JigProfile")
                        .WithMany()
                        .HasForeignKey("JigProfileID")
                        .OnDelete(DeleteBehavior.Cascade);

                    b.HasOne("PedServer.Models.ModelJigInfo.ModelJigInfo", "ModelJigInfo")
                        .WithMany("ModelJigProfileAssignments")
                        .HasForeignKey("ModelJigInfoID")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("PedServer.Models.ProductModelInfo.ProductModelInfo", b =>
                {
                    b.HasOne("PedServer.Models.ProductModel.ProductModel", "ProductModel")
                        .WithMany()
                        .HasForeignKey("ProductModelID");
                });

            modelBuilder.Entity("PedServer.Models.StandardCrud.TestCrud", b =>
                {
                    b.HasOne("PedServer.Models.standardApprove.BackendApproveStatus", "BackendApproveStatus")
                        .WithMany()
                        .HasForeignKey("BackendApproveStatusID");
                });

            modelBuilder.Entity("PedServer.Models.StandardCrud.TestCrudItemList", b =>
                {
                    b.HasOne("PedServer.Models.StandardCrud.TestCrud", "TestCrud")
                        .WithMany("TestCrudItemLists")
                        .HasForeignKey("TestCrudID");
                });

            modelBuilder.Entity("PedServer.Models.UserControl.EventAssignment", b =>
                {
                    b.HasOne("PedServer.Models.ApplicationUser", "ApplicationUser")
                        .WithMany("EventAssignments")
                        .HasForeignKey("ApplicationUserID")
                        .OnDelete(DeleteBehavior.Cascade);

                    b.HasOne("PedServer.Models.UserControl.UserEvent", "UserEvent")
                        .WithMany("EventAssignments")
                        .HasForeignKey("UserEventID")
                        .OnDelete(DeleteBehavior.Cascade);
                });
        }
    }
}
