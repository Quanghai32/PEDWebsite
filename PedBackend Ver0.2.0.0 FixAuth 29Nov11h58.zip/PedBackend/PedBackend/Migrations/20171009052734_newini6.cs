﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;

namespace PedServer.Migrations
{
    public partial class newini6 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "VerifyRequests",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    ActionDescription = table.Column<string>(nullable: true),
                    ApplicationName = table.Column<string>(nullable: true),
                    ApproverUserName = table.Column<string>(nullable: true),
                    BackendLink = table.Column<string>(nullable: true),
                    FrontendLink = table.Column<string>(nullable: true),
                    ObjectID = table.Column<string>(nullable: true),
                    RequestorComment = table.Column<string>(nullable: true),
                    RequestorUserName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VerifyRequests", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "VerifyResults",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    Comment = table.Column<string>(nullable: true),
                    Result = table.Column<string>(nullable: true),
                    VerifyRequestID = table.Column<string>(nullable: true),
                    VerifyTime = table.Column<DateTime>(nullable: false),
                    isDone = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VerifyResults", x => x.ID);
                    table.ForeignKey(
                        name: "FK_VerifyResults_VerifyRequests_VerifyRequestID",
                        column: x => x.VerifyRequestID,
                        principalTable: "VerifyRequests",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_VerifyResults_VerifyRequestID",
                table: "VerifyResults",
                column: "VerifyRequestID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "VerifyResults");

            migrationBuilder.DropTable(
                name: "VerifyRequests");
        }
    }
}
