﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using PedServer.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using AspNet.Security.OpenIdConnect.Primitives;
using PedServer.Models;
using Newtonsoft.Json;
using PedServer.Define;
using PedServer.Server.Services;
using PedServer;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using PedBackend.Define;

namespace PedBackend
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
			// services.AddMvc();
			services.AddCors();

			// Add framework services.
			services.AddDbContext<ApplicationDbContext>(options =>
			{
				options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"));
				//
				options.UseOpenIddict();
			});

			// Configure Identity to use the same JWT claims as OpenIddict instead
			// of the legacy WS-Federation claims it uses by default (ClaimTypes),
			// which saves you from doing the mapping in your authorization controller.
			services.Configure<IdentityOptions>(options =>
			{
				options.ClaimsIdentity.UserNameClaimType = OpenIdConnectConstants.Claims.Name;
				options.ClaimsIdentity.UserIdClaimType = OpenIdConnectConstants.Claims.Subject;
				options.ClaimsIdentity.RoleClaimType = OpenIdConnectConstants.Claims.Role;
			});

			// Register the OpenIddict services.
			services.AddOpenIddict(options =>
			{
				// Register the Entity Framework stores.
				options.AddEntityFrameworkCoreStores<ApplicationDbContext>();

				// Register the ASP.NET Core MVC binder used by OpenIddict.
				// Note: if you don't call this method, you won't be able to
				// bind OpenIdConnectRequest or OpenIdConnectResponse parameters.
				options.AddMvcBinders();

				// Enable the token endpoint.
				options.EnableTokenEndpoint("/connect/token");

				// Enable the password flow.
				options.AllowPasswordFlow();
				options.AllowRefreshTokenFlow();

				// During development, you can disable the HTTPS requirement.
				options.DisableHttpsRequirement();

				// Note: to use JWT access tokens instead of the default
				// encrypted format, the following lines are required:
				//Note that if select JWT => cannot simple access api like simple token...
				options.UseJsonWebTokens();
                // options.AddEphemeralSigningKey();
                options.AddSigningKey(BackendSetting.GetSymmetricSecurityKey());
            });

			services.AddIdentity<ApplicationUser, ApplicationRole>()
				.AddEntityFrameworkStores<ApplicationDbContext>()
				.AddDefaultTokenProviders();

			// Add framework services.
			services.AddMvc();
			services.AddMvc()
				.AddJsonOptions(
				x => x.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore) //Prevent when some model looping...
				.AddJsonOptions(
				x => x.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Utc) //Prevent UTC datetime binding decrease 1 day!
				.AddJsonOptions(options =>
				{
					options.SerializerSettings.ContractResolver = new Newtonsoft.Json.Serialization.DefaultContractResolver(); //Prevent camel case auto-become first lower case => use Pascal case
				});

			//Add claims for user authorization service
			services.AddAuthorization(options =>
			{
				//Well, with asp .net core, the Claim only exist in database if there is at least an user has that Claim
				//If the user own that claim deleted, that claim also be deleted!
				//So if we want to find all Claims exists in Database, we can look through userManager to get all Claims of all user exist!
				ClaimDefine.RegisterAllClaims(ref options);
			});

            // If you prefer using JWT, don't forget to disable the automatic
            // JWT -> WS-Federation claims mapping used by the JWT middleware:
            JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Clear();
            JwtSecurityTokenHandler.DefaultOutboundClaimTypeMap.Clear();

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                options.Audience = Configuration[BackendSetting.BackendAddress];
                options.Authority = Configuration[BackendSetting.BackendAddress];
                options.RequireHttpsMetadata = false;
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    IssuerSigningKey = BackendSetting.GetSymmetricSecurityKey(),
                    ValidAudience = BackendSetting.BackendAddress,
                    ValidIssuer = BackendSetting.BackendAddress,
                    NameClaimType = OpenIdConnectConstants.Claims.Name,
                    RoleClaimType = OpenIdConnectConstants.Claims.Role
                };
            });


            // Add application services.
            services.AddTransient<IEmailSender, AuthMessageSender>();
			services.AddTransient<ISmsSender, AuthMessageSender>();

			//Add Automapper
			var config = new AutoMapper.MapperConfiguration(cfg =>
			{
				cfg.AddProfile(new MappingProfile());
			});

			var mapper = config.CreateMapper();
			services.AddSingleton(mapper);
			//services.AddAutoMapper(typeof(Startup));
		}

		// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
		public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
			loggerFactory.AddConsole(Configuration.GetSection("Logging"));
			loggerFactory.AddDebug();

			app.UseStaticFiles();

			app.UseAuthentication();

			app.UseCors(builder => builder.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());

			app.UseMvc();
            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });

        }
    }
}
