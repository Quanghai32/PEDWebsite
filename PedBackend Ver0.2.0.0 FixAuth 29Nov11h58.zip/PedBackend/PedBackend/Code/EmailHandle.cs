﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MailKit.Net.Smtp;
using MimeKit;
using MailKit.Security;

namespace PedServer.Code
{
    public class EmailHandle
    {
        public async Task SendEmailAsync(string email, string subject, string message)
        {
            var emailMessage = new MimeMessage();

            emailMessage.From.Add(new MailboxAddress("Joe Bloggs", "jbloggs@example.com"));
            emailMessage.To.Add(new MailboxAddress("", email));
            emailMessage.Subject = subject;
            emailMessage.Body = new TextPart("plain") { Text = message };

            using (var client = new SmtpClient())
            {
                client.LocalDomain = "some.domain.com";
                await client.ConnectAsync("smtp.relay.uri", 25, SecureSocketOptions.None).ConfigureAwait(false);
                await client.SendAsync(emailMessage).ConfigureAwait(false);
                await client.DisconnectAsync(true).ConfigureAwait(false);
            }
        }


        public void Test(string subject, string message)
        {
            var emailMessage = new MimeMessage();

            emailMessage.From.Add(new MailboxAddress("Hoang Do Van", "hoangbk3010@gmail.com"));
            emailMessage.To.Add(new MailboxAddress("Hoang Do Van", "hoangbk3010@gmail.com"));
            emailMessage.Subject = subject;
            emailMessage.Body = new TextPart("plain") { Text = message };

            //using (var client = new SmtpClient())
            //{
            //    var credentials = new NetworkCredential
            //    {
            //        UserName = "hoangbk3010@gmail.com", // replace with valid value
            //        Password = "ekgucxgkdercjtqi" // replace with valid value
            //    };

            //    //client.LocalDomain = "domain.com";
            //    // check your smtp server setting and amend accordingly:
            //    await client.ConnectAsync("smtp.gmail.com", 465, SecureSocketOptions.Auto).ConfigureAwait(false);
            //    await client.AuthenticateAsync(credentials);
            //    await client.SendAsync(emailMessage).ConfigureAwait(false);
            //    await client.DisconnectAsync(true).ConfigureAwait(false);
            //}

            using (var client = new SmtpClient())
            {
                client.Connect("smtp.gmail.com", 465, SecureSocketOptions.Auto);
                client.AuthenticationMechanisms.Remove("XOAUTH2"); // Must be removed for Gmail SMTP
                client.Authenticate("hoangbk3010@gmail.com", "ekgucxgkdercjtqi");
                client.Send(emailMessage);
                client.Disconnect(true);
            }
        }

    }
}
