﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using PedServer.Define;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using PedServer.Data;
using Microsoft.AspNetCore.Identity;
using PedServer.Models;
using System.Security.Claims;
using PedServer.Models.StandardCrud;
using AutoMapper;
using Newtonsoft.Json.Linq;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PedServer.api
{
    public class ApplicationUserDTO
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public bool EmailConfirmed { get; set; }
        public string Dept { get; set; } //Department of User
        public string Password { get; set; }
    }

    [Produces("application/json")]
    [Route("api/[controller]")]
    // [Authorize(ActiveAuthenticationSchemes = "Bearer", Policy = ClaimDefine.WebAppRole.Admin)]
    [Authorize(AuthenticationSchemes = "Bearer", Policy = ClaimDefine.WebAppRole.Admin)]
    public class AppUsersController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ApplicationDbContext _context;
        private IMapper _mapper;

        public AppUsersController(
            ApplicationDbContext context, 
            UserManager<ApplicationUser> userManager,
            IMapper mapper
            )
        {
            _context = context;
            _userManager = userManager;
            _mapper = mapper;
        }

        [HttpGet("info")]
        public JsonResult GetInfo()
        {
            StandardCrudInfo test = new StandardCrudInfo();
            //Form building
            List<ElementDescription> elementDescriptions = new List<ElementDescription>();
            //public string Id { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "Id",
                displayName = "ID",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        isPrimaryKey = true, //This key is primary key => do not allow user for changing on client side
                        propertyName = "Id",
                        displayName="ID",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null,
                        cssStyle = new CssStyle
                        {
                            color = "red"
                        }
                    }
                }
            });
            //public string Name { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "Name",
                displayName = "Name",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "Name",
                        displayName="Name",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });

            //public string UserName { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "UserName",
                displayName = "User Name",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "UserName",
                        displayName="User Name",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });

            //public string Email { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "Email",
                displayName = "Email",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "Email",
                        displayName="Email",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });

            //public bool EmailConfirmed { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "EmailConfirmed",
                displayName = "Email Confirm",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "EmailConfirmed",
                        displayName="Email Confirm",
                        dataType="string",
                        controlType="checkbox",
                        selectDatas = null
                    }
                }
            });

            //public string Dept { get; set; } //Department of User
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "Dept",
                displayName = "Dept",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "Dept",
                        displayName="Dept",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });

            //public string Password { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "Password",
                displayName = "Password",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "Password",
                        displayName="Password",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });
            test.model = elementDescriptions;
            return Json(test);
        }

        /// <summary>
        /// Get Data Info
        /// </summary>
        /// <returns></returns>
        [HttpGet("DataInfo")]
        public StandardDataInfo GetDataInfo()
        {
            StandardDataInfo info = new StandardDataInfo();
            var test = _userManager.Users.Count();
            info.total = test;
            return info;
        }

        // GET: api/values
        [HttpGet]
        public JsonResult Get(int offset, int take)
        {
            //If take = 0: get all item from offset to end
            var lstTest = new List<ApplicationUserDTO>();

            if (take != 0)
            {
                lstTest = _userManager.Users
                    .Skip(offset)
                    .Take(take)
                    .Select(u => _mapper.Map<ApplicationUser,ApplicationUserDTO>(u)).ToList();
            }
            else
            {
                lstTest = _userManager.Users
                    .Skip(offset)
                    .Select(u => _mapper.Map<ApplicationUser, ApplicationUserDTO>(u)).ToList();
            }

            return Json(lstTest);
        }

        [HttpGet("Search")]
        public JsonResult GetSearch(string searchQuery, string searchCriteria)
        {
            Response.StatusCode = 200;

            try
            {
                //Default is search for all
                var keySearch = searchQuery.ToLower().Trim();

                var lstTest = new List<ApplicationUser>();
                lstTest = _userManager.Users.ToList();

                var lstRet = new List<ApplicationUserDTO>();
                foreach (var item in lstTest)
                {
                    string test2 = "";

                    //JObject jo = JObject.FromObject(item);
                    JObject jo = JObject.FromObject(item, new Newtonsoft.Json.JsonSerializer()
                    {
                        ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        //PreserveReferencesHandling = Newtonsoft.Json.PreserveReferencesHandling.None
                    });
                    //JArray ja = new JArray();
                    foreach (var value in jo.Values())
                    {
                        //ja.Add(value);
                        test2 = test2 + value.ToString() + "\r\n";
                    }

                    if (test2.ToLower().Contains(keySearch))
                    {
                        lstRet.Add(_mapper.Map<ApplicationUser,ApplicationUserDTO>(item));
                    }
                }

                return Json(lstRet);
            }
            catch (Exception ex)
            {
                Response.StatusCode = 400;
                return Json(ex.Message);
            }

        }



        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // GET api/values/5
        [HttpGet("{id}/roles")]
        public string GetRoles(int id)
        {
            return "Role List";
        }


        // POST api/values - Create New Application User
        [HttpPost]
        public async Task<JsonResult> Post([FromBody]ApplicationUserDTO applicationUserDTO) //dynamic allow null value, prevent model binding fail!
        {
            Response.StatusCode = 200;

            try
            {
                applicationUserDTO.Id = null; //Must clear Id!
                var newUser = _mapper.Map<ApplicationUserDTO, ApplicationUser>(applicationUserDTO);

                //create user account in database
                var result = await _userManager.CreateAsync(newUser, applicationUserDTO.Password);
                if(result.Succeeded)
                {
                    applicationUserDTO.Id = newUser.Id;
                    return Json(applicationUserDTO);
                }
                else
                {
                    Response.StatusCode = 400;
                    return Json("Error: " + result.Errors.FirstOrDefault().Description);
                }
               
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return Json(e.ToString());
            }
        }

        // PUT api/values/5
        [HttpPut]
        public async Task<JsonResult> Put([FromBody]ApplicationUserDTO applicationUserDTO)
        {
            Response.StatusCode = 200;

            try
            {
                ApplicationUser user = await _userManager.FindByIdAsync(applicationUserDTO.Id);
                //Only allow Edit some field!
                user.EmailConfirmed = applicationUserDTO.EmailConfirmed;
                user.Dept = applicationUserDTO.Dept;
                user.Name = applicationUserDTO.Name;

                IdentityResult result = await _userManager.UpdateAsync(user);
                if (!result.Succeeded)
                {
                    Response.StatusCode = 400;
                    return Json("Error: " + result.Errors.FirstOrDefault().Description);
                }

                //
                return Json(applicationUserDTO);
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return Json(e.ToString());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public async Task<string> Delete(string id)
        {
            Response.StatusCode = 200;

            try
            {
                string name = string.Empty;
                if (!String.IsNullOrEmpty(id))
                {
                    ApplicationUser user = await _userManager.FindByIdAsync(id);
                    if (user != null)
                    {
                        IdentityResult result = await _userManager.DeleteAsync(user);
                        if (!result.Succeeded)
                        {
                            return "Error";
                        }
                    }
                }
            }
            catch (Exception e)
            {
                return e.ToString();
            }
            return "OK";
        }

    }
}
