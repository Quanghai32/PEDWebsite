﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PedServer.Data;
using PedServer.Models.StandardCrud;
using PedServer.Models.JigProfile;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using AutoMapper;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PedServer.WebApi
{
    //public class JigProfile
    //{
    //    [Key]
    //    public string ID { get; set; } //ID in database
    //    public string DesignID { get; set; } //ID in master jiglist => in the future, this should be replaced by ID in database?

    //    public string JigName { get; set; }
    //    public string JigCode { get; set; }
    //    public string JigRev { get; set; }
    //    //For Ranking
    //    public string JigRank { get; set; }
    //}


    public class JigProfileDTO
    {
        public string ID { get; set; }
        public string DesignID { get; set; }
        //public string DisplayInfo { get; set; } //JigName-JigCode-JigRev
        public string JigName { get; set; }
        public string JigCode { get; set; }
        public string JigRev { get; set; }
    }

    [Produces("application/json")]
    [Route("api/[controller]")]
    public class JigProfilesController : Controller
    {
        private readonly ApplicationDbContext _context;
        // Create a field to store the mapper object
        private readonly IMapper _mapper;

        public JigProfilesController(
            ApplicationDbContext context,
            IMapper mapper
            )
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpGet("info")]
        public JsonResult GetInfo()
        {
            StandardCrudInfo test = new StandardCrudInfo();
            //Form building
            List<ElementDescription> elementDescriptions = new List<ElementDescription>();
            //public string ID { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "ID",
                displayName = "ID",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        isPrimaryKey = true, //This key is primary key => do not allow user for changing on client side
                        propertyName = "ID",
                        displayName="ID",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null,
                        cssStyle = new CssStyle
                        {
                            color = "red"
                        }
                    }
                }
            });
            //public string DesignID { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "DesignID",
                displayName = "Design ID",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "DesignID",
                        displayName="Design ID",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });
            //public string JigName { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "JigName",
                displayName = "Jig Name",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "JigName",
                        displayName="Jig Name",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });
            //public string JigCode { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "JigCode",
                displayName = "Jig Code",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "JigCode",
                        displayName="Jig Code",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });
            //public string JigRev { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "JigRev",
                displayName = "Jig Rev",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "JigRev",
                        displayName="Jig Rev",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });
            //public string JigRank { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "JigRank",
                displayName = "Jig Rank",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "JigRank",
                        displayName="Jig Rank",
                        dataType="string",
                        controlType="select",
                        selectDatas = Enum.GetNames(typeof(jigRanking)).ToList()
                    }
                }
            });

            test.model = elementDescriptions;
            return Json(test);
        }

        /// <summary>
        /// Get Data Info
        /// </summary>
        /// <returns></returns>
        [HttpGet("DataInfo")]
        public StandardDataInfo GetDataInfo()
        {
            StandardDataInfo info = new StandardDataInfo();
            var test = _context.JigProfile.Count();
            info.total = test;
            return info;
        }

        //// GET: api/values
        //[HttpGet]
        //public IEnumerable<JigProfile> Get()
        //{
        //    return _context.JigProfile.ToList()
        //        .OrderBy(j => j.JigRev) //least important
        //        .OrderBy(j=>j.JigCode) //important
        //        .OrderBy(j => j.JigName); //most important
        //}

        [HttpGet]
        public IEnumerable<JigProfile> Get(int offset, int take)
        {
            //If take = 0: get all item from offset to end
            var lstTest = new List<JigProfile>();

            if (take != 0)
            {
                lstTest = _context.JigProfile
                .Skip(offset)
                .Take(take).ToList();
            }
            else
            {
                lstTest = _context.JigProfile
                .Skip(offset).ToList();
            }
            return lstTest
                .OrderBy(j => j.JigRev) //least important
                .OrderBy(j => j.JigCode) //important
                .OrderBy(j => j.JigName); //most important;
        }


        [HttpGet("Search")]
        public IEnumerable<JigProfileDTO> GetSearch(string searchQuery, string searchCriteria)
        {
            //Default is search for all
            var keySearch = searchQuery.ToLower().Trim();

            var lstTest = new List<JigProfile>();
            lstTest = _context.JigProfile.ToList();

            var lstRet = new List<JigProfile>();
            foreach (var item in lstTest)
            {
                string test2 = "";

                JObject jo = JObject.FromObject(item);
                //JArray ja = new JArray();
                foreach (var value in jo.Values())
                {
                    //ja.Add(value);
                    test2 = test2 + value.ToString() + "\r\n";
                }

                if (test2.ToLower().Contains(keySearch))
                {
                    lstRet.Add(item);
                }
            }

            //var lstRet2 = lstRet.Select(item => new JigProfileDTO
            //{
            //    ID = item.ID,
            //    DesignID = item.DesignID,
            //    //DisplayInfo = item.JigName + ";" + item.JigCode + ";" + item.JigRev
            //    JigName = item.JigName,
            //    JigCode = item.JigCode,
            //    JigRev = item.JigRev
            //});

            var lstRet2 = lstRet.Select(item => _mapper.Map<JigProfile,JigProfileDTO>(item));


            return lstRet2
                .OrderBy(j => j.JigRev) //least important
                .OrderBy(j => j.JigCode) //important
                .OrderBy(j => j.JigName); //most important;;
        }

        [HttpPost]
        public JsonResult Post([FromBody]JigProfile jigProfile)
        {
            //First we create new item (Reject "id" key)
            var newJigProfile = new JigProfile
            {
                DesignID = jigProfile.DesignID,
                JigName = jigProfile.JigName,
                JigCode = jigProfile.JigCode,
                JigRev = jigProfile.JigRev,
                JigRank = jigProfile.JigRank
            };

            var test1 = _context.JigProfile.Add(newJigProfile);
            var test2 = _context.SaveChanges();
            //Return saved entity => we need return new created entity because we need info like id to update on view of client side
            return Json(test1.Entity);
        }

        // PUT api/values/5
        [HttpPut]
        public async Task<JsonResult> Put([FromBody] JigProfile jigProfile)
        {
            Response.StatusCode = 200;

            try
            {
                var test1 = _context.JigProfile.Attach(jigProfile);
                _context.Entry(jigProfile).State = EntityState.Modified;

                //Save all change
                await _context.SaveChangesAsync();

                //Reading entiy again and return to frontend
                var result = await _context.JigProfile
                    .SingleOrDefaultAsync(j => j.ID == jigProfile.ID);

                //Return saved entity => we need return new created entity because we need info like id to update on view of client side
                return Json(result);
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return Json(e.ToString());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public async Task<string> Delete(string id)
        {
            Response.StatusCode = 200;

            try
            {
                JigProfile delJigProfile = await _context.JigProfile
                    .SingleOrDefaultAsync(item => item.ID == id);

                //Now deleted 
                _context.JigProfile.Remove(delJigProfile);
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return e.ToString();
            }
            return "OK";
        }
    }
}
