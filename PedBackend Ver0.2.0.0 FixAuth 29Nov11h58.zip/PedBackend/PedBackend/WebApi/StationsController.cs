﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using PedServer.Data;
using PedServer.Models;
using Microsoft.AspNetCore.Authorization;
using PedServer.Define;
using PedServer.Models.StandardCrud;
using PedServer.Models.StationControl;
using Newtonsoft.Json.Linq;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PedServer.api
{
    //[Authorize]
    [Produces("application/json")]
    [Route("api/[controller]")]
    public class StationsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public StationsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("info")]
        public JsonResult GetInfo()
        {
            //StandardCrudInfo test = new StandardCrudInfo();
            //test.model = new string[] {
            //    "id:ID:number:textbox",
            //    "strLine:Line:string:textbox",
            //    "strProductModel:Product Model:string:textbox",
            //};
            //test.primaryKey = "id";

            StandardCrudInfo test = new StandardCrudInfo();
            //Form building
            List<ElementDescription> elementDescriptions = new List<ElementDescription>();
            //"item::id:ID:string:textbox"
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "id",
                displayName = "ID",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        isPrimaryKey = true, //This key is primary key => do not allow user for changing on client side
                        propertyName = "id",
                        displayName="ID",
                        dataType="number",
                        controlType="textbox",
                        selectDatas = null,
                        cssStyle = new CssStyle
                        {
                            color = "red"
                        }
                    }
                }
            });

            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "strLine",
                displayName = "Line",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "strLine",
                        displayName="Line",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });

            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "strProductModel",
                displayName = "Model",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "strProductModel",
                        displayName="Model",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });

            test.model = elementDescriptions;
            return Json(test);
        }

        /// <summary>
        /// Get Data Info
        /// </summary>
        /// <returns></returns>
        [HttpGet("DataInfo")]
        public StandardDataInfo GetDataInfo()
        {
            StandardDataInfo info = new StandardDataInfo();
            var test = _context.Station.Count();
            info.total = test;
            return info;
        }

        // GET: api/values
        //[HttpGet]
        ////[Authorize(Policy = ClaimDefine.Station.CanCreate)] //Only allow user has claim
        ////[Authorize(ActiveAuthenticationSchemes ="Bearer", Roles = ClaimDefine.Station.CanCreate)] //Only allow user has claim
        //[Authorize(ActiveAuthenticationSchemes = "Bearer", Policy = ClaimDefine.Station.CanCreate)] //Only allow user has claim
        //public IEnumerable<Models.StationControl.Station> Get()
        //{
        //    return _context.Station.ToList();
        //}

        // GET: api/values
        [HttpGet]
        [Authorize(ActiveAuthenticationSchemes = "Bearer", Policy = ClaimDefine.Station.CanCreate)] //Only allow user has claim
        public IEnumerable<Models.StationControl.Station> Get(int offset, int take)
        {
            //If take = 0: get all item from offset to end
            var lstTest = new List<Station>();

            if (take != 0)
            {
                lstTest = _context.Station
                .Skip(offset)
                .Take(take).ToList();
            }
            else
            {
                lstTest = _context.Station
                .Skip(offset).ToList();
            }

            return lstTest
                .OrderBy(s=>s.strLine)
                .OrderBy(s=>s.strProductModel);
        }

        [HttpGet("Search")]
        public IEnumerable<Station> GetSearch(string searchQuery, string searchCriteria)
        {
            //Default is search for all
            var keySearch = searchQuery.ToLower().Trim();

            var lstTest = new List<Station>();
            lstTest = _context.Station.ToList();

            var lstRet = new List<Station>();
            foreach (var item in lstTest)
            {
                string test2 = "";

                JObject jo = JObject.FromObject(item);
                //JArray ja = new JArray();
                foreach (var value in jo.Values())
                {
                    //ja.Add(value);
                    test2 = test2 + value.ToString() + "\r\n";
                }

                if (test2.ToLower().Contains(keySearch))
                {
                    lstRet.Add(item);
                }
            }

            return lstRet
                .OrderBy(s=>s.strLine)
                .OrderBy(s=>s.strProductModel);
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        
        [HttpPost]
        public JsonResult Post([FromBody]dynamic station) //Note that we should use dynamic to prevent model Binding Fail
        {
            //Note that we should use dynamic to prevent model Binding Fail
            //Especially when Object model has id type is integer!
            Response.StatusCode = 200;

            try
            {
                //Reject "id" key
                var newStation = new Station
                {
                    strLine = station.strLine,
                    strProductModel = station.strProductModel
                };

                var test1 = _context.Station.Add(newStation);
                var test2 = _context.SaveChanges();

                return Json(test1.Entity);
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return Json(e.ToString());
            }
        }

        [HttpPut]
        public async Task<JsonResult> Put([FromBody] Station station)
        {
            Response.StatusCode = 200;

            try
            {
                _context.Station.Attach(station);
                _context.Entry(station).State = EntityState.Modified;
                var test = await _context.SaveChangesAsync();

                //Reading entiy again and return to frontend
                var result = _context.Station
                    .SingleOrDefault(s=>s.id == station.id);
                //Return saved entity => we need return new created entity because we need info like id to update on view of client side
                return Json(result);
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return Json(e.ToString());
            }
        }


        // DELETE api/values/5
        [HttpDelete("{id}")]
        public string Delete(int id)
        {
            Response.StatusCode = 200;

            try
            {
                Models.StationControl.Station delStation = new Models.StationControl.Station();
                delStation.id = id;
                _context.Station.Remove(delStation);
                _context.SaveChanges();
            }
            catch (Exception e)
            {
                return e.ToString();
            }
            return "OK";
        }
    }
}
