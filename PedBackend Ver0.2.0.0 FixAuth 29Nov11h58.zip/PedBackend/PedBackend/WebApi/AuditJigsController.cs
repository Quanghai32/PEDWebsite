﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PedServer.Data;
using Microsoft.EntityFrameworkCore;
using PedServer.Models.AuditJig;
using PedServer.Models;
using PedServer.Models.JigProfile;
using PedServer.Models.StandardCrud;
using Microsoft.AspNetCore.Identity;
using Newtonsoft.Json.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PedServer.WebApi
{
    public class AuditJigReportDTO
    {
        public string ID { get; set; }
        public DateTime AuditTime { get; set; }

        //Foreign Key - Product Model
        public string ProductModel { get; set; }

        //Cell Name
        public string CellName { get; set; }

        //Foreign Key - Auditor
        public string Auditor { get; set; } //User name of Auditor

        //Result of List item audit
        public List<AuditItemResultDTO> AuditItemResultDTOs { get; set; }
    }

    public class AuditItemResultDTO
    {
        //public string ID { get; set; } //No need, always create new
        public string Barcode { get; set; } //barcode of audit item object

        //Flatenning Jig Profile 
        public string JigProfileID { get; set; }
        public string DesignID { get; set; }
        public string JigName { get; set; }
        public string JigCode { get; set; }
        public string JigRev { get; set; }

        //Result & Note
        public string Result { get; set; } //OK, NG or Unknown
        public string Note { get; set; } //Note about result
    }



    [Produces("application/json")]
    [Route("api/[controller]")]
    public class AuditJigsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> userManager;

        public AuditJigsController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            this.userManager = userManager;
        }

        [HttpGet("info")]
        public JsonResult GetInfo()
        {
            StandardCrudInfo test = new StandardCrudInfo();
            //Form building
            List<ElementDescription> elementDescriptions = new List<ElementDescription>();
            //public string ID { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "ID",
                displayName = "ID",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        isPrimaryKey = true, //This key is primary key => do not allow user for changing on client side
                        propertyName = "ID",
                        displayName="ID",
                        dataType="string",
                        controlType="textbox",
                        cssStyle = new CssStyle
                        {
                            color = "red"
                        }
                    }
                }
            });
            //public string ProductModel { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "ProductModel",
                displayName = "Model",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "ProductModel",
                        displayName="Model",
                        dataType="string",
                        controlType="textbox"
                    }
                }
            });
            //public string CellName { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "CellName",
                displayName = "Cell Name",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "CellName",
                        displayName="Cell Name",
                        dataType="string",
                        controlType="textbox"
                    }
                }
            });
            //public DateTime AuditTime { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "AuditTime",
                displayName = "Audit Time",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "AuditTime",
                        displayName="Audit Time",
                        dataType="string",
                        controlType="date"
                    }
                }
            });
            //public string Auditor { get; set; } //User name of Auditor
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "Auditor",
                displayName = "Auditor",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "Auditor",
                        displayName="Auditor",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });
            //List child item - AuditItemResultDTO
            elementDescriptions.Add(new ElementDescription
            {
                type = "list",
                elementName = "AuditItemResultDTOs",
                displayName = "Audit Result List",
                cssStyle = new CssStyle
                {
                    visibility="hidden"
                },
                propertyDescriptions = new List<PropertyDescription>
                {
                    //public string Barcode { get; set; }
                    new PropertyDescription
                    {
                        propertyName = "Barcode",
                        displayName="Barcode",
                        dataType="string",
                        controlType="textbox"
                    },
                    //public string JigProfileID { get; set; }
                    new PropertyDescription
                    {
                        //isPrimaryKey = true, //This key is primarykey
                        propertyName = "JigProfileID",
                        displayName="JigProfile ID",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    },
                    //public string DesignID { get; set; }
                    new PropertyDescription
                    {
                        propertyName = "DesignID",
                        displayName="Design ID",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    },
                    //public string JigName { get; set; }
                    new PropertyDescription
                    {
                        propertyName = "JigName",
                        displayName="Jig Name",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    },
                    //public string JigCode { get; set; }
                    new PropertyDescription
                    {
                        propertyName = "JigCode",
                        displayName="Jig Code",
                        dataType="string",
                        controlType="textbox"
                    },
                    //public string JigRev { get; set; }
                    new PropertyDescription
                    {
                        propertyName = "JigRev",
                        displayName="Jig Rev",
                        dataType="string",
                        controlType="textbox"
                    },

                    //public string Result { get; set; } //OK, NG or Unknown
                    new PropertyDescription
                    {
                        propertyName = "Result",
                        displayName="Result",
                        dataType="string",
                        controlType="textbox"
                    },

                    //public string Note { get; set; } //Note about result
                    new PropertyDescription
                    {
                        propertyName = "Note",
                        displayName="Note",
                        dataType="string",
                        controlType="textbox"
                    }
                }
            });
            //
            test.model = elementDescriptions;
            return Json(test);
        }

        [HttpGet("DataInfo")]
        public StandardDataInfo GetDataInfo()
        {
            StandardDataInfo info = new StandardDataInfo();
            var test = _context.AuditJigReports.Count();
            info.total = test;
            return info;
        }

        //// GET: api/values
        //[HttpGet]
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        // GET: api/values
        [HttpGet]
        public IEnumerable<AuditJigReportDTO> Get(int offset, int take)
        {
            //If take = 0: get all item from offset to end
            var lstTest = new List<AuditJigReport>();

            if (take != 0)
            {
                lstTest = _context.AuditJigReports
                .Include(a => a.AuditItemResults)
                .ThenInclude(r=>r.JigProfile)
                .Include(a=>a.ApplicationUser)
                .Include(a=>a.ProductModel)
                .OrderByDescending(a=>a.AuditTime)
                .Skip(offset)
                .Take(take).ToList();
            }
            else
            {
                lstTest = _context.AuditJigReports
                .Include(a => a.AuditItemResults)
                .ThenInclude(r => r.JigProfile)
                .Include(a=>a.ApplicationUser)
                .Include(a => a.ProductModel)
                .OrderByDescending(a => a.AuditTime)
                .Skip(offset).ToList();
            }

            var lstRet = new List<AuditJigReportDTO>();
            foreach (var item in lstTest)
            {
                //lstRet.Add(item);
                var newAuditJigReportDTO = new AuditJigReportDTO
                {
                    ID = item.ID,
                    ProductModel = (item.ProductModel!=null)? item.ProductModel.ModelName:"",
                    CellName = item.CellName,
                    AuditTime = item.AuditTime,
                    Auditor = (item.ApplicationUser!=null)?item.ApplicationUser.UserName:"unknown"
                };

                var lstItems = new List<AuditItemResultDTO>();
                foreach(var itemResult in item.AuditItemResults)
                {
                    lstItems.Add(new AuditItemResultDTO
                    {
                        Barcode = itemResult.Barcode,
                        JigProfileID = itemResult.JigProfileID,

                        DesignID = (itemResult.JigProfile!=null) ? itemResult.JigProfile.DesignID:"",
                        JigName = (itemResult.JigProfile != null) ? itemResult.JigProfile.JigName : "",
                        JigCode = (itemResult.JigProfile != null) ? itemResult.JigProfile.JigCode : "",
                        JigRev = (itemResult.JigProfile != null) ? itemResult.JigProfile.JigRev : "",

                        Result = itemResult.Result,
                        Note = itemResult.Note
                    });
                }
                newAuditJigReportDTO.AuditItemResultDTOs = lstItems;
                lstRet.Add(newAuditJigReportDTO);
            }
            return lstRet;
        }

        [HttpGet("Search")]
        public IEnumerable<AuditJigReportDTO> GetSearch(string searchQuery, string searchCriteria)
        {
            //Default is search for all
            var keySearch = searchQuery.ToLower().Trim();

            var lstTest = new List<AuditJigReport>();
            lstTest = _context.AuditJigReports
                .Include(a => a.AuditItemResults)
                .ThenInclude(r => r.JigProfile)
                .Include(a => a.ApplicationUser)
                .Include(a => a.ProductModel)
                .OrderByDescending(a => a.AuditTime)
                .ToList();

            var lstRet = new List<AuditJigReportDTO>();
            foreach (var item in lstTest)
            {
                string test2 = "";

                //JObject jo = JObject.FromObject(item);
                JObject jo = JObject.FromObject(item, new Newtonsoft.Json.JsonSerializer()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                    //PreserveReferencesHandling = Newtonsoft.Json.PreserveReferencesHandling.None
                });
                //JArray ja = new JArray();
                foreach (var value in jo.Values())
                {
                    //ja.Add(value);
                    test2 = test2 + value.ToString() + "\r\n";
                }

                if (test2.ToLower().Contains(keySearch))
                {
                    //lstRet.Add(item);
                    var newAuditJigReportDTO = new AuditJigReportDTO
                    {
                        ID = item.ID,
                        ProductModel = (item.ProductModel != null) ? item.ProductModel.ModelName : "",
                        CellName = item.CellName,
                        AuditTime = item.AuditTime,
                        Auditor = (item.ApplicationUser != null) ? item.ApplicationUser.UserName : "unknown"
                    };

                    var lstItems = new List<AuditItemResultDTO>();
                    foreach (var itemResult in item.AuditItemResults)
                    {
                        lstItems.Add(new AuditItemResultDTO
                        {
                            Barcode = itemResult.Barcode,
                            JigProfileID = itemResult.JigProfileID,

                            DesignID = (itemResult.JigProfile != null) ? itemResult.JigProfile.DesignID : "",
                            JigName = (itemResult.JigProfile != null) ? itemResult.JigProfile.JigName : "",
                            JigCode = (itemResult.JigProfile != null) ? itemResult.JigProfile.JigCode : "",
                            JigRev = (itemResult.JigProfile != null) ? itemResult.JigProfile.JigRev : "",

                            Result = itemResult.Result,
                            Note = itemResult.Note
                        });
                    }
                    newAuditJigReportDTO.AuditItemResultDTOs = lstItems;
                    lstRet.Add(newAuditJigReportDTO);
                }
            }

            return lstRet;
        }

        // GET: api/values
        [HttpGet("jigProfile")]
        public IEnumerable<JigProfileDTO> GetJigProfile(string model)
        {
            //Get all jig profile of model
            var modelJigInfo = _context.ModelJigInfo
                .Include(m => m.ModelJigProfileAssignments)
                .ThenInclude(ma => ma.JigProfile)
                .Include(m => m.ProductModel)
                .SingleOrDefault(m => m.ProductModel.ModelName == model);

            var jigProfileDTOs = new List<JigProfileDTO>();
            if(modelJigInfo.ModelJigProfileAssignments!=null)
            {
                foreach (var item in modelJigInfo.ModelJigProfileAssignments)
                {
                    var jigProfileDTO = new JigProfileDTO();
                    //
                    var jigProfile = _context.JigProfile.SingleOrDefault(j => j.ID == item.JigProfileID);
                    jigProfileDTO.ID = jigProfile.ID;
                    jigProfileDTO.DesignID = jigProfile.DesignID;
                    jigProfileDTO.JigName = jigProfile.JigName;
                    jigProfileDTO.JigCode = jigProfile.JigCode;
                    jigProfileDTO.JigRev = jigProfile.JigRev;
                    //
                    jigProfileDTOs.Add(jigProfileDTO);
                }
            }

            return jigProfileDTOs;
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public async Task<JsonResult> Post([FromBody]AuditJigReportDTO auditJigReportDTO)
        {
            Response.StatusCode = 200;

            try
            {
                //Find User 
                var user = await this.userManager.FindByNameAsync(auditJigReportDTO.Auditor);
                if(user == null)
                {
                    Response.StatusCode = 400;
                    return Json("Error: Cannot find user!");
                }

                var productModel = _context.ProductModel
                    .Where(p => p.ModelName == auditJigReportDTO.ProductModel)
                    .FirstOrDefault();

                //First we create new AuditJigReport (Reject "id" key)
                var auditJigReport = new AuditJigReport
                {
                    ProductModelID = (productModel!=null)?productModel.ID:null,
                    CellName = auditJigReportDTO.CellName,
                    AuditTime = DateTime.Now, //Always record timing here, not from user provide!
                    ApplicationUserID = user.Id
                };
                var test1 = _context.AuditJigReports.Add(auditJigReport);

                //When we have new Test Crud identity, then create TestCrudItemList
                foreach (var item in auditJigReportDTO.AuditItemResultDTOs)
                {
                    var newAuditItemResult = new AuditItemResult
                    {
                        Barcode = item.Barcode,
                        Result = item.Result,
                        Note = item.Note,
                        //Foreign Key
                        AuditJigReportID = test1.Entity.ID,
                        JigProfileID = item.JigProfileID,
                    };

                    _context.AuditItemResults.Add(newAuditItemResult);
                }

                var test2 = _context.SaveChanges();

                //Reading entity again & return result
                var result = _context.AuditJigReports
                    .Include(a => a.AuditItemResults)
                    .ThenInclude(item => item.JigProfile)
                    .Include(a=>a.ApplicationUser)
                    .Include(a=>a.ProductModel)
                    .SingleOrDefault(a => a.ID == test1.Entity.ID);

                //Convert to DTO
                var result2 = new AuditJigReportDTO
                {
                    ID = result.ID,
                    ProductModel = result.ProductModel.ModelName,
                    CellName = result.CellName,
                    AuditTime = result.AuditTime,
                    Auditor = user.UserName
                };

                var lstDTO = new List<AuditItemResultDTO>();
                lstDTO = result.AuditItemResults.Select(a => new AuditItemResultDTO
                {
                    Barcode = a.Barcode,
                    Result = a.Result,
                    Note = a.Note,
                    JigProfileID = (a.JigProfileID!=null)? a.JigProfileID : "",
                    DesignID = (a.JigProfile != null) ? a.JigProfile.DesignID : "",
                    JigName = (a.JigProfile != null) ? a.JigProfile.JigName : "",
                    JigCode = (a.JigProfile != null) ? a.JigProfile.JigCode : "",
                    JigRev = (a.JigProfile != null) ? a.JigProfile.JigRev : ""
                }).ToList();
                result2.AuditItemResultDTOs = lstDTO;

                //Return saved entity => we need return new created entity because we need info like id to update on view of client side
                return Json(result2);
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return Json(e.ToString());
            }
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public async Task<string> Delete(string id)
        {
            Response.StatusCode = 200;

            try
            {
                AuditJigReport delAuditJigReport = await _context.AuditJigReports
                    .Include(a=>a.AuditItemResults)
                    .SingleOrDefaultAsync(item => item.ID == id);

                //Remove all child items belong to item which want to deleted
                if (delAuditJigReport.AuditItemResults != null)
                {
                    _context.AuditItemResults.RemoveRange(delAuditJigReport.AuditItemResults);
                    await _context.SaveChangesAsync();
                }

                //Now deleted AuditJigReport
                _context.AuditJigReports.Remove(delAuditJigReport);
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return e.ToString();
            }
            return "OK";
        }
    }
}
