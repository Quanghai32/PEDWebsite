﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PedServer.Data;
using PedServer.Models.StandardCrud;
using PedServer.Models.JigRequest;
using Microsoft.AspNetCore.Identity;
using PedServer.Models;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PedServer.WebApi
{
    public class RequestDeptReqInfoDto
    {
        public string id { get; set; } //ID

        public string deptName { get; set; }
        public string deptCode { get; set; }
        public string requestControlNo { get; set; }

        public string userName { get; set; } //Owner of Request
    }


    [Route("api/[controller]")]
    public class RequestDeptsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> userManager;

        public RequestDeptsController(ApplicationDbContext context,
            UserManager<ApplicationUser> userManager)
        {
            _context = context;
            this.userManager = userManager;
        }

        [HttpGet("{userid}/info")] //
        public JsonResult GetInfo(string userid)
        {
            StandardCrudInfo test = new StandardCrudInfo();
            //Form building regulation
            //  Property Name : Label display on form : Type of Data : Type of Form Control : Parameter (options for select...)
            test.model = new string[] {
                "id:ID:string:textbox",
                "deptName:Dept Name:string:textbox",
                "deptCode:Dept Code:string:textbox",
                "requestControlNo:Control No:string:textbox",
                "userName:User Name:string:textbox"
            };

            return Json(test);
        }

        /// <summary>
        /// Get Data Info
        /// </summary>
        /// <returns></returns>
        [HttpGet("{userid}/DataInfo")]
        public JsonResult GetDataInfo(string userid)
        {
            StandardDataInfo info = new StandardDataInfo();
            //Only load what request belong to current user?
            List<RequestDeptReqInfoDto> lstRet = new List<RequestDeptReqInfoDto>();

            //Load all request include IssuedByInfo information
            var requestDeptReqInfos = _context.RequestDeptReqInfo.Include(r => r.issuedByInfo);
            foreach (RequestDeptReqInfo req in requestDeptReqInfos)
            {
                //First, check user identity
                var user = this.userManager.FindByIdAsync(userid).Result;
                if (user == null) break;
                if (req.issuedByInfo == null) continue;
                if (req.issuedByInfo.ApplicationUserID != userid) continue; //Only load what request belong to current user
                //If everything is ok, then create new dto & add to list
                var newItem = new RequestDeptReqInfoDto
                {
                    id = req.ID,
                    deptName = req.deptName,
                    deptCode = req.deptCode,
                    requestControlNo = req.requestControlNo,
                    userName = user.UserName
                };
                //
                lstRet.Add(newItem);
            }

            info.total = lstRet.Count;
            return Json(info);
        }

        // GET: api/values
        [HttpGet("{userid}")] //
        public JsonResult Get(string userid)
        {
            //Only load what request belong to current user?
            List<RequestDeptReqInfoDto> lstRet = new List<RequestDeptReqInfoDto>();

            //Load all request include IssuedByInfo information
            var requestDeptReqInfos = _context.RequestDeptReqInfo.Include(r => r.issuedByInfo);
            foreach(RequestDeptReqInfo req in requestDeptReqInfos)
            {
                //First, check user identity
                var user = this.userManager.FindByIdAsync(userid).Result;
                if (user == null) break;
                if (req.issuedByInfo == null) continue;
                if (req.issuedByInfo.ApplicationUserID != userid) continue; //Only load what request belong to current user
                //If everything is ok, then create new dto & add to list
                var newItem = new RequestDeptReqInfoDto
                {
                    id = req.ID,
                    deptName = req.deptName,
                    deptCode = req.deptCode,
                    requestControlNo = req.requestControlNo,
                    userName = user.UserName
                };
                //
                lstRet.Add(newItem);
            }

            return Json(lstRet.ToList());
        }

        public string FindRequestorName(RequestDeptReqInfo infoInput)
        {
            string strRet = "unknown";
            if (infoInput.issuedByInfo == null) return strRet;
            if (infoInput.issuedByInfo.ApplicationUserID == null) return strRet;
            //
            var user = this.userManager.FindByIdAsync(infoInput.issuedByInfo.ApplicationUserID).Result;
            if (user != null) return user.UserName;
            //Not found
            return strRet;
        }

        //// GET api/values/5
        //[HttpGet("{id}")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        // POST api/values
        [HttpPost("{userid}")] //
        public JsonResult Post(string userid, [FromBody]RequestDeptReqInfoDto requestDeptDto)
        {
            Response.StatusCode = 200;

            try
            {
                //When receiving new request dept info - we create all new Jig Request & info of Request Dept
                //0. Create new issuedByInfo
                var issuedByInfo = new IssuedByInfo
                {
                    ApplicationUserID = userid,
                    date = DateTime.Now
                };
                //issuedByInfo.ApplicationUserID = userid;
                var test0 = _context.IssuedByInfo.Add(issuedByInfo);
                _context.SaveChanges();

                //1. Create new RequestDeptReqInfo
                var newRequestInfo = new RequestDeptReqInfo
                {
                    deptName = requestDeptDto.deptName.ToString(),
                    deptCode = requestDeptDto.deptCode.ToString(),
                    requestControlNo = requestDeptDto.requestControlNo.ToString(),
                    IssuedByInfoID = test0.Entity.ID
                };
                //Save change
                var test1 = _context.RequestDeptReqInfo.Add(newRequestInfo);
                _context.SaveChanges();

                //2. Create new RequisitionArea
                var newRequisitionArea = new RequisitionArea
                {
                    RequestDeptReqInfoID = test1.Entity.ID
                };
                var test2 = _context.RequisitionArea.Add(newRequisitionArea);
                _context.SaveChanges();

                //3. Create new Request
                var newJigRequest = new JigRequest
                {
                    RequisitionAreaID = test2.Entity.ID
                };
                var test3 = _context.JigRequest.Add(newJigRequest);
                _context.SaveChanges();

                //Return saved entity
                var newRequestInfoDto = new RequestDeptReqInfoDto
                {
                    id = test1.Entity.ID,
                    deptName = requestDeptDto.deptName.ToString(),
                    deptCode = requestDeptDto.deptCode.ToString(),
                    requestControlNo = requestDeptDto.requestControlNo.ToString()
                };
                return Json(newRequestInfoDto);
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return Json(e.ToString());
            }
        }

        // PUT api/values/5
        [HttpPut("{userid}/{id}")]
        public string Put(string userid,string id, [FromBody]dynamic requestDeptDto)
        {
            Response.StatusCode = 200;

            try
            {
                RequestDeptReqInfo requestDeptReqInfo = new RequestDeptReqInfo
                {
                    ID = requestDeptDto.id,
                    deptName = requestDeptDto.deptName,
                    deptCode = requestDeptDto.deptCode,
                    requestControlNo = requestDeptDto.requestControlNo
                };

                _context.RequestDeptReqInfo.Attach(requestDeptReqInfo);
                _context.Entry(requestDeptReqInfo).State = EntityState.Modified;
                _context.SaveChanges();

            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return e.ToString();
            }
            return "OK";
        }

        // DELETE api/values/5
        [HttpDelete("{userid}/{id}")]
        public string Delete(string userid, string id)
        {
            Response.StatusCode = 200;

            try
            {
                var delReqInfo = new RequestDeptReqInfo();
                delReqInfo.ID = id;

                //Looking for RequisitionArea to delete
                var delRequisitionArea = new RequisitionArea();
                delRequisitionArea = _context.RequisitionArea.Where(item => item.RequestDeptReqInfoID == delReqInfo.ID).FirstOrDefault();

                //Looking for Jig Request to delete
                var delJigRequest = new JigRequest();
                delJigRequest = _context.JigRequest.Where(item => item.RequisitionAreaID == delRequisitionArea.ID).FirstOrDefault();

                //Looking for issuedByInfo to delete
                var issuedByInfo = new IssuedByInfo();
                var test = _context.RequestDeptReqInfo.AsNoTracking()
                    .Include(item => item.issuedByInfo)
                    .Where(item => item.ID == id)
                    .FirstOrDefault();

                if (delJigRequest!=null)
                {
                    _context.JigRequest.Remove(delJigRequest);
                    _context.SaveChanges();
                }

                if (delRequisitionArea != null)
                {
                    _context.RequisitionArea.Remove(delRequisitionArea);
                    _context.SaveChanges();
                }

                if (delReqInfo != null)
                {
                    _context.RequestDeptReqInfo.Remove(delReqInfo);
                    _context.SaveChanges();
                }

                if (test != null)
                {
                    if(test.issuedByInfo!=null)
                    {
                        var delIssuedByInfo = new IssuedByInfo();
                        delIssuedByInfo.ID = test.issuedByInfo.ID;
                        _context.IssuedByInfo.Remove(delIssuedByInfo);
                        _context.SaveChanges();
                    }
                }

            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                string test = e.ToString();
                return e.ToString();
            }
            return "OK";
        }
    }
}
