﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PedServer.Data;
using PedServer.Models.StandardCrud;
using PedServer.Models.ProductModel;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PedServer.WebApi
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    public class ProductModelsController : Controller
    {
        private readonly ApplicationDbContext _context;
        public ProductModelsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("info")]
        public JsonResult GetInfo()
        {
            StandardCrudInfo test = new StandardCrudInfo();
            //Form building
            List<ElementDescription> elementDescriptions = new List<ElementDescription>();
            //public string ID { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "ID",
                displayName = "ID",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        isPrimaryKey = true, //This key is primary key => do not allow user for changing on client side
                        propertyName = "ID",
                        displayName="ID",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null,
                        cssStyle = new CssStyle
                        {
                            color = "red"
                        }
                    }
                }
            });
            //public string ModelName { get; set; } //E28, D92, D81...
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "ModelName",
                displayName = "Model Name",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "ModelName",
                        displayName="Model Name",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });
            //public string CodeName { get; set; } //Laoag, Essen...
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "CodeName",
                displayName = "Code Name",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "CodeName",
                        displayName="Code Name",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });
            //public string EngineName { get; set; } //Fine11, ZF784...
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "EngineName",
                displayName = "Engine Name",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "EngineName",
                        displayName="Engine Name",
                        dataType="boolean",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });

            test.model = elementDescriptions;
            return Json(test);
        }

        /// <summary>
        /// Get Data Info
        /// </summary>
        /// <returns></returns>
        [HttpGet("DataInfo")]
        public StandardDataInfo GetDataInfo()
        {
            StandardDataInfo info = new StandardDataInfo();
            var test = _context.ProductModel.Count();
            info.total = test;
            return info;
        }

        // GET: api/values
        [HttpGet]
        public IEnumerable<Models.ProductModel.ProductModel> Get(int offset, int take)
        {
            //If take = 0: get all item from offset to end
            if(take!=0)
            {
                return _context.ProductModel
                    .OrderBy(p => p.ModelName)
                    .Skip(offset)
                    .Take(take);
            }
            else //Get all from offset
            {
                return _context.ProductModel
                    .OrderBy(p => p.ModelName)
                    .Skip(offset);
            }
        }

        [HttpGet("Search")]
        public IEnumerable<Models.ProductModel.ProductModel> GetSearch(string searchQuery, string searchCriteria)
        {
            //Default is search for all
            var keySearch = searchQuery.ToLower().Trim();
            var test = _context.ProductModel
                .Where(
                    p => p.ModelName.ToLower().Contains(keySearch) ||
                    p.CodeName.ToLower().Contains(keySearch) ||
                    p.EngineName.ToLower().Contains(keySearch) ||
                    p.ID.ToLower().Contains(keySearch)
                );
            return test;
        }


        //// GET api/values/5
        //[HttpGet("{id}")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        // POST api/values
        [HttpPost]
        public JsonResult Post([FromBody]ProductModel productModel)
        {
            Response.StatusCode = 200;
            //Check if ModelName already exist or not
            var test = _context.ProductModel
                .SingleOrDefault(p => p.ModelName.ToLower().Trim() == productModel.ModelName.ToLower().Trim());

            if(test!=null) //Already exist, do not allow create same model record
            {
                Response.StatusCode = 400;
                return Json("Error: Model Name already exist!");
            }
            //First we create new item (Reject "id" key)
            var newProductModel = new ProductModel
            {
                ModelName = productModel.ModelName,
                CodeName = productModel.CodeName,
                EngineName = productModel.EngineName
            };

            var test1 =  _context.ProductModel.Add(newProductModel);
            var test2 =  _context.SaveChanges();
            //Return saved entity => we need return new created entity because we need info like id to update on view of client side
            return Json(test1.Entity);
        }

        // PUT api/values/5
        [HttpPut]
        public async Task<JsonResult> Put([FromBody] ProductModel productModel)
        {
            Response.StatusCode = 200;

            try
            {
                //Do not allow user edit another model name to exist one!
                var testModel = _context.ProductModel
                    .SingleOrDefault(p => p.ModelName.ToLower().Trim() == productModel.ModelName.ToLower().Trim());
                if(testModel!=null)
                {
                    if(testModel.ID!= productModel.ID) //User want to edit another model to name replace exist one!
                    {
                        Response.StatusCode = 400;
                        return Json("Error: Model Name " + testModel.ModelName + " already exist! Edit another with same name is not allowed!");
                    }
                }
                
                var test1 = _context.ProductModel.Attach(productModel);
                _context.Entry(productModel).State = EntityState.Modified;

                //Save all change
                await _context.SaveChangesAsync();

                ////Reading entiy again and return to frontend
                //var result = await _context.ProductModel
                //    .SingleOrDefaultAsync(p => p.ID == productModel.ID);

                //Return saved entity => we need return new created entity because we need info like id to update on view of client side
                return Json(test1.Entity);
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return Json(e.ToString());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public async Task<string> Delete(string id)
        {
            Response.StatusCode = 200;

            try
            {
                ProductModel delProductModel = await _context.ProductModel
                    .SingleOrDefaultAsync(item => item.ID == id);

                //Now deleted 
                _context.ProductModel.Remove(delProductModel);
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return e.ToString();
            }
            return "OK";
        }
    }
}
