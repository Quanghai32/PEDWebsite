﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PedServer.Data;
using PedServer.Models.StandardCrud;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PedServer.WebApi
{
    public class JigBarcodeDTO
    {
        public string ID { get; set; }
        public string BarcodeData { get; set; }
        public JigProfileDTO JigProfileDTO { get; set; }
    }

    [Produces("application/json")]
    [Route("api/[controller]")]
    public class JigBarcodesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public JigBarcodesController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("info")]
        public JsonResult GetInfo()
        {
            StandardCrudInfo test = new StandardCrudInfo();
            //Form building
            List<ElementDescription> elementDescriptions = new List<ElementDescription>();
            //public string ID { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "ID",
                displayName = "ID",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        isPrimaryKey = true, //This key is primary key => do not allow user for changing on client side
                        propertyName = "ID",
                        displayName="ID",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null,
                        cssStyle = new CssStyle
                        {
                            color = "red"
                        }
                    }
                }
            });
            //public string BarcodeData { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "BarcodeData",
                displayName = "Barcode",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "BarcodeData",
                        displayName="Barcode",
                        dataType="string",
                        controlType="text",
                        selectDatas = null
                    }
                }
            });
            //public JigProfileDTO JigProfileDTO { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "list",
                elementName = "JigProfileDTO",
                displayName = "Jig Profile",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "JigProfileDTO",
                        displayName="Jig Profile",
                        dataType="string",
                        controlType="select",
                        selectDatas = _context.JigProfile.ToList()
                        .Select(j=> j.JigName + ";" + j.JigCode + ";" + j.JigRev).ToList()
                    }
                }
            });
            
            //
            test.model = elementDescriptions;
            return Json(test);
        }

        /// <summary>
        /// Get Data Info
        /// </summary>
        /// <returns></returns>
        [HttpGet("DataInfo")]
        public StandardDataInfo GetDataInfo()
        {
            StandardDataInfo info = new StandardDataInfo();
            var test = _context.JigBarcodes.Count();
            info.total = test;
            return info;
        }

        // GET: api/values
        [HttpGet]
        public JsonResult Get()
        {
            var lstTest = _context.TestCrud.Include(item => item.TestCrudItemLists);
            var lstRet = new List<TestCrud>();
            foreach (TestCrud item in lstTest)
            {
                lstRet.Add(item);
            }
            return Json(lstRet);
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
