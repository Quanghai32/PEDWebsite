﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PedServer.Data;
using PedServer.Models.StandardCrud;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PedServer.Models.standardApprove;
using PedServer.WebApi;
using PedServer.Models.UserControl;
using PedServer.Models;
using Microsoft.AspNetCore.Identity;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PedServer.api
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    public class TestCrudsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public TestCrudsController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        [HttpGet("info")]
        public JsonResult GetInfo()
        {
            StandardCrudInfo test = new StandardCrudInfo();

            //Create & Add Model Info
            List<ElementDescription> elementDescriptions = new List<ElementDescription>();
            //"item::id:ID:string:textbox"
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "Id",
                displayName = "ID",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        isPrimaryKey = true, //This key is primary key => do not allow user for changing on client side
                        propertyName = "Id",
                        displayName="ID",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null,
                        cssStyle = new CssStyle
                        {
                            color = "red"
                        }
                    }
                }
            });
            //"item::property1:Label1:string:textbox"
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "SampleDate",
                displayName = "Sample Date",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "SampleDate",
                        displayName="Sample Date",
                        dataType="string",
                        controlType="date",
                        selectDatas = null
                    }
                }
            });
            //"item::property2:Label2:string:textbox"
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "Property2",
                displayName = "Property 2",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "Property2",
                        displayName="Property 2",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });
            //"item:property3:Label3:boolean:checkbox"
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "Property3",
                displayName = "Property 3",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "Property3",
                        displayName="Property 3",
                        dataType="boolean",
                        controlType="checkbox",
                        selectDatas = null
                    }
                }
            });
            //List child item
            elementDescriptions.Add(new ElementDescription
            {
                type = "list",
                elementName = "TestCrudItemLists",
                displayName = "Crud Item List",
                propertyDescriptions = new List<PropertyDescription>
                {
                    //"list:TestCrudItemList:id:ID:string:textbox"
                    new PropertyDescription
                    {
                        isPrimaryKey = true, //This key is primarykey
                        propertyName = "Id",
                        displayName="ID",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    },
                    //"list:TestCrudItemList:itemProperty1:Item Property1:string:textbox"
                    new PropertyDescription
                    {
                        propertyName = "ItemProperty1",
                        displayName="Item Property1",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    },
                    //"list:TestCrudItemList:itemProperty2:Item Property2:string:textbox"
                    new PropertyDescription
                    {
                        propertyName = "ItemProperty2",
                        displayName="Item Property2",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    },
                    //"list:TestCrudItemList:itemProperty3:Item Property3:boolean:checkbox",
                    new PropertyDescription
                    {
                        propertyName = "ItemProperty3",
                        displayName="Item Property3",
                        dataType="boolean",
                        controlType="checkbox",
                        selectDatas = null
                    },
                    //"list:TestCrudItemList:itemProperty4:Item Property4:string:select:A/B/C/D/E/F"
                    new PropertyDescription
                    {
                        propertyName = "ItemProperty4",
                        displayName="Item Property4",
                        dataType="string",
                        controlType="select",
                        selectDatas = new List<string>
                        {
                            "A","B","C","D","E","F"
                        }
                    }
                }
            });
            //"item::property4:Label4:string:select:A/B/C/D/E/F"
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "Property4",
                displayName = "Property 4",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "Property4",
                        displayName="Label4",
                        dataType="string",
                        controlType="select",
                        selectDatas = new List<string>
                        {
                            "A","B","C","D","E","F"
                        }
                    }
                }
            });
            //Add Model Info
            test.model = elementDescriptions;

            //Create & Add Approve Model Info
            BackendApproveSetting backendApproveSetting = new BackendApproveSetting();
            backendApproveSetting.requireApprove = true;
            backendApproveSetting.approveActionInfos = new List<BackendApproveActionSetting>();
            BackendApproveActionSetting checkInfo = new BackendApproveActionSetting
            {
                actionName = "Check",
                explanation = "Your action need to be checked! Please select member who can check your action!"
            };
            backendApproveSetting.approveActionInfos.Add(checkInfo);

            BackendApproveActionSetting approveInfo = new BackendApproveActionSetting
            {
                actionName = "Approve",
                explanation = "Your action need to be approved! Please select member who can approve your action!"
            };
            backendApproveSetting.approveActionInfos.Add(approveInfo);

            //Add approve model
            test.approveModel = backendApproveSetting;

            return Json(test);
        }

        /// <summary>
        /// Get Data Info
        /// </summary>
        /// <returns></returns>
        [HttpGet("DataInfo")] 
        public StandardDataInfo GetDataInfo()
        {
            StandardDataInfo info = new StandardDataInfo();
            var test = _context.TestCrud.Count();
            info.total = test;
            return info;
        }

        /// <summary>
        /// Get Info of 1 item by id
        /// </summary>
        /// <param name="id"> ID of item want to get Info</param>
        /// <returns></returns>
        [HttpGet("ItemInfo")]
        public JsonResult GetItemInfo(string itemId)
        {
            var standardCrudItemInfo = new StandardCrudItemInfo();
            //id
            standardCrudItemInfo.id = itemId;
            //Total number of all data
            standardCrudItemInfo.total = _context.TestCrud.Count();
            //Searching Index of Item in all list
            standardCrudItemInfo.index = _context.TestCrud.ToList()
                .FindIndex(t => t.Id == itemId);

            return Json(standardCrudItemInfo);
        }

        /// <summary>
        /// Get items object
        /// </summary>
        /// <param name="offset"></param>
        /// <param name="take"></param>
        /// <returns></returns>
        [HttpGet]
        public IEnumerable<Models.StandardCrud.TestCrud> Get(int offset, int take)
        {
            //If take = 0: get all item from offset to end
            var lstTest = new List<TestCrud>();

            if(take != 0)
            {
                lstTest = _context.TestCrud
                .Include(item => item.TestCrudItemLists)
                .Skip(offset)
                .Take(take).ToList();
            }
            else
            {
                lstTest = _context.TestCrud
                .Include(item => item.TestCrudItemLists)
                .Skip(offset).ToList();
            }
            
            var lstRet = new List<TestCrud>();
            foreach (TestCrud item in lstTest)
            {
                lstRet.Add(item);
            }
            return lstRet;
        }

        /// <summary>
        /// Get Approve Status of items
        /// </summary>
        /// <param name="offset"></param>
        /// <param name="take"></param>
        /// <returns></returns>
        [HttpGet("VerifyResult")]
        public IEnumerable<VerifyResult> GetVerifyResult(int offset, int take)
        {
            // We need looking in VerifyResults table of Database where ApplicationName = 'TEST CRUD APPLICATION'
            // And ObjectID matching with ID of TestCrud Items
            var lstResult = new List<VerifyResult>();

            //If take = 0: get all item from offset to end
            var lstTest = new List<TestCrud>();

            if (take != 0)
            {
                lstTest = _context.TestCrud
                .Include(item => item.TestCrudItemLists)
                .Skip(offset)
                .Take(take).ToList();
            }
            else
            {
                lstTest = _context.TestCrud
                .Include(item => item.TestCrudItemLists)
                .Skip(offset).ToList();
            }

            foreach (TestCrud item in lstTest)
            {
                var temp = new VerifyResult();
                temp = _context.VerifyResults
                    .Include(v => v.VerifyRequest)
                    .SingleOrDefault(v => ((v.VerifyRequest.ObjectID == item.Id)
                    && (v.VerifyRequest.ApplicationName == "TEST CRUD APPLICATION")));
                lstResult.Add(temp);
            }

            return lstResult;
        }

        [HttpGet("Search")]
        public JsonResult GetSearch(string searchQuery, string searchCriteria)
        {
            Response.StatusCode = 200;

            try
            {
                //Default is search for all
                var keySearch = searchQuery.ToLower().Trim();

                var lstTest = new List<TestCrud>();
                lstTest = _context.TestCrud
                    .Include(item => item.TestCrudItemLists).ToList();

                var lstRet = new List<TestCrud>();
                foreach (var item in lstTest)
                {
                    string test2 = "";

                    //JObject jo = JObject.FromObject(item);
                    JObject jo = JObject.FromObject(item, new Newtonsoft.Json.JsonSerializer()
                    {
                        ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        //PreserveReferencesHandling = Newtonsoft.Json.PreserveReferencesHandling.None
                    });
                    //JArray ja = new JArray();
                    foreach (var value in jo.Values())
                    {
                        //ja.Add(value);
                        test2 = test2 + value.ToString() + "\r\n";
                    }

                    if (test2.ToLower().Contains(keySearch))
                    {
                        lstRet.Add(item);
                    }
                }

                return Json(lstRet);
            }
            catch(Exception ex)
            {
                Response.StatusCode = 400;
                return Json(ex.Message);
            }

        }


        // GET api/values/5
        [HttpGet("{id}")]
        public TestCrud Get(string id)
        {
            var test = _context.TestCrud
                .Include(item => item.TestCrudItemLists)
                .Where(item => item.Id == id).FirstOrDefault();
            return test;
        }

        // POST api/values
        [HttpPost]
        public JsonResult Post([FromBody]TestCrud testCrud)
        {
            Response.StatusCode = 200;

            try
            {
                //First we create new TestCrud (Reject "id" key)
                var newCrud = new TestCrud{
                    SampleDate = testCrud.SampleDate,
                    Property2 = testCrud.Property2,
                    Property3 = testCrud.Property3,
                    Property4 = testCrud.Property4
                };

                var test1 = _context.TestCrud.Add(newCrud);
                //When we have new Test Crud identity, then create TestCrudItemList
                foreach(var item in testCrud.TestCrudItemLists)
                {
                    item.Id = null; //Reset so Identity Core will autoset Id for new create item
                    item.TestCrudID = test1.Entity.Id;
                    _context.TestCrudItemList.Add(item);
                }

                var test2 = _context.SaveChanges();

                //Reading entity again & return result
                var result = _context.TestCrud
                    .Include(t => t.TestCrudItemLists)
                    .SingleOrDefault(i=>i.Id==test1.Entity.Id);

                //Return saved entity => we need return new created entity because we need info like id to update on view of client side
                return Json(result);
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return Json(e.ToString());
            }
        }

        // PUT api/values/5
        [HttpPut]
        public async Task<JsonResult> Put([FromBody] Models.StandardCrud.TestCrud testCrud)
        {
            Response.StatusCode = 200;

            try
            {
                // We need handle some cases:
                //  1. User want to create new TestCrudItemList item for TestCrud
                //  2. User want to modify existing TestCrudItemList of TestCrud
                //  3. User want to delete existing TestCrudItemList of TestCrud

                //1. First, we need to find info of TestCrud in database
                var testCrudToUpdate = await _context.TestCrud.AsNoTracking()
                    .Include(i => i.TestCrudItemLists)
                    .SingleOrDefaultAsync(m => m.Id == testCrud.Id);
                
                var currentItemList = new HashSet<string>(testCrudToUpdate
                        .TestCrudItemLists.Select(i => i.Id)
                    ); //Current list
                var desiredItemList = testCrud.TestCrudItemLists.Select(item => item.Id).ToList(); //User want to have
                var currentDBItem = _context.TestCrudItemList.AsNoTracking().ToList(); //Hold all item existing in database
                var currentDatabaseList = currentDBItem.Select(t => t.Id).ToList();

                //1. To ensure al desired list need to update
                foreach (var itemId in desiredItemList) //check all item in desired list
                {
                    if(currentDatabaseList.Contains(itemId)) //selected item already exist in database => Maybe user want to modify item
                    {
                        //Modify handle
                        //var modifyItem = currentDBItem.SingleOrDefault(t => t.Id == itemId);
                        var modifyItem = testCrud.TestCrudItemLists.SingleOrDefault(t => t.Id == itemId);
                        _context.TestCrudItemList.Attach(modifyItem);
                        _context.Entry(modifyItem).State = EntityState.Modified;

                        //_context.SaveChanges();
                        //_context.Entry(modifyItem).State = EntityState.Detached;
                    }
                    else //desired item does not exist in database => user want to create new
                    {
                        //Create new handle
                        var createItem = new TestCrudItemList();
                        createItem = testCrud.TestCrudItemLists.SingleOrDefault(t => t.Id == itemId);
                        createItem.Id = null; //Remove Id so Identity Core will autoset ID for new item
                        createItem.TestCrudID = testCrud.Id;
                        _context.TestCrudItemList.Add(createItem);
                    }
                }
                //2. Remove unwanted item
                foreach(var itemID in currentItemList)
                {
                    if(!desiredItemList.Contains(itemID))
                    {
                        //remove handle
                        var delItem = _context.TestCrudItemList.SingleOrDefault(t => t.Id == itemID);
                        _context.TestCrudItemList.Remove(delItem);
                    }
                }

                //3. Saving TestCrud
                _context.TestCrud.Attach(testCrud);
                _context.Entry(testCrud).State = EntityState.Modified;

                //Save all change
                _context.SaveChanges();

                //Reading entiy again and return to frontend
                var result = _context.TestCrud
                    .Include(t => t.TestCrudItemLists)
                    .SingleOrDefault(i => i.Id == testCrud.Id);

                //Return saved entity => we need return new created entity because we need info like id to update on view of client side
                return Json(result);

            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return Json(e.ToString());
            }
            //return "OK";
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public async Task<string> Delete(string id)
        {
            Response.StatusCode = 200;

            try
            {
                TestCrud delTestCrud = await _context.TestCrud
                    .Include(i => i.TestCrudItemLists)
                    .SingleOrDefaultAsync(item => item.Id==id);
                //Remove all TestCrudItemLists belong to item TestCrud which want to deleted
                if(delTestCrud.TestCrudItemLists!=null)
                {
                    _context.TestCrudItemList.RemoveRange(delTestCrud.TestCrudItemLists);
                    await _context.SaveChangesAsync();
                }

                //Now deleted TestCrud
                _context.TestCrud.Remove(delTestCrud);
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return e.ToString();
            }
            return "OK";
        }

    }
}
