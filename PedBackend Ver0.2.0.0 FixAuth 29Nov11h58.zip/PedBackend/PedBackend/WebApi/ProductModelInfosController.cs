﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PedServer.Data;
using PedServer.Models.StandardCrud;
using PedServer.Models.ProductModelInfo;
using Microsoft.EntityFrameworkCore;
using AutoMapper;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PedServer.WebApi
{
    public class ProductModelInfoDTO
    {
        public string ID { get; set; }
        public string RomVersion { get; set; }
        public string LoaderVersion { get; set; }
        //Foreign Key
        public string ModelName { get; set; }
    }

    [Route("api/[controller]")]
    public class ProductModelInfosController : Controller
    {
        private readonly ApplicationDbContext _context;
        private IMapper _mapper;

        public ProductModelInfosController(ApplicationDbContext context, IMapper mapper)
        {
            this._context = context;
            _mapper = mapper;
        }

        [HttpGet("info")]
        public JsonResult GetInfo()
        {
            StandardCrudInfo test = new StandardCrudInfo();
            //Form building
            List<ElementDescription> elementDescriptions = new List<ElementDescription>();
            //public string ID { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "ID",
                displayName = "ID",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        isPrimaryKey = true, //This key is primary key => do not allow user for changing on client side
                        propertyName = "ID",
                        displayName="ID",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null,
                        cssStyle = new CssStyle
                        {
                            color = "red"
                        }
                    }
                }
            });

            //public string ModelName { get; set; } //E28, D92, D81...
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "ModelName",
                displayName = "Model Name",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "ModelName",
                        displayName="Model Name",
                        dataType="string",
                        controlType="select",
                        selectDatas = _context.ProductModel.Select(p=>p.ModelName).ToList()
                    }
                }
            });

            //public string RomVersion { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "RomVersion",
                displayName = "Rom Version",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "RomVersion",
                        displayName="Rom Version",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });

            //public string LoaderVersion { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "LoaderVersion",
                displayName = "Loader Version",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "LoaderVersion",
                        displayName="Loader Version",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });

            //
            test.model = elementDescriptions;
            return Json(test);
        }

        /// <summary>
        /// Get Data Info
        /// </summary>
        /// <returns></returns>
        [HttpGet("DataInfo")]
        public StandardDataInfo GetDataInfo()
        {
            StandardDataInfo info = new StandardDataInfo();
            var test = _context.ProductModelInfos.Count();
            info.total = test;
            return info;
        }


        //// GET: api/values
        //[HttpGet]
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        // GET: api/values
        [HttpGet]
        public IEnumerable<ProductModelInfoDTO> Get(int offset, int take)
        {
            //If take = 0: get all item from offset to end
            var lstData = new List<ProductModelInfo>();
            if (take != 0)
            {
                lstData = _context.ProductModelInfos
                    .Include(p => p.ProductModel)
                    .OrderBy(p => p.ProductModel.ModelName)
                    .Skip(offset)
                    .Take(take)
                    .ToList();
            }
            else //Get all from offset
            {
                lstData = _context.ProductModelInfos
                    .Include(p => p.ProductModel)
                    .OrderBy(p => p.ProductModel.ModelName)
                    .Skip(offset)
                    .ToList();
            }

            //var lstRet = lstData.Select(p => new ProductModelInfoDTO
            //{
            //    ID = p.ID,
            //    RomVersion = p.RomVersion,
            //    LoaderVersion = p.LoaderVersion,
            //    ModelName = p.ProductModel.ModelName
            //});

            var lstRet = lstData.Select(p => _mapper.Map< ProductModelInfo, ProductModelInfoDTO>(p));

            return lstRet;
        }

        [HttpGet("Search")]
        public List<ProductModelInfoDTO> GetSearch(string searchQuery, string searchCriteria)
        {
            //Default is search for all
            var keySearch = searchQuery.ToLower().Trim();
            var test = _context.ProductModelInfos
                .Include(p => p.ProductModel)
                .Where(
                    p => p.ProductModel.ModelName.ToLower().Contains(keySearch) ||
                    p.RomVersion.ToLower().Contains(keySearch) ||
                    p.LoaderVersion.ToLower().Contains(keySearch) ||
                    p.ID.ToLower().Contains(keySearch)
                ).Select(p => new ProductModelInfoDTO
                {
                    ID = p.ID,
                    RomVersion = p.RomVersion,
                    LoaderVersion = p.LoaderVersion,
                    ModelName = p.ProductModel.ModelName
                }).ToList();

            return test;
        }

        /// <summary>
        /// For CFP Web API searching
        /// </summary>
        /// <param name="searchQuery">Must be product model name</param>
        /// <param name="searchCriteria">"all" or specific info like "RomVersion", "LoaderVersion"...</param>
        /// <param name="searchOption">Optional information such as "active", "valid", "latest", "all"...</param>
        /// <returns></returns>
        [HttpGet("GetModelInfo")]
        public JsonResult GetModelInfo(string searchQuery, string searchCriteria, string searchOption)
        {
            Response.StatusCode = 200;
            //Default is search for all
            var model = searchQuery.ToLower().Trim();
            //searching model exist or not
            var testExist = _context.ProductModel
                .SingleOrDefault(p => p.ModelName.ToLower().Trim() == model);
            if(testExist==null)
            {
                Response.StatusCode = 400;
                return Json("Error: model name " + model + " not exist!");
            }

            //Search Info of that model exist or not
            var testInfo = _context.ProductModelInfos
                    .Include(pm => pm.ProductModel)
                    .SingleOrDefault(pm => pm.ProductModel.ModelName.ToLower().Trim() == model);

            if (testInfo == null)
            {
                Response.StatusCode = 400;
                return Json("Error: cannot find info of model " + model);
            }
            //Base on searchCriteria, get necessary information CFP need
            //Default is request "all"

            if (searchCriteria.ToLower().Trim()=="romversion")
            {
                //If everything is OK, then return romversion
                return Json(testInfo.RomVersion);
            }
            else //Default is return all model information - Json format
            {
                return Json(testInfo);
            }
        }

        //// GET api/values/5
        //[HttpGet("{id}")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        // POST api/values
        [HttpPost]
        public JsonResult Post([FromBody]ProductModelInfoDTO productModelInfoDTO)
        {
            Response.StatusCode = 200;
            //
            try
            {
                var newProductModelInfo = new ProductModelInfo
                {
                    RomVersion = productModelInfoDTO.RomVersion,
                    LoaderVersion = productModelInfoDTO.LoaderVersion
                };

                //Looking for ProductModel
                var productModel = _context.ProductModel
                    .SingleOrDefault(
                        p => p.ModelName.ToLower().Trim() == productModelInfoDTO.ModelName.ToLower().Trim()
                    );
                if (productModel == null) return Json("Error: Cannot find model name " + productModelInfoDTO.ModelName);
                newProductModelInfo.ProductModelID = productModel.ID;
                //
                var newItem = _context.ProductModelInfos.Add(newProductModelInfo);
                _context.SaveChanges();

                return Json(new ProductModelInfoDTO
                {
                    ID = newItem.Entity.ID,
                    RomVersion = newItem.Entity.RomVersion,
                    LoaderVersion = newItem.Entity.LoaderVersion,
                    ModelName = productModelInfoDTO.ModelName
                });

            }
            catch (Exception ex)
            {
                Response.StatusCode = 200;
                return Json(ex.Message);
            }
           
        }

        // PUT api/values/5
        [HttpPut]
        public JsonResult Put([FromBody]ProductModelInfoDTO productModelInfoDTO)
        {
            Response.StatusCode = 200;

            try
            {
                var modifyItem = new ProductModelInfo
                {
                    ID = productModelInfoDTO.ID,
                    LoaderVersion = productModelInfoDTO.LoaderVersion,
                    RomVersion = productModelInfoDTO.RomVersion
                };

                //Looking for Product Model Name
                var productModel = _context.ProductModel
                    .SingleOrDefault(p => p.ModelName.ToLower().Trim() == productModelInfoDTO.ModelName.ToLower().Trim());
                if (productModel == null) return Json("Error: Model Name not exist!");

                modifyItem.ProductModel = productModel;
                modifyItem.ProductModelID = productModel.ID;

                //Save to database
                var saveItem = _context.ProductModelInfos.Attach(modifyItem);
                _context.Entry(modifyItem).State = EntityState.Modified;
                _context.SaveChanges();

                //Return data
                return Json(new ProductModelInfoDTO
                {
                    ID = saveItem.Entity.ID,
                    RomVersion = saveItem.Entity.RomVersion,
                    LoaderVersion = saveItem.Entity.LoaderVersion,
                    ModelName = productModel.ModelName
                });
            }
            catch(Exception ex)
            {
                Response.StatusCode = 200;
                return Json(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public async Task<string> Delete(string id)
        {
            Response.StatusCode = 200;

            try
            {
                ProductModelInfo delProductModelInfo = await _context.ProductModelInfos
                    .SingleOrDefaultAsync(item => item.ID == id);

                //Now deleted 
                _context.ProductModelInfos.Remove(delProductModelInfo);
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return e.ToString();
            }
            return "OK";
        }
    }
}
