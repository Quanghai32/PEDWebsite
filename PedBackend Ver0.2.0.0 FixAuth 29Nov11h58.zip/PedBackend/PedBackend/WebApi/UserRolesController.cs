﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using PedServer.Models.StandardCrud;
using PedServer.Models;
using PedServer.Data;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;
using Newtonsoft.Json.Linq;
using PedServer.Define;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PedServer.Server.api
{
    public class UserRoleDTO
    {
        public int idRole { get; set; } //id of 
        public string id { get; set; } //Application User ID
        public string claim { get; set; }
    }

    // [Authorize(AuthenticationSchemes = "Bearer", Policy = ClaimDefine.WebAppRole.Admin)]
    [Produces("application/json")]
    [Route("api/[controller]")]
    public class UserRolesController : Controller
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly RoleManager<ApplicationRole> roleManager;
        private readonly ApplicationDbContext _context;

        public UserRolesController(ApplicationDbContext context, UserManager<ApplicationUser> userManager, RoleManager<ApplicationRole> roleManager)
        {
            _context = context;
            this.userManager = userManager;
            this.roleManager = roleManager;
        }

        [HttpGet("info")] //id: User ID
        public JsonResult GetInfo(string id)
        {
            StandardCrudInfo test = new StandardCrudInfo();
            //Form building
            List<ElementDescription> elementDescriptions = new List<ElementDescription>();
            //"id:ID:number:textbox"
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "idRole",
                displayName = "Role ID",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        isPrimaryKey = true, //This key is primary key => do not allow user for changing on client side
                        propertyName = "idRole",
                        displayName="Role ID",
                        dataType="number",
                        controlType="textbox",
                        selectDatas = null,
                        cssStyle = new CssStyle
                        {
                            color = "red"
                        }
                    }
                }
            });
            //"userId:User ID:string:textbox"
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "id",
                displayName = "User Id",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        //isPrimaryKey = true, //This key is primary key => do not allow user for changing on client side
                        propertyName = "id",
                        displayName="User Id",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null,
                        cssStyle = new CssStyle
                        {
                            color = "red",
                            disabled = true,
                            //visibility = "hidden"
                        }
                    }
                }
            });
            //"claim:Claim:string:select:" + this.CalClaimString()
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "claim",
                displayName = "Claim",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "claim",
                        displayName="Claim",
                        dataType="string",
                        controlType="select",
                        selectDatas = this.CalClaimString()
                    }
                }
            });

            test.model = elementDescriptions;
            return Json(test);
        }

        private List<string> CalClaimString()
        {
            //Get list of all possible roles in application
            List<Claim> lstAppRoles = new List<Claim>();
            lstAppRoles = Define.ClaimDefine.GetAllClaim();

            var lstRet = lstAppRoles.Select(item => item.Value);
            return lstRet.ToList();
        }

        /// <summary>
        /// Get Data Info
        /// </summary>
        /// <returns></returns>
        [HttpGet("DataInfo")]
        public async Task<JsonResult> GetDataInfo(string id)
        {
            StandardDataInfo info = new StandardDataInfo();
            //Looking for user
            var user = await this.userManager.FindByIdAsync(id);
            if (user == null)
            {
                Response.StatusCode = 400;
                return Json("Error: user not exist!");
            }

            //Get list of all possible roles in application
            List<Claim> lstAppRoles = new List<Claim>();
            lstAppRoles = Define.ClaimDefine.GetAllClaim();

            //Looking for roles of user
            var roles = await this.userManager.GetClaimsAsync(user);
            info.total = roles.Count;
            return Json(info);
        }

        [HttpGet] //id: User ID .Test OK with Postman
        public async Task<JsonResult> Get(string id, int offset, int take) //id: Application User ID
        {
            //Looking for user
            var user = await this.userManager.FindByIdAsync(id);
            if (user == null)
            {
                Response.StatusCode = 400;
                return Json("Error: user not exist!");
            }

            //Get list of all possible roles in application
            List<Claim> lstAppRoles = new List<Claim>();
            lstAppRoles = Define.ClaimDefine.GetAllClaim();

            //Looking for roles of user
            var roles = await this.userManager.GetClaimsAsync(user);

            var roles2 = new List<Claim>();
            if (take != 0)
            {
                roles2 = roles
                    .Skip(offset)
                    .Take(take).ToList();
            }
            else
            {
                roles2 = roles
                    .Skip(offset).ToList();
            }

            //Create new class base on user's roles compare with list of all possible roles
            List<UserRoleDTO> lstRet = new List<UserRoleDTO>();

            for (int i = 0; i < lstAppRoles.Count; i++)
            {
                bool blFound = false;
                foreach (var item in roles2)
                {
                    if (item.Value == lstAppRoles[i].Value)
                    {
                        blFound = true;
                        break;
                    }
                }
                //
                if (blFound == true)
                {
                    lstRet.Add(new UserRoleDTO
                    {
                        idRole = i,
                        id = id,
                        claim = lstAppRoles[i].Value
                    });
                }
            }
            return Json(lstRet);
        }

        [HttpGet("Search")]
        public async Task<JsonResult> GetSearch(string id, string searchQuery, string searchCriteria)
        {
            //Default is search for all
            var keySearch = searchQuery.ToLower().Trim();

            //Looking for user
            var user = await this.userManager.FindByIdAsync(id);
            if (user == null)
            {
                Response.StatusCode = 400;
                return Json("Error: user not exist!");
            }

            //Get list of all possible roles in application
            List<Claim> lstAppRoles = new List<Claim>();
            lstAppRoles = Define.ClaimDefine.GetAllClaim();

            //Looking for roles of user
            var roles = await this.userManager.GetClaimsAsync(user);

            var roles2 = new List<Claim>();
            //Do searching
            foreach(var role in roles)
            {
                string test2 = "";

                JObject jo = JObject.FromObject(role);
                //JArray ja = new JArray();
                foreach (var value in jo.Values())
                {
                    //ja.Add(value);
                    test2 = test2 + value.ToString() + "\r\n";
                }

                if (test2.ToLower().Contains(keySearch))
                {
                    roles2.Add(role);
                }
            }

            //Create new class base on user's roles compare with list of all possible roles
            List<UserRoleDTO> lstRet = new List<UserRoleDTO>();

            for (int i = 0; i < lstAppRoles.Count; i++)
            {
                bool blFound = false;
                foreach (var item in roles2)
                {
                    if (item.Value == lstAppRoles[i].Value)
                    {
                        blFound = true;
                        break;
                    }
                }
                //
                if (blFound == true)
                {
                    lstRet.Add(new UserRoleDTO
                    {
                        idRole = i,
                        id = id,
                        claim = lstAppRoles[i].Value
                    });
                }
            }
            return Json(lstRet);

        }

        // POST api/values
        [HttpPost] //id: User ID
        public async Task<JsonResult> Post(string id, [FromBody]dynamic userRoleDto) //dynamic prevent [FromBody] fail because id is null!
        {
            Response.StatusCode = 200;

            try
            {
                //Looking for user
                var user = await this.userManager.FindByIdAsync(id);
                if (user == null)
                {
                    Response.StatusCode = 400;
                    return Json("Error: user not exist!");
                }

                //Looking for roles of user
                var roles = await this.userManager.GetClaimsAsync(user);
                var test3 = roles.Select(r => r.Value).ToList().Contains(userRoleDto.claim.ToString());
                if(test3==true)
                {
                    Response.StatusCode = 400;
                    return Json("Error: claim already exist!");
                }


                //Get list of all possible roles in application
                List<Claim> lstAppRoles = new List<Claim>();
                lstAppRoles = Define.ClaimDefine.GetAllClaim();

                //Looking for id of claim want to set for user
                for (int i =0;i<lstAppRoles.Count;i++)
                {
                    if(lstAppRoles[i].Value== userRoleDto.claim.ToString()) //Dynamic type...
                    {
                        //Set claim for user
                        IdentityResult test = await this.userManager.AddClaimAsync(user, lstAppRoles[i]);
                        //Return new role
                        return Json(new UserRoleDTO
                        {
                            idRole = i,
                            id = id,
                            claim = lstAppRoles[i].Value
                        });
                    }
                }

                return Json("Error: cannot find role want to set!");
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return Json(e.ToString());
            }
        }

        // PUT api/values/5 => Not support with user role control
        [HttpPut] //id: User ID
        public JsonResult Put(string id, [FromBody]dynamic userRoleDto)
        {
            Response.StatusCode = 400;
            return Json("Put() method not support with user role control! Instead, use Add & Delete.");
        }

        // DELETE api/values/5
        [HttpDelete("{idRole}")]
        public async Task<JsonResult> Delete(string id, int idRole)
        {
            //Looking for user
            var user = await this.userManager.FindByIdAsync(id);
            if (user == null)
            {
                Response.StatusCode = 400;
                return Json("Error: user not exist!");
            }

            //Get list of all possible roles in application
            List<Claim> lstAppRoles = new List<Claim>();
            lstAppRoles = Define.ClaimDefine.GetAllClaim();

            //Looking for roles of user
            var roles = await this.userManager.GetClaimsAsync(user);

            //Looking for if input claim already belong to user or not
            foreach (var role in roles)
            {
                if (role.Value == lstAppRoles[idRole].Value) //Need to remove claim from user
                {
                    IdentityResult remove = await this.userManager.RemoveClaimAsync(user, lstAppRoles[idRole]);
                    break;
                }
            }
            return Json("Del OK");
        }
    }
}
