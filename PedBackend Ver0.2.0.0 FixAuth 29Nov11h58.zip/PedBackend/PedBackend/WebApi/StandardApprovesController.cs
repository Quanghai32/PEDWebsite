﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using PedServer.Models;
using PedServer.Data;
using AutoMapper;
using PedServer.Models.UserControl;
using PedServer.Models.standardApprove;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PedServer.WebApi
{
    [Route("api/[controller]")]
    public class StandardApprovesController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ApplicationDbContext _context;
        private IMapper _mapper;

        public StandardApprovesController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            IMapper mapper
            )
        {
            _context = context;
            _userManager = userManager;
            _mapper = mapper;
        }

        // GET: api/values
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // Create new Verify Request: Requestor send to Verifier (person who check or approve request)
        [HttpPost("VerifyRequest")]
        public async Task<JsonResult> PostVerifyRequest([FromBody]VerifyRequest verifyRequest)
        {
            //We will convert approveRequest to User Event, and assign for related users
            Response.StatusCode = 200;

            try
            {
                //1. Check requestor & approver identity
                var requestor = await this._userManager.FindByNameAsync(verifyRequest.RequestorUserName);
                if (requestor == null)
                {
                    Response.StatusCode = 400;
                    return Json("Requestor UserName doesn't exist!");
                }
                var approver = await this._userManager.FindByNameAsync(verifyRequest.ApproverUserName);
                if (approver == null)
                {
                    Response.StatusCode = 400;
                    return Json("Approver UserName doesn't exist!");
                }
                //If everything OK, then create User Event for them
                var newEvent = new UserEvent();
                newEvent.EventName = verifyRequest.ActionDescription;
                newEvent.Application = verifyRequest.ApplicationName;
                newEvent.Message = verifyRequest.RequestorComment;
                newEvent.EventLink = verifyRequest.FrontendLink;
                newEvent.EventTime = DateTime.Now;

                //Create new UserEvent in Database
                var test1 = _context.UserEvent.Add(newEvent);
                var test2 = _context.SaveChanges();

                //Assign for Approver this event
                var newAssignment = new EventAssignment();
                newAssignment.UserEventID = test1.Entity.ID;
                newAssignment.ApplicationUserID = approver.Id;
                var test3 = _context.EventAssignments.Add(newAssignment);
                var test4 = _context.SaveChanges();

                //Sending Email for Approver
                //Sending Email Code go here!


                //2. To create new Verify Request & Save into Database
                var newVerifyRequest = new VerifyRequest();
                newVerifyRequest = verifyRequest;
                newVerifyRequest.RequestTime = DateTime.Now;
                var test5 = _context.VerifyRequests.Add(newVerifyRequest);
                var test6 = _context.SaveChanges();

                //3. Create new Verify Result & Save into Database
                var newVerifyResult = new VerifyResult();
                // newVerifyResult.VerifyRequest = newVerifyRequest;
                newVerifyResult.VerifyRequestID = test5.Entity.ID;
                newVerifyResult.Result = "Not confirmed yet.";
                var test7 = _context.VerifyResults.Add(newVerifyResult);
                var test8 = _context.SaveChanges();

                return Json("Verify Request created Successfully!");
            }
            catch (Exception ex)
            {
                Response.StatusCode = 400;
                return Json(ex.Message);
            }
        }

        // Create new Verify Result: Verifier checking or approval result.
        [HttpPost("VerifyResult")]
        public async Task<JsonResult> PostVerifyResult([FromBody]VerifyResult verifyResult)
        {
            //We will convert approveRequest to User Event, and assign for related users
            Response.StatusCode = 200;

            try
            {
                //1. Check requestor & approver identity
                var requestor = await this._userManager.FindByNameAsync(verifyResult.VerifyRequest.RequestorUserName);
                if (requestor == null)
                {
                    Response.StatusCode = 400;
                    return Json("Requestor UserName doesn't exist!");
                }
                var approver = await this._userManager.FindByNameAsync(verifyResult.VerifyRequest.ApproverUserName);
                if (approver == null)
                {
                    Response.StatusCode = 400;
                    return Json("Approver UserName doesn't exist!");
                }

                //Sending Email for Requestpr & Approver here
                //Sending Email Code go here!


                //2. To create new Verify Request & Save into Database
                var newVerifyResult = new VerifyResult();
                newVerifyResult = verifyResult;
                var test5 = _context.VerifyResults.Add(newVerifyResult);
                var test6 = _context.SaveChanges();

                return Json("Verify Result created Successfully!");
            }
            catch (Exception ex)
            {
                Response.StatusCode = 400;
                return Json(ex.Message);
            }
        }

        // Modify Verify Result: Change Verifier checking or approval result.
        [HttpPut("VerifyResult")]
        public async Task<JsonResult> PutVerifyResult([FromBody]VerifyResult verifyResult)
        {
            //We will convert approveRequest to User Event, and assign for related users
            Response.StatusCode = 200;

            try
            {
                //1. Check requestor & approver identity
                var requestor = await this._userManager.FindByNameAsync(verifyResult.VerifyRequest.RequestorUserName);
                if (requestor == null)
                {
                    Response.StatusCode = 400;
                    return Json("Requestor UserName doesn't exist!");
                }
                var approver = await this._userManager.FindByNameAsync(verifyResult.VerifyRequest.ApproverUserName);
                if (approver == null)
                {
                    Response.StatusCode = 400;
                    return Json("Approver UserName doesn't exist!");
                }

                //Sending Email for Requestpr & Approver here
                //Sending Email Code go here!


                //2. To create new Verify Request & Save into Database
                //var newVerifyResult = new VerifyResult();
                //newVerifyResult = verifyResult;
                var test5 = _context.VerifyResults.Attach(verifyResult);
                _context.Entry(verifyResult).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                var test6 = _context.SaveChanges();

                return Json("Verify Result created Successfully!");
            }
            catch (Exception ex)
            {
                Response.StatusCode = 400;
                return Json(ex.Message);
            }
        }


        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
