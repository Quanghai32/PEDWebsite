﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PedServer.Data;
using PedServer.Models.StandardCrud;
using Microsoft.EntityFrameworkCore;
using AutoMapper;
using PedServer.Models.UserControl;
using Microsoft.AspNetCore.Identity;
using PedServer.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PedServer.WebApi
{
    public class UserEventDTO
    {
        public string ID { get; set; } //ID of event
        public string Application { get; set; } //Application name 
        public string EventName { get; set; } //Event Name
        public string Message { get; set; } //Event message
        public string EventLink { get; set; } //Event link - link to view detail Info of event
        public DateTime EventTime { get; set; } //Record time when event occur

        //public ICollection<EventAssignment> ApplicationUsers { get; set; }
    }

    [Route("api/[controller]")]
    public class UserEventsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IMapper _mapper;

        public UserEventsController(
            ApplicationDbContext context,
            IMapper mapper,
            UserManager<ApplicationUser> userManager
            )
        {
            _context = context;
            _mapper = mapper;
            _userManager = userManager;
        }

        [HttpGet("info")]
        public JsonResult GetInfo()
        {
            StandardCrudInfo test = new StandardCrudInfo();

            //Create & Add Model Info
            List<ElementDescription> elementDescriptions = new List<ElementDescription>();
            //public string ID { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "ID",
                displayName = "ID",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        isPrimaryKey = true, //This key is primary key => do not allow user for changing on client side
                        propertyName = "ID",
                        displayName="ID",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null,
                        cssStyle = new CssStyle
                        {
                            color = "red"
                        }
                    }
                }
            });
            //public string Application { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "Application",
                displayName = "Application",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "Application",
                        displayName="Application",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });
            //public string EventName
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "EventName",
                displayName = "Event Name",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "EventName",
                        displayName="Event Name",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                }
            });
            //public string Message
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "Message",
                displayName = "Message",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "Message",
                        displayName="Message",
                        dataType="string",
                        controlType="pre",
                        selectDatas = null
                    }
                }
            });
            //public string EventLink
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "EventLink",
                displayName = "Event Link",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "EventLink",
                        displayName="Event Link",
                        dataType="href",
                        controlType="href"
                    }
                }
            });
            //public DateTime EventTime
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "EventTime",
                displayName = "EventTime",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "EventTime",
                        displayName="EventTime",
                        dataType="string",
                        controlType="date"
                    }
                }
            });

            //Add Model Info
            test.model = elementDescriptions;

            return Json(test);
        }

        /// <summary>
        /// Get Data Info
        /// </summary>
        /// <returns></returns>
        [HttpGet("DataInfo")]
        public StandardDataInfo GetDataInfo(string userId)
        {
            StandardDataInfo info = new StandardDataInfo();

            var test = _context.EventAssignments
                .Include(e => e.ApplicationUser)
                .Where(e => e.ApplicationUserID == userId).ToList();

            info.total = test.Count;
            return info;
        }

        // GET: api/values
        [HttpGet]
        public async Task<JsonResult> Get(string userId, int offset, int take)
        {
            if(userId==null)
            {
                Response.StatusCode = 400;
                return Json("Error: userId cannot be null.");
            }

            //Check User ID
            var user = await _userManager.FindByIdAsync(userId);
            if(user == null)
            {
                Response.StatusCode = 400;
                return Json("Error: Cannot find user.");
            }
            //Only load event belong to user
            var lstRet = new List<UserEventDTO>();
            var lstAll = new List<UserEventDTO>();

            var lstTest = _context.EventAssignments
                .Where(e => e.ApplicationUserID == userId).ToList();
            foreach(var item in lstTest)
            {
                var uEvent = _context.UserEvent
                    .Where(u => u.ID == item.UserEventID).FirstOrDefault();
                if(uEvent!=null)
                {
                    lstAll.Add(_mapper.Map<UserEvent, UserEventDTO>(uEvent));
                }
            }

            //If take = 0: get all item from offset to end
            if (take != 0)
            {
                lstRet = lstAll
                .Skip(offset)
                .Take(take)
                .OrderByDescending(u => u.EventTime).ToList();
            }
            else
            {
                lstRet = lstAll
                .Skip(offset)
                .OrderByDescending(u => u.EventTime).ToList();
            }

            return Json(lstRet);
        }

        //// GET api/values/5
        //[HttpGet("{id}")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        // POST api/values
        [HttpPost]
        public JsonResult Post(string userId, [FromBody]dynamic value)
        {
            return (Json("UserEvents Error: Create New not allowed!"));
        }

        // PUT api/values/5
        [HttpPut]
        public JsonResult Put(string userId, [FromBody]dynamic value)
        {
            return (Json("UserEvents Error: Modify not allowed!"));
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public async Task<string> Delete(string userId, string id)
        {
            Response.StatusCode = 200;

            try
            {
                UserEvent delUserEvent = await _context.UserEvent
                    .SingleOrDefaultAsync(item => item.ID == id);

                //Now deleted 
                _context.UserEvent.Remove(delUserEvent);
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return e.ToString();
            }
            return "OK";
        }
    }
}
