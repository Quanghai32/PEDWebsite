﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using PedServer.Data;
using Microsoft.AspNetCore.Identity;
using PedServer.Models;
using PedServer.Server.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PedServer.WebApi
{
    public class UserRegisterDTO
    {
        public string name { get; set; }
        public string userName { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string confirmPassword { get; set; }
    }


    [Route("api/[controller]")]
    [Produces("application/json")]
    [AllowAnonymous]
    public class UserRegistersController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ApplicationDbContext _context;
        private readonly IEmailSender _emailSender;

        public UserRegistersController(
                ApplicationDbContext context, 
                UserManager<ApplicationUser> userManager,
                IEmailSender emailSender
            )
        {
            _context = context;
            _userManager = userManager;
            _emailSender = emailSender;
        }


        //// GET: api/values
        //[HttpGet]
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public async Task<JsonResult> Post([FromBody]UserRegisterDTO userRegisterDTO)
        {
            //var test = userRegisterDTO;
            //User Register Procedure:
            //  1. User fill all required register information
            //  2. Do check user infor valid or not
            //  3. If OK, create new account for user (with email confirm = false)
            //  4. Sending email to user for complete register
            //  5. User click on sent link
            //  6. Change state of user to email confirm = true
            //  7. Now, user can access PED website!

            Response.StatusCode = 200; //Start with OK status
            //1. Check user information valid or not
            //1.1. Check if user name already exist or not
            var testExist = await _userManager.FindByNameAsync(userRegisterDTO.userName.Trim());
            if(testExist!=null)
            {
                Response.StatusCode = 400;
                return Json("Error: Username already exist!");
            }

            //1.2. If username not yet exist, then try to create new application user
            try
            {
                var newUser = new ApplicationUser
                {
                    UserName = userRegisterDTO.userName,
                    Email = userRegisterDTO.email,
                    Name = userRegisterDTO.name
                };

                var result = await _userManager.CreateAsync(newUser, userRegisterDTO.password);
                if(result.Succeeded) //Create success
                {
                    // For more information on how to enable account confirmation and password reset please visit http://go.microsoft.com/fwlink/?LinkID=532713
                    // Send an email with this link
                    var code = await _userManager.GenerateEmailConfirmationTokenAsync(newUser);
                    var callbackUrl = Url.Action("ConfirmEmail", "UserRegisters", new { userId = newUser.Id, code = code }, protocol: HttpContext.Request.Scheme);
                    //callbackUrl = .../api/UserRegisters?userId=abc...&code=123...
                    //But we don't want user directly access here. So we modify call back URL to navigate user to front-end setting url route
                    //callbackUrl2 = .../UserRegisters?userId=abc...&code=123...

                    //var test = Url.

                    var callbackUrl2 = callbackUrl.Replace("api/", ""); //Reject "api/"

                    await _emailSender.SendEmailAsync(newUser.Email, "Confirm your account",
                        $"Please confirm your account by clicking this link: <a href='{callbackUrl2}'>link</a>");

                    //return Json("New account created successfully!");
                }
                else
                {
                    Response.StatusCode = 400;
                    return Json("Create new account fail! Error detail: " + result.Errors.FirstOrDefault().ToString());
                }
            }
            catch(Exception ex)
            {
                Response.StatusCode = 400;
                return Json(ex.Message);
            }

            return Json("New account created successfully!");
        }

        // GET: /Account/ConfirmEmail
        [HttpGet]
        [AllowAnonymous]
        public async Task<JsonResult> ConfirmEmail(string userId, string code)
        {
            Response.StatusCode = 200; //start with OK code
            if (userId == null || code == null)
            {
                Response.StatusCode = 400;
                return Json("Error: userid or code is null!");
            }
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                Response.StatusCode = 400;
                return Json("Error: user not exist!");
            }
            var result = await _userManager.ConfirmEmailAsync(user, code);
            if(!result.Succeeded)
            {
                Response.StatusCode = 400;
                return Json("Error: email confirm fail!\r\n" 
                    + "Error Code: " + result.Errors.FirstOrDefault().Code + "\r\n"
                    + "Error Description: " + result.Errors.FirstOrDefault().Description);
            }
            return Json("Email confirm successfully!");
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
