﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PedServer.Data;
using PedServer.Models.StandardCrud;
using Microsoft.EntityFrameworkCore;
using PedServer.Models.ModelJigInfo;
using Newtonsoft.Json.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PedServer.WebApi
{

    //public class JigProfileDTO
    //{
    //    public string ID { get; set; }
    //    public string JigName { get; set; }
    //    public string JigCode { get; set; }
    //    public string JigRev { get; set; }
    //}

    public class ModelJigInfoDTO
    {
        public string ID { get; set; }
        public string ModelName { get; set; }
        public List<JigProfileDTO> JigProfileDTOs { get; set; }
    }

    [Produces("application/json")]
    [Route("api/[controller]")]
    public class ModelJigInfosController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ModelJigInfosController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("info")]
        public JsonResult GetInfo()
        {
            StandardCrudInfo test = new StandardCrudInfo();
            //Form building
            List<ElementDescription> elementDescriptions = new List<ElementDescription>();
            //public string ID { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "ID",
                displayName = "ID",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        isPrimaryKey = true, //This key is primary key => do not allow user for changing on client side
                        propertyName = "ID",
                        displayName="ID",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null,
                        cssStyle = new CssStyle
                        {
                            color = "red"
                        }
                    }
                }
            });
            // public string ModelName { get; set; }
            elementDescriptions.Add(new ElementDescription
            {
                type = "item",
                elementName = "ModelName",
                displayName = "Product Model",
                propertyDescriptions = new List<PropertyDescription>
                {
                    new PropertyDescription
                    {
                        propertyName = "ModelName",
                        displayName="Product Model",
                        dataType="string",
                        controlType="select",
                        selectDatas = _context.ProductModel.ToList()
                        .Select(p=>p.ModelName).ToList()
                    }
                }
            });
            //public List<JigProfileDTO> JigProfileDTOs { get; set; }
            //List child item
            elementDescriptions.Add(new ElementDescription
            {
                //Here we have to handle situation that user will select from existing jig profile. Not create new one.
                type = "list",
                elementName = "JigProfileDTOs",
                displayName = "Jig List Profile",
                createMethod = "select", //Create new element by select from existing target objects
                searchUrl = "/api/JigProfiles/search",
                propertyDescriptions = new List<PropertyDescription>
                {
                    //public string ID { get; set; }
                    new PropertyDescription
                    {
                        isPrimaryKey = true, //This key is primarykey
                        propertyName = "ID",
                        displayName="ID",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    },
                    //public string JigName { get; set; }
                    new PropertyDescription
                    {
                        propertyName = "JigName",
                        displayName="Jig Name",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    },
                    //public string JigCode { get; set; }
                    new PropertyDescription
                    {
                        propertyName = "JigCode",
                        displayName="Jig Code",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    },
                    //public string JigRev { get; set; }
                    new PropertyDescription
                    {
                        propertyName = "JigRev",
                        displayName="Jig Rev",
                        dataType="string",
                        controlType="textbox",
                        selectDatas = null
                    }
                },
                cssStyle = new CssStyle
                {
                    visibility="hidden"
                }
            });
            //
            test.model = elementDescriptions;
            return Json(test);
        }

        /// <summary>
        /// Get Data Info
        /// </summary>
        /// <returns></returns>
        [HttpGet("DataInfo")]
        public StandardDataInfo GetDataInfo()
        {
            StandardDataInfo info = new StandardDataInfo();
            var test = _context.ModelJigInfo.Count();
            info.total = test;
            return info;
        }

        //// GET: api/values
        //[HttpGet]
        //public IEnumerable<ModelJigInfoDTO> Get()
        //{
        //    List<ModelJigInfoDTO> lstRet = new List<ModelJigInfoDTO>();

        //    var lstInfo = _context.ModelJigInfo
        //        .Include(item => item.ModelJigProfileAssignments);
        //    foreach (var modelJigInfo in lstInfo)
        //    {
        //        var jigProfileDTOs = new List<JigProfileDTO>();
        //        foreach (var item in modelJigInfo.ModelJigProfileAssignments)
        //        {
        //            var jigProfileDTO = new JigProfileDTO();
        //            //
        //            var jigProfile = _context.JigProfile.SingleOrDefault(j => j.ID == item.JigProfileID);
        //            jigProfileDTO.ID = jigProfile.ID;
        //            jigProfileDTO.JigName = jigProfile.JigName;
        //            jigProfileDTO.JigCode = jigProfile.JigCode;
        //            jigProfileDTO.JigRev = jigProfile.JigRev;
        //            //
        //            jigProfileDTOs.Add(jigProfileDTO);
        //        }

        //        var test = new ModelJigInfoDTO
        //        {
        //            ID = modelJigInfo.ID,
        //            ModelName = _context.ProductModel.SingleOrDefault(p=>p.ID==modelJigInfo.ProductModelID).ModelName,
        //            JigProfileDTOs = jigProfileDTOs
        //        };
        //        lstRet.Add(test);
        //    }

        //    return lstRet;
        //}


        [HttpGet]
        public IEnumerable<ModelJigInfoDTO> Get(int offset, int take)
        {
            List<ModelJigInfoDTO> lstRet = new List<ModelJigInfoDTO>();
            var lstInfo = new List<ModelJigInfo>();

            if(take!=0) //Get some items, not all
            {
                lstInfo = _context.ModelJigInfo
                    .Include(item => item.ProductModel)
                    .Include(item => item.ModelJigProfileAssignments)
                    .Skip(offset)
                    .Take(take)
                    .ToList();
            }
            else //Get all items
            {
                lstInfo = _context.ModelJigInfo
                    .Include(item => item.ProductModel)
                    .Include(item => item.ModelJigProfileAssignments)
                    .Skip(offset)
                    .ToList();
            }

            foreach (var modelJigInfo in lstInfo)
            {
                if(modelJigInfo.ModelJigProfileAssignments!=null)
                {
                    var jigProfileDTOs = new List<JigProfileDTO>();
                    foreach (var item in modelJigInfo.ModelJigProfileAssignments)
                    {
                        var jigProfileDTO = new JigProfileDTO();
                        //
                        var jigProfile = _context.JigProfile.SingleOrDefault(j => j.ID == item.JigProfileID);
                        jigProfileDTO.ID = jigProfile.ID;
                        jigProfileDTO.JigName = jigProfile.JigName;
                        jigProfileDTO.JigCode = jigProfile.JigCode;
                        jigProfileDTO.JigRev = jigProfile.JigRev;
                        //
                        jigProfileDTOs.Add(jigProfileDTO);
                    }

                    var test = new ModelJigInfoDTO
                    {
                        ID = modelJigInfo.ID,
                        ModelName = _context.ProductModel.SingleOrDefault(p => p.ID == modelJigInfo.ProductModelID).ModelName,
                        JigProfileDTOs = jigProfileDTOs
                    };
                    lstRet.Add(test);
                }
            }

            return lstRet;
        }

        [HttpGet("Search")]
        public IEnumerable<ModelJigInfoDTO> GetSearch(string searchQuery, string searchCriteria)
        {
            //Default is search for all
            var keySearch = searchQuery.ToLower().Trim();

            var lstInfo = new List<ModelJigInfo>();
            lstInfo = _context.ModelJigInfo
                .Include(item=>item.ProductModel)
                .Include(item => item.ModelJigProfileAssignments)
                .ThenInclude(j=>j.JigProfile)
                .ToList();

            var lstTest = new List<ModelJigInfo>();
            foreach (var item in lstInfo)
            {
                string test2 = "";

                JObject jo = JObject.FromObject(item, new Newtonsoft.Json.JsonSerializer()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                    //PreserveReferencesHandling = Newtonsoft.Json.PreserveReferencesHandling.None
                });

                //JObject jo = JObject.FromObject(item);

                //JArray ja = new JArray();
                foreach (var value in jo.Values())
                {
                    //ja.Add(value);
                    test2 = test2 + value.ToString() + "\r\n";
                }

                if (test2.ToLower().Contains(keySearch))
                {
                    lstTest.Add(item);
                }
            }

            var lstRet = new List<ModelJigInfoDTO>();
            foreach (var modelJigInfo in lstTest)
            {
                var jigProfileDTOs = new List<JigProfileDTO>();
                foreach (var item in modelJigInfo.ModelJigProfileAssignments)
                {
                    var jigProfileDTO = new JigProfileDTO();
                    //
                    var jigProfile = _context.JigProfile.SingleOrDefault(j => j.ID == item.JigProfileID);
                    jigProfileDTO.ID = jigProfile.ID;
                    jigProfileDTO.JigName = jigProfile.JigName;
                    jigProfileDTO.JigCode = jigProfile.JigCode;
                    jigProfileDTO.JigRev = jigProfile.JigRev;
                    //
                    jigProfileDTOs.Add(jigProfileDTO);
                }

                var test = new ModelJigInfoDTO
                {
                    ID = modelJigInfo.ID,
                    ModelName = _context.ProductModel.SingleOrDefault(p => p.ID == modelJigInfo.ProductModelID).ModelName,
                    JigProfileDTOs = jigProfileDTOs
                };
                lstRet.Add(test);
            }
            return lstRet;
        }



        //// GET api/values/5
        //[HttpGet("{id}")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        // POST api/values
        [HttpPost]
        public JsonResult Post([FromBody]ModelJigInfoDTO modelJigInfoDTO)
        {
            Response.StatusCode = 200;

            try
            {
                //First we create new ModelJigInfo (Reject "id" key)
                var newModelJigInfo = new ModelJigInfo
                {
                    ProductModelID = _context.ProductModel
                    .SingleOrDefault(m => m.ModelName == modelJigInfoDTO.ModelName).ID
                };

                var test1 = _context.ModelJigInfo.Add(newModelJigInfo);
                //When we have new ModelJigInfo identity, then create ModelJigProfileAssignment
                foreach (var item in modelJigInfoDTO.JigProfileDTOs)
                {
                    ////We need to find JigProfileID from Display Info
                    //string[] strTest = item.DisplayInfo.Split(';');
                    //var result = _context.JigProfile.SingleOrDefault(j =>
                    //((j.JigName == strTest[0])&&(j.JigCode == strTest[1]) &&(j.JigRev == strTest[2]))
                    //);

                    var newModelJigProfileAssignment = new ModelJigProfileAssignment
                    {
                        ModelJigInfoID = test1.Entity.ID,
                        JigProfileID = item.ID
                    };

                    var test11 = _context.ModelJigProfileAssignment.Add(newModelJigProfileAssignment);
                    //var test12 = _context.SaveChanges();
                }

                var test2 = _context.SaveChanges();

                //Reading entity again & return result
                var modelJigInfo = _context.ModelJigInfo
                    .Include(t => t.ModelJigProfileAssignments)
                    .SingleOrDefault(i => i.ID == test1.Entity.ID);

                //Create DTO and return
                var jigProfileDTOs = new List<JigProfileDTO>();
                foreach (var item in modelJigInfo.ModelJigProfileAssignments)
                {
                    var jigProfileDTO = new JigProfileDTO();
                    //
                    var jigProfile = _context.JigProfile.SingleOrDefault(j => j.ID == item.JigProfileID);
                    jigProfileDTO.ID = jigProfile.ID;
                    jigProfileDTO.JigName = jigProfile.JigName;
                    jigProfileDTO.JigCode = jigProfile.JigCode;
                    jigProfileDTO.JigRev = jigProfile.JigRev;
                    //
                    jigProfileDTOs.Add(jigProfileDTO);
                }

                var test = new ModelJigInfoDTO
                {
                    ID = modelJigInfo.ID,
                    ModelName = _context.ProductModel.SingleOrDefault(p=>p.ID==modelJigInfo.ProductModelID).ModelName,
                    JigProfileDTOs = jigProfileDTOs
                };

                //Return saved entity => we need return new created entity because we need info like id to update on view of client side
                return Json(test);
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return Json(e.ToString());
            }
        }

        // PUT api/values/5
        [HttpPut]
        public async Task<JsonResult> Put([FromBody]ModelJigInfoDTO modelJigInfoDTO)
        {
            Response.StatusCode = 200;

            try
            {
                //1. First, we need to find info of Parent Object in database
                var modelJigInfoToUpdate = await _context.ModelJigInfo.AsNoTracking()
                    .Include(i => i.ModelJigProfileAssignments)
                    .ThenInclude(m =>m.JigProfile)
                    .Include(p => p.ProductModel) //Loading with Product Model
                    .SingleOrDefaultAsync(m => m.ID == modelJigInfoDTO.ID);

                //Modify some properties
                modelJigInfoToUpdate.ProductModelID = _context.ProductModel
                    .SingleOrDefault(p => p.ModelName == modelJigInfoDTO.ModelName).ID;

                //3. Saving TestCrud
                // Note that 
                _context.ModelJigInfo.Attach(modelJigInfoToUpdate);
                _context.Entry(modelJigInfoToUpdate).State = EntityState.Modified;

                //Save all change
                _context.SaveChanges();

                //We need handle some cases:
                //  1. User want to create new child item for Parent Object
                //  2. User want to modify existing child item of Parent Object
                //  3. User want to delete existing child item of Parent Object

                var currentItemList = new HashSet<string>(modelJigInfoToUpdate
                        .ModelJigProfileAssignments.Select(i => i.JigProfileID)
                    ); //Current list

                //To find desired list, we must find from name-code-rev
                //var desiredItemList = modelJigInfoDTO.JigProfileDTOs.Select(item => item.ID).ToList(); //User want to have
                var desiredItemList = new List<string>();
                foreach(var d in modelJigInfoDTO.JigProfileDTOs)
                {
                    desiredItemList.Add(d.ID);
                }

                var currentDBItem = _context.JigProfile.AsNoTracking().ToList(); //Hold all item existing in database
                var currentDatabaseList = currentDBItem.Select(t => t.ID).ToList();

                //1. To ensure al desired list need to update
                foreach (var itemId in desiredItemList) //check all item in desired list
                {
                    if (currentDatabaseList.Contains(itemId)) //selected item already exist in database (surely?) => Add this child item if necessary
                    {
                        if(!currentItemList.Contains(itemId)) //Add more if not yet include
                        {
                            //We add child item to Parent Object by adding assignment class item
                            var newModelJigProfileAssignment = new ModelJigProfileAssignment
                            {
                                ModelJigInfoID = modelJigInfoToUpdate.ID,
                                JigProfileID = itemId
                            };
                            var test11 = _context.ModelJigProfileAssignment.Add(newModelJigProfileAssignment);
                        }
                    }
                    else //desired item does not exist in database (cannot happen?) => user want to create new?
                    {
                        //With Jig Profile, user cannot modify or create new here
                        //If these actions are necessary => user must user Jig Profile Control Application instead
                    }
                }
                //2. Remove unwanted item
                foreach (var itemID in currentItemList)
                {
                    if (!desiredItemList.Contains(itemID))
                    {
                        //remove handle
                        var delItem = _context.ModelJigProfileAssignment
                            .SingleOrDefault(t => (t.JigProfileID == itemID)&&(t.ModelJigInfoID== modelJigInfoToUpdate.ID));
                        _context.ModelJigProfileAssignment.Remove(delItem);
                    }
                }

                ////3. Saving TestCrud
                //// Note that 
                //_context.ModelJigInfo.Attach(modelJigInfoToUpdate);
                //_context.Entry(modelJigInfoToUpdate).State = EntityState.Modified;

                //Save all change
                _context.SaveChanges();

                //Reading entiy again and return to frontend
                var result2 = _context.ModelJigInfo
                    .Include(t => t.ModelJigProfileAssignments)
                    .SingleOrDefault(i => i.ID == modelJigInfoToUpdate.ID);

                //Create DTO and return to front end
                var retModelJigInfoDTO = new ModelJigInfoDTO();
                retModelJigInfoDTO.ID = result2.ID;
                retModelJigInfoDTO.ModelName = result2.ProductModel.ModelName;
                var retJigProfileDTOs = new List<JigProfileDTO>();
                foreach(var item in result2.ModelJigProfileAssignments)
                {
                    var retJigProfile = _context.JigProfile
                        .SingleOrDefault(j => j.ID == item.JigProfileID);
                    var newJigProfileDTO = new JigProfileDTO
                    {
                        ID = item.JigProfileID,
                        JigName = item.JigProfile.JigName,
                        JigCode = item.JigProfile.JigCode,
                        JigRev = item.JigProfile.JigRev
                    };
                    retJigProfileDTOs.Add(newJigProfileDTO);
                };
                retModelJigInfoDTO.JigProfileDTOs = retJigProfileDTOs;

                //Return saved entity => we need return new created entity because we need info like id to update on view of client side
                return Json(retModelJigInfoDTO);

            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return Json(e.ToString());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public async Task<string> Delete(string id)
        {
            Response.StatusCode = 200;

            try
            {
                ModelJigInfo delModelJigInfo = await _context.ModelJigInfo
                    .Include(i => i.ModelJigProfileAssignments)
                    .SingleOrDefaultAsync(item => item.ID == id);
                //Remove all TestCrudItemLists belong to item TestCrud which want to deleted
                if (delModelJigInfo.ModelJigProfileAssignments != null)
                {
                    _context.ModelJigProfileAssignment.RemoveRange(delModelJigInfo.ModelJigProfileAssignments);
                    await _context.SaveChangesAsync();
                }

                //Now deleted TestCrud
                _context.ModelJigInfo.Remove(delModelJigInfo);
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return e.ToString();
            }
            return "OK";
        }
    }
}
