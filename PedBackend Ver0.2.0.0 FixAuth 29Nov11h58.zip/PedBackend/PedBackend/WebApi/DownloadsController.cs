﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Text;
using System.Net.Http.Headers;

namespace PedBackend.WebApi
{
    // [Produces("application/json")]
    [Route("api/Downloads")]
    public class DownloadsController : Controller
    {
		//[HttpGet]
		//public FileResult Get()
		//{
		//	using (var stream = new FileStream(@"D:\test.pdf", FileMode.Open))
		//	{
		//		return File(stream, "application/pdf", "FileDownloadName.ext");
		//	}
		//}


		[HttpGet]
		public FileStreamResult Get() // already tested OK!!!
		{
            var stream = new MemoryStream(Encoding.ASCII.GetBytes("Hello World"));
            return new FileStreamResult(stream, "text/plain")
            {
                FileDownloadName = "test.txt"
            };

            //var stream = new FileStream(@"D:\test.pdf", FileMode.Open);
            //return new FileStreamResult(stream, "application/pdf")
            //{
            //	FileDownloadName = "download.txt"
            //};

        }

	}
}