﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PedServer.Data;
using Microsoft.EntityFrameworkCore;
using PedServer.Models.StandardCrud;
using PedServer.WebApi;
using PedServer.Models.JigRequest;
using PedServer.Models;
using Microsoft.AspNetCore.Identity;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PedServer.WebApi
{
    [Route("api/[controller]")]
    public class JigRequestsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> userManager;

        public JigRequestsController(ApplicationDbContext context,
            UserManager<ApplicationUser> userManager)
        {
            _context = context;
            this.userManager = userManager;
        }

        [HttpGet("info")]
        public JsonResult GetInfo()
        {
            StandardCrudInfo test = new StandardCrudInfo();
            //Form building regulation
            //  Property Name : Label display on form : Type of Data : Type of Form Control : Parameter (options for select...)
            test.model = new string[] {
                "id:ID:string:textbox",
                "deptName:Dept Name:string:textbox",
                "deptCode:Dept Code:string:textbox",
                "requestControlNo:Control No:string:textbox",
                "userName:User Name:string:textbox"
            };

            return Json(test);
        }

        /// <summary>
        /// Get Data Info
        /// </summary>
        /// <returns></returns>
        [HttpGet("DataInfo")]
        public StandardDataInfo GetDataInfo()
        {
            StandardDataInfo info = new StandardDataInfo();
            var test = _context.JigRequest.Count();
            info.total = test;
            return info;
        }


        // GET: api/values
        [HttpGet]
        public JsonResult Get()
        {
            //var jigRequests = _context.JigRequest
            //    .Include(req => req.requisitionArea)
            //    .ThenInclude(reqArea => reqArea.requestDeptReqInfo);

            ////return _context.JigRequest.ToList();
            //return jigRequests.ToList();


            //Only load what request belong to current user?
            List<RequestDeptReqInfoDto> lstRet = new List<RequestDeptReqInfoDto>();

            var requestDeptReqInfos = _context.RequestDeptReqInfo.Include(r => r.issuedByInfo);
            foreach (RequestDeptReqInfo req in requestDeptReqInfos)
            {
                var newItem = new RequestDeptReqInfoDto
                {
                    id = req.ID,
                    deptName = req.deptName,
                    deptCode = req.deptCode,
                    requestControlNo = req.requestControlNo,
                    userName = this.FindRequestorName(req)
                };
                //
                lstRet.Add(newItem);
            }

            return Json(lstRet.ToList());
        }

        public string FindRequestorName(RequestDeptReqInfo infoInput)
        {
            string strRet = "unknown";
            if (infoInput.issuedByInfo == null) return strRet;
            if (infoInput.issuedByInfo.ApplicationUserID == null) return strRet;
            //
            var user = this.userManager.FindByIdAsync(infoInput.issuedByInfo.ApplicationUserID).Result;
            if (user != null) return user.UserName;
            //Not found
            return strRet;
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public string Post([FromBody]Models.JigRequest.RequestDeptReqInfo requestDeptReqInfo)
        {
            Response.StatusCode = 200;

            try
            {
                //From requestDeptReqInfo => create new JigRequest and update database
                Models.JigRequest.JigRequest newJigRequest = new Models.JigRequest.JigRequest();
                newJigRequest.requisitionArea = new Models.JigRequest.RequisitionArea();
                newJigRequest.requisitionArea.requestDeptReqInfo = requestDeptReqInfo;

                _context.JigRequest.Add(newJigRequest);
                _context.SaveChanges();
            }
            catch (Exception e)
            {
                Response.StatusCode = 400;
                return e.ToString();
            }
            return "OK";
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public string Delete(string id)
        {
            Response.StatusCode = 200;

            try
            {
                Models.JigRequest.JigRequest delJigRequest = new Models.JigRequest.JigRequest();
                delJigRequest.ID = id;
                _context.JigRequest.Remove(delJigRequest);
                _context.SaveChanges();
            }
            catch (Exception e)
            {
                return e.ToString();
            }
            return "OK";
        }
    }
}
