﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using PedServer.Models;
using PedServer.Data;

namespace PedBackend.Controllers
{
    [Produces("application/json")]
    [Route("api/TestServer")]
    public class TestServerController : Controller
    {
		private readonly UserManager<ApplicationUser> _userManager;
		private readonly ApplicationDbContext _context;

		public TestServerController(
		   ApplicationDbContext context,
		   UserManager<ApplicationUser> userManager
		   )
		{
			_context = context;
			_userManager = userManager;
		}

		// GET api/values
		[HttpGet]
		public string Get()
		{
			try
			{
				var test = _userManager.Users.Take(1).ToList();
				return test[0].Name;
			}
			catch(Exception ex)
			{
				return "Exception: " + ex.Message;
			}
		}

		// GET api/values/5
		[HttpGet("{id}")]
		public string Get(int id)
		{
			return "value";
		}

		// POST api/values
		[HttpPost]
		public void Post([FromBody]string value)
		{
		}

		// PUT api/values/5
		[HttpPut("{id}")]
		public void Put(int id, [FromBody]string value)
		{
		}

		// DELETE api/values/5
		[HttpDelete("{id}")]
		public void Delete(int id)
		{
		}
	}
}