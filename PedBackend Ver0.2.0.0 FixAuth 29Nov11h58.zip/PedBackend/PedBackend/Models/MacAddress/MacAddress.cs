﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PedServer.Models.MacAddress
{
    public class MacAddress
    {
        [Key]
        public string ID { get; set; }
        public string MacModelName { get; set; } //QM7-1234 ...
        //List of LowRange - High Range
        public ICollection<MacAddressRange> MacAddressRanges { get; set; }
    }

    public class MacAddressRange
    {
        public string LowRange { get; set; }
        public string HighRange { get; set; }

        //Foreign Key - MacAddress class
        public MacAddress MacAddress { get; set; }
        public string MacAddressID { get; set; }
    }
}
