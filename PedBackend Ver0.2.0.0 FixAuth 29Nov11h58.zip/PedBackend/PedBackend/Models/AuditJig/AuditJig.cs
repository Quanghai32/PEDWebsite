﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PedServer.Models.AuditJig
{
    public class AuditJigReport
    {
        public string ID { get; set; }
        public DateTime AuditTime { get; set; }

        //Result of List item audit
        public List<AuditItemResult> AuditItemResults { get; set; }

        //Cell Name
        public string CellName { get; set; }

        //Foreign Key - Product Model
        public ProductModel.ProductModel ProductModel { get; set; }
        public string ProductModelID { get; set; }

        //Foreign Key - Auditor
        public ApplicationUser ApplicationUser { get; set; }
        public string ApplicationUserID { get; set; } //Relation between ApplicationUser vs AuditJigReport: 1 to many
    }

    /// <summary>
    /// Relation between AuditJigReport & AuditItemResult is 1 to many
    /// </summary>
    public class AuditItemResult
    {
        public string ID { get; set; }

        public string Barcode { get; set; }
        public string Result { get; set; } //OK, NG or Unknown
        public string Note { get; set; } //Note about result

        //Foreign Key - Jig Profile found. Relation between AuditItemResult vs JigProfile: 1 vs 1
        public JigProfile.JigProfile JigProfile { get; set; }
        public string JigProfileID { get; set; }

        //Foreign Key - AuditJigReport which AuditItemResult belong to (Relation: 1 to many)
        public AuditJigReport AuditJigReport { get; set; }
        public string AuditJigReportID { get; set; }
    }


}
