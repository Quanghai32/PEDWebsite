﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PedServer.Models.ProductModelInfo
{
    //With each Product Model, we have some setting Info like:
    //  - Rom version, Ram Version, Loader version...
    //  - Mac Address
    public class ProductModelInfo
    {
        [Key]
        public string ID { get; set; }
        public string RomVersion { get; set; }
        public string LoaderVersion { get; set; }
        
        //Foreign Key
        public ProductModel.ProductModel ProductModel { get; set; }
        public string ProductModelID { get; set; }
    }
}
