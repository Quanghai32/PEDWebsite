﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PedServer.Models.UserControl
{
    /// <summary>
    /// The realation between ApplicationUser vs UserEvent? many to many
    /// </summary>
    public class UserEvent
    {
        public string ID { get; set; } //ID of event
        public string Application { get; set; } //Application name 
        public string EventName { get; set; } //Event Name
        public string Message { get; set; } //Event message
        public string EventLink { get; set; } //Event link - link to view detail Info of event
        public DateTime EventTime { get; set; } //Record time when event occur

        public ICollection<EventAssignment> EventAssignments { get; set; }
    }

    //Join table for UserEvent & ApplicationUser tables
    //We need this because relation: many to many
    public class EventAssignment
    {
        public string UserEventID { get; set; }
        public UserEvent UserEvent { get; set; }

        public string ApplicationUserID { get; set; }
        public ApplicationUser ApplicationUser { get; set; }
    }
}
