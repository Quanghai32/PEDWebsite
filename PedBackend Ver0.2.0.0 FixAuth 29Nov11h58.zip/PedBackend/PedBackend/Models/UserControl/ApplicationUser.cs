﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using PedServer.Models.UserControl;
using Microsoft.AspNetCore.Identity;

namespace PedServer.Models
{
    // Add profile data for application users by adding properties to the ApplicationUser class
    public class ApplicationUser : IdentityUser
    {
        public string Name { get; set; } //Full Name of User
        public string Dept { get; set; } //Department of User

        //Relation between ApplicationUser vs UserEvent: 1 to many!
        public ICollection<EventAssignment> EventAssignments { get; set; }
    }
}
