﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace PedServer.Models.StationControl
{
    /// <summary>
    /// This model represent for an actual station in production line.
    /// 
    /// </summary>
    public class Station
    {
        [Key]
        [Display(Name = "Station ID")]
        public int id { get; set; }

        [Required]
        [Display(Name = "Line")]
        [Column("Line")]
        public string strLine { get; set; } //1 station need belong to 1 Line

        [Display(Name = "Product Model")]
        [Column("ProductModel")]
        public string strProductModel { get; set; } //1 station need belong to 1 model

        //[Display(Name = "Checker Name")]
        //[Column("Checker")]
        //public string strChecker { get; set; } //1 station need belong to 1 checker

        //[Display(Name = "Running Mode")]
        //[Column("RunningMode")]
        //public string strRunningMode { get; set; } //Mode indicate running mode: Normal mode/TVP mode

        //[Display(Name = "Program Version")]
        //[Column("ProgramVer")]
        //public string strProgramVer { get; set; } //Version of program used in station

        //[Display(Name = "Step List Version")]
        //[Column("SteplistVer")]
        //public string strSteplistVer { get; set; } //Version of Step list used in station

        //[Display(Name = "Protect Code")]
        //[Column("ProtectCode")]
        //public string strProtectCode { get; set; } //Version of Step list used in station


        //public string strDestination { get; set; } //
        //public string strWlanVer { get; set; }
    }
}
