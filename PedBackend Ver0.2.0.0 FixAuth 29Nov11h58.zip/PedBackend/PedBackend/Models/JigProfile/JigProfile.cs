﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PedServer.Models.JigProfile
{
    public enum jigRanking
    {
        A,
        B1,
        B2,
        C
    }

    public class JigProfile
    {
        [Key]
        public string ID { get; set; } //ID in database
        public string DesignID { get; set; } //ID in master jiglist => in the future, this should be replaced by ID in database?

        public string JigName { get; set; }
        public string JigCode { get; set; }
        public string JigRev { get; set; }
        //For Ranking
        public string JigRank { get; set; }
    }
}
