﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PedServer.Models.JigBarcode
{
    /// <summary>
    /// Contain barcode data of Jig item which made or incharge by PED
    /// </summary>
    public class JigBarcode
    {
        public string ID { get; set; } //ID in database
        public string BarcodeData { get; set; } //Barcode label which assigned & paste on each jig item
        public JigProfile.JigProfile JigProfile { get; set; }
        public string JigProfileID { get; set; } //ID of Jig Profile which jig item belong to
    }
}
