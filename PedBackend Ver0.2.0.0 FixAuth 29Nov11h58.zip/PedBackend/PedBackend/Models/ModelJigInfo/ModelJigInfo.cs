﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using PedServer.Models.JigProfile;
using PedServer.Models.ProductModel;

namespace PedServer.Models.ModelJigInfo
{
    /// <summary>
    /// This class model, contains all infomation of what Model can using what Jig
    /// </summary>
    public class ModelJigInfo
    {
        [Key]
        public string ID { get; set; }
        //Product Model
        public ProductModel.ProductModel ProductModel { get; set; }
        public string ProductModelID { get; set; }
        //List of Jig Profile allow running for Model
        public List<ModelJigProfileAssignment> ModelJigProfileAssignments { get; set; }
    }

    /// <summary>
    /// Relation between ModelJigInfo & JigProfile is many-to-many.
    /// We need a class to connect 2 models together
    /// </summary>
    public class ModelJigProfileAssignment
    {
        public string ModelJigInfoID { get; set; }
        public string JigProfileID { get; set; }
        public ModelJigInfo ModelJigInfo { get; set; }
        public JigProfile.JigProfile JigProfile { get; set; }
    }

}
