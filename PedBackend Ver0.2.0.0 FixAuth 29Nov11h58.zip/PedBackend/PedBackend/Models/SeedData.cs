﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using PedServer.Data;
using PedServer.Define;
using PedServer.Models;
using PedServer.Models.UserControl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static PedServer.Define.ClaimDefine;

namespace PedServer.Models
{
    public class DbInitializer
    {
        public static async Task Initialize(ApplicationDbContext context, UserManager<ApplicationUser> userManager,
            RoleManager<IdentityRole> roleManager, ILogger<DbInitializer> logger)
        {
            context.Database.EnsureCreated();

            // Look for any users.
            if (context.Users.Any())
            {
                return; // DB has been seeded
            }

            await CreateDefaultUserAndRoleForApplication(userManager, roleManager, logger);
        }

        private static async Task CreateDefaultUserAndRoleForApplication(UserManager<ApplicationUser> um, RoleManager<IdentityRole> rm, ILogger<DbInitializer> logger)
        {
            //const string administratorRole = "Administrator";
            //const string email = "Admin@gmail.com";

            //await CreateDefaultAdministratorRole(rm, logger, administratorRole);
            //var user = await CreateDefaultUser(um, logger, email);
            //await SetPasswordForDefaultUser(um, logger, email, user);
            //await AddDefaultRoleToDefaultUser(um, logger, email, administratorRole, user);

            //Confirm if Admin account is created
            ApplicationUser result = await um.FindByNameAsync("Admin");

            //If Admin account not yet exist, then create new account for Admin
            if (result == null)
            {
                //Create new Admin
                var newAdmin = new ApplicationUser()
                {
                    Name = "Admin",
                    UserName = "Admin",
                    Email = "Admin@gmail.com",
                    EmailConfirmed = true
                };

                //Add to user manager
                await um.CreateAsync(newAdmin);

                //Set password for Admin
                await um.AddPasswordAsync(newAdmin, "Admin0123!");

                //Set Claim for Admin
                await um.AddClaimAsync(newAdmin, new IdentityUserClaim<int>()
                {
                    ClaimType = WebAppRole.ClaimType,
                    ClaimValue = WebAppRole.Admin,
                }.ToClaim());

            }
        }

        private static async Task CreateDefaultAdministratorRole(RoleManager<IdentityRole> rm, ILogger<DbInitializer> logger, string administratorRole)
        {
            logger.LogInformation($"Create the role `{administratorRole}` for application");
            var ir = await rm.CreateAsync(new IdentityRole(administratorRole));
            if (ir.Succeeded)
            {
                logger.LogDebug($"Created the role `{administratorRole}` successfully");
            }
            else
            {
                var exception = new ApplicationException($"Default role `{administratorRole}` cannot be created");
                logger.LogError(exception, GetIdentiryErrorsInCommaSeperatedList(ir));
                throw exception;
            }
        }

        //private static async Task<ApplicationUser> CreateDefaultUser(UserManager<ApplicationUser> um, ILogger<DbInitializer> logger, string email)
        //{
        //    logger.LogInformation($"Create default user with email `{email}` for application");
        //    var user = new ApplicationUser(email, "First", "Last", new DateTime(1970, 1, 1));

        //    var ir = await um.CreateAsync(user);
        //    if (ir.Succeeded)
        //    {
        //        logger.LogDebug($"Created default user `{email}` successfully");
        //    }
        //    else
        //    {
        //        var exception = new ApplicationException($"Default user `{email}` cannot be created");
        //        logger.LogError(exception, GetIdentiryErrorsInCommaSeperatedList(ir));
        //        throw exception;
        //    }

        //    var createdUser = await um.FindByEmailAsync(email);
        //    return createdUser;
        //}

        private static async Task SetPasswordForDefaultUser(UserManager<ApplicationUser> um, ILogger<DbInitializer> logger, string email, ApplicationUser user)
        {
            logger.LogInformation($"Set password for default user `{email}`");
            const string password = "YourPassword01!";
            var ir = await um.AddPasswordAsync(user, password);
            if (ir.Succeeded)
            {
                logger.LogTrace($"Set password `{password}` for default user `{email}` successfully");
            }
            else
            {
                var exception = new ApplicationException($"Password for the user `{email}` cannot be set");
                logger.LogError(exception, GetIdentiryErrorsInCommaSeperatedList(ir));
                throw exception;
            }
        }

        private static async Task AddDefaultRoleToDefaultUser(UserManager<ApplicationUser> um, ILogger<DbInitializer> logger, string email, string administratorRole, ApplicationUser user)
        {
            logger.LogInformation($"Add default user `{email}` to role '{administratorRole}'");
            var ir = await um.AddToRoleAsync(user, administratorRole);
            if (ir.Succeeded)
            {
                logger.LogDebug($"Added the role '{administratorRole}' to default user `{email}` successfully");
            }
            else
            {
                var exception = new ApplicationException($"The role `{administratorRole}` cannot be set for the user `{email}`");
                logger.LogError(exception, GetIdentiryErrorsInCommaSeperatedList(ir));
                throw exception;
            }
        }

        private static string GetIdentiryErrorsInCommaSeperatedList(IdentityResult ir)
        {
            string errors = null;
            foreach (var identityError in ir.Errors)
            {
                errors += identityError.Description;
                errors += ", ";
            }
            return errors;
        }
    }


    public static class SeedData
    {
        public static async void Initialize(IServiceProvider serviceProvider)
        {
            //Check if there is any user
            var userManager = serviceProvider.GetRequiredService<UserManager<ApplicationUser>>();
            var roleManager = serviceProvider.GetRequiredService<RoleManager<ApplicationRole>>();

            //Confirm if Admin account is created
            ApplicationUser result = await userManager.FindByNameAsync("Admin");

            //If Admin account not yet exist, then create new account for Admin
            if (result == null)
            {
                //Create new Admin
                var newAdmin = new ApplicationUser()
                {
                    Name = "Admin",
                    UserName = "Admin",
                    Email = "Admin@gmail.com",
                    EmailConfirmed = true
                };

                //Add to user manager
                await userManager.CreateAsync(newAdmin);

                //Set password for Admin
                await userManager.AddPasswordAsync(newAdmin, "Admin0123!");

                //Set Claim for Admin
                await userManager.AddClaimAsync(newAdmin, new IdentityUserClaim<int>()
                {
                    ClaimType = WebAppRole.ClaimType,
                    ClaimValue = WebAppRole.Admin,
                }.ToClaim());

            }
        }


        public static async Task<int> Initialize2(UserManager<ApplicationUser> userManager, RoleManager<ApplicationRole> roleManager)
        {
            //Confirm if Admin account is created
            ApplicationUser result = await userManager.FindByNameAsync("Admin");

            //If Admin account not yet exist, then create new account for Admin
            if (result == null)
            {
                //Create new Admin
                var newAdmin = new ApplicationUser()
                {
                    Name = "Admin",
                    UserName = "Admin",
                    Email = "Admin@gmail.com",
                    EmailConfirmed = true
                };

                //Add to user manager
                await userManager.CreateAsync(newAdmin);

                //Set password for Admin
                await userManager.AddPasswordAsync(newAdmin, "Admin0123!");

                //Set Claim for Admin
                await userManager.AddClaimAsync(newAdmin, new IdentityUserClaim<int>()
                {
                    ClaimType = WebAppRole.ClaimType,
                    ClaimValue = WebAppRole.Admin,
                }.ToClaim());

            }
            return 0;
        }


    }
}
