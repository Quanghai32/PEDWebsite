﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PedServer.Models.ProductModel
{
    public class ProductModel
    {
        [Key]
        public string ID { get; set; }
        public string ModelName { get; set; } //E28, D92, D81...
        public string CodeName { get; set; } //Laoag, Essen...
        public string EngineName { get; set; } //Fine11, ZF784...
    }
}
