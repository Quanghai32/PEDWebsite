﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PedServer.Models.standardApprove
{
    /// <summary>
    /// Description how 1 action such as: create new, edit, delete... should be approved!
    /// </summary>
    public class BackendApproveSetting
    {
        public bool requireApprove { get; set; } //Indicate action need to be approved or not
        public List<BackendApproveActionSetting> approveActionInfos { get; set; } //Describe how many approve action required
    }

    public class BackendApproveActionSetting
    {
        public string actionName { get; set; } //"Check" or "Approve"
        public string explanation { get; set; } //Explain to user what action need to do
    }

    /// <summary>
    /// Contains information of Verify (Check or Approve) request information
    /// </summary>
    public class VerifyRequest
    {
        [Key]
        public string ID { get; set; } // Primary Key

        public string ApplicationName { get; set; } //Name of Application need verify
        public string ActionDescription { get; set; } //Description of action need to verify (config from backend)
        public string ObjectID { get; set; } // ID of Object need to do verify
        public string BackendLink { get; set; } // Api link of backend which is target when do verify for item (send from Frontend to save Verify request)
        public string FrontendLink { get; set; } // Frontend link navigate to place which can do verify action

        public string RequestorUserName { get; set; } //UserName of Requestor
        public string RequestorComment { get; set; } //Comment of Requestor
        public DateTime RequestTime { get; set; } // Timing do verify request

        public string ApproverUserName { get; set; } //UserName of Approver
    }

    /// <summary>
    /// Contains information about Result of Verify (Check or Approve) actions
    /// </summary>
    public class VerifyResult
    {
        [Key]
        public string ID { get; set; } // Primary Key
        public bool isDone { get; set; } // Indicate Approve request is done or not
        public string Result { get; set; } // Approve result is OK (Accept) or NG (Reject) or another...
        public string Comment { get; set; } // Comment of Approver
        public DateTime VerifyTime { get; set; } // Timing do verify action

        // Foreign Key
        public VerifyRequest VerifyRequest { get; set; }
        public string VerifyRequestID { get; set; }
    }



    //**********************NO USE YET************************************************************

    /// <summary>
    /// Backend data for Standard Approve
    /// </summary>
    /// 
    public class StandardApprove
    {
        [Key]
        public string ID { get; set; } //Primary Key in Database

        public List<ApproveFlow> approveFlows { get; set; } //The flow of Approving process
                                                            //1 Approving process maybe required some approving action
                                                            //Ex: Check + Approve of User Dept => Check + Approve of PE1/P2 => Check + Approve of PQA...
    }

    /// <summary>
    /// Describe the flow of approving process: Action => check? => Approve? => Finish?
    /// </summary>
    public class ApproveFlow
    {
        [Key]
        public string ID { get; set; } //Primary Key in Database

        //Foreign Key - Approve Requestor
        public ApproveRequestor ApproveRequestor { get; set; }
        public string ApproveRequestorID { get; set; }

        //Foreign Key - Checker
        //Foreign Key - Approver
        // => using common model
        public List<ApproveVerify> ApproveVerifies { get; set; } //Count=1: Only require 1 approve
                                                                 //Count=2: Require Check + Approve
    }

    public class ApproveRequestor //Infomation about person who issues approve request
    {
        [Key]
        public string ID { get; set; } //Primary Key in Database
        public string Comment { get; set; } //Comment of Requestor send to all Approve person

        //Foreign Key - Application User
        public ApplicationUser ApplicationUser { get; set; } //Issuer entity
        public string ApplicationUserID { get; set; }
    }

    public class ApproveVerify //Infomation about person who does check request of Approve request (common model)
    {
        [Key]
        public string ID { get; set; } //Primary Key in Database

        public string ActionName { get; set; } // "Check" - Check action
                                               // "Approve" - Approve for action

        public string Message { get; set; } //Message from Approve Requestor send to checker
        public bool CheckResult { get; set; } //Result of Checking is OK or not
        public string Comment { get; set; } //Comment of Approve checker when after check

        //Foreign Key - Approve Checker Entity
        public ApplicationUser ApplicationUser { get; set; } //Issuer entity
        public string ApplicationUserID { get; set; }
    }

}
