﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;


namespace PedServer.Models.JigRequest
{
    public class JigRequest
    {
        [Key]
        public string ID { get; set; } //ID of request

        public string RequisitionAreaID { get; set; }
        public RequisitionArea requisitionArea { get; set; }
        //pedQCArea: PedQCArea;
        //verificationArea: VerificationArea;
    }

    public class RequisitionArea
    {
        [Key]
        public string ID { get; set; } //ID

        public string RequestDeptReqInfoID { get; set; }
        public RequestDeptReqInfo requestDeptReqInfo { get; set; }
        //pe2ReqInfo: Pe2ReqInfo;
        //pedReqInfo: PedReqInfo;
    }

    public class RequestDeptReqInfo
    {
        [Key]
        public string ID { get; set; } //ID

        public string deptName { get; set; }
        public string deptCode { get; set; }
        public string requestControlNo { get; set; }

        //public DateTime receiveDate { get; set; }
        //public string orderQuantity { get; set; } //1,2,3 or attach file!
        //public string AppliedModels { get; set; } //E28,D92,E26...

        ////Jig Name - Code - Rev
        //public string JigToolInfoID { get; set; }
        //public JigToolInfo jigToolInfo { get; set; }

        ////New Jig - Jig Rev Up (reasons)
        //public string RequestCategoryID { get; set; }
        //public RequestCategory requestCategory { get; set; }

        ////MT1 - MT2 - MP - Current Model
        //public string RequestStageID { get; set; }
        //public RequestStage requestStage { get; set; }

        ////Requestor Comment
        //public string comment { get; set; }

        //Requestor Info
        public string IssuedByInfoID { get; set; }
        public IssuedByInfo issuedByInfo { get; set; }

        ////Approve by Manager Info
        //public string ApprovedByInfoID { get; set; }
        //public ApprovedByInfo approvedByInfo { get; set; }
    }

    public class JigToolInfo
    {
        [Key]
        public string ID { get; set; } //ID

        public string jigName { get; set; }
        public string jigCode { get; set; }
        public string jigRev { get; set; }
    }

    public class RequestCategory
    {
        [Key]
        public string ID { get; set; } //ID

        public bool isNewJig { get; set; } //If not => Jig Revision up

        public string jigRevUpReason { get; set; }
        //Design problem: Jig archive request, can run but not good need improvement
        //Request change:Same request but can't operate, not archive purpose, can run but not good,need improvement
        //ECN change: Spec change, Process change,
        //Other...
    }

    public class RequestStage
    {
        [Key]
        public string ID { get; set; } //ID

        public string stageProduction { get; set; }
        //MT1 - MT2 - MP - Current Model
    }

    public class IssuedByInfo
    {
        [Key]
        public string ID { get; set; } //ID

        //public string fullName { get; set; }
        public string ApplicationUserID { get; set; }
        public ApplicationUser user { get; set; }

        public string phoneNumber { get; set; }
        public DateTime date { get; set; }
    }

    public class ApprovedByInfo
    {
        [Key]
        public string ID { get; set; } //ID

        public bool isDone { get; set; } //Already decided?

        public string fullName { get; set; }
        public bool isApproved { get; set; }
        public string phoneNumber { get; set; }
        public DateTime date { get; set; }
    }

}

