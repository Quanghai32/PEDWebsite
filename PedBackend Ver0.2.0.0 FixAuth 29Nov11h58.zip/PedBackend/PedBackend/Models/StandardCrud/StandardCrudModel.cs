﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PedServer.Models.StandardCrud
{
    public class StandardCrudInfo
    {
        public object model { get; set; } //contains all information about properties of model
        public object approveModel { get; set; } //contains description about how bussiness logic of Approving action (create new, Edit, delete...)
    }

    public class StandardDataInfo
    {
        public int total { get; set; } //Total number of item in database
    }

    public class StandardCrudItemInfo
    {
        public object id { get; set; } //id of item
        public int total { get; set; } //Total number of item in database
        public int index { get; set; } //Index of item in all list
    }

    /// <summary>
    /// Element can be just an item or a list of item
    /// </summary>
    public class ElementDescription
    {
        public string type { get; set; } //item or list
        public string elementName { get; set; } //name of element property of object (F1 property)
        public string displayName { get; set; } //Display name of element
        public List<PropertyDescription> propertyDescriptions { get; set; } // type='item' => List has only 1 item. type='List' => List can contains multi item.
        public string createMethod { get; set; } // + createMethod = "input" - default. Create new element by input directly each property of element (textbox, checkbox...)
                                                 // + createMethod = "select" - Create new element by searching from existing entity. Frontend should provide search funtion for user search & select desired item.

        public string searchUrl { get; set; } //Setting search Url for element

        //For CSS Style
        public CssStyle cssStyle { get; set; }

        public ElementDescription()
        {
            this.createMethod = "input";
            this.cssStyle = new CssStyle();
        }
    }

    /// <summary>
    /// "itemProperty1:Item Property1:string:textbox:"
    /// "property4:Label4:string:select:A/B/C/D/E/F"
    /// </summary>
    public class PropertyDescription
    {
        public bool isPrimaryKey { get; set; } //Indicate property is primary key or not

        public string propertyName { get; set; } //Ex: property4
        public string displayName { get; set; } //display name for property. Ex: Label4
        public string dataType { get; set; } //type of property (string, number, boolean...). Ex: string
        public string controlType { get; set; } //Control type for property (textbox,checkbox, select...). Ex: select
        
        //public string style { get; set; } //Description for how to style property ()
        //For Select type
        public List<string> selectDatas { get; set; } // A,B,C,D,E,F

        //For CSS Style
        public CssStyle cssStyle { get; set; }

        public PropertyDescription()
        {
            this.isPrimaryKey = false;
            this.cssStyle = new CssStyle();
        }
    }

    public class CssStyle
    {
        public string color { get; set; }
        public string visibility { get; set; }
        public string display { get; set; }

        //HTML5
        public bool disabled { get; set; }

        public CssStyle()
        {
            this.color = "blue";
            this.visibility = "show";
            this.display = "inline";

            this.disabled = false;
        }
    }

}
