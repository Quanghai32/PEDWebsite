﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace PedServer.Models.StandardCrud
{
    public enum testEnum
    {
        A,
        B,
        C,
        D,
        E
    }

    //Relationship between TestCrud & TestCrudItemList => 1 to many
    public class TestCrudItemList
    {
        [Key]
        public string Id { get; set; }

        public string ItemProperty1 { get; set; }
        public string ItemProperty2 { get; set; }
        public bool ItemProperty3 { get; set; }
        public string ItemProperty4 { get; set; }

        //Foreign key - TestCrud
        public string TestCrudID { get; set; }
        public TestCrud TestCrud { get; set; }
    }

    public class TestCrud
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public string Id { get; set; }
        //
        public DateTime SampleDate { get; set; }
        public string Property2 { get; set; }
        public bool Property3 { get; set; }
        public string Property4 { get; set; } //Get value from enum

        // Foreign Key
        //Test Collection - Relationship between TestCrudItemList & ItemList => 1 to many
        public ICollection<TestCrudItemList> TestCrudItemLists { get; set; }
    }
}
