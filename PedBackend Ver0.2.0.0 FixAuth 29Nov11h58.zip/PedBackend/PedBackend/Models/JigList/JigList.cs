﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using PedServer.Models.JigProfile;
using PedServer.Models.ProductModel;

namespace PedServer.WebApi
{
    public class JigListRowData
    {
        public string ID { get; set; }
        public string ItemNo { get; set; }
        public string NewOrCommon { get; set; }
        public List<JigProfile> JigProfiles { get; set; }
        public string RequestDept { get; set; }
    }

    public class JigList
    {
        [Key]
        public string ID { get; set; }
        //Model of Jig List
        public ProductModel ProductModel { get; set; }
        public string ProductModelID { get; set; }

        //Row data model of Jig List 
        public List<JigListRowData> JigListRowDatas { get; set; }
    }
}
