﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using PedServer.Models.JigProfile;
using PedServer.WebApi;
using PedServer.Models.ProductModelInfo;
using PedServer.Models;
using PedServer.api;
using PedServer.Models.UserControl;

namespace PedServer
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            // Add as many of these lines as you need to map your objects
            CreateMap<ApplicationUser, ApplicationUserDTO>();
            CreateMap<ApplicationUserDTO, ApplicationUser>(); //Should not be map?
            //
            CreateMap<JigProfile, JigProfileDTO>();
            CreateMap<JigProfileDTO, JigProfile>();
            //
            CreateMap<ProductModelInfo, ProductModelInfoDTO>()
                .ForMember(dest => dest.ModelName, opt => opt.MapFrom(src => src.ProductModel.ModelName));
            CreateMap<ProductModelInfoDTO, ProductModelInfo>();
            //
            CreateMap<UserEvent, UserEventDTO>();
            CreateMap<UserEventDTO, UserEvent>();
        }
    }
}
